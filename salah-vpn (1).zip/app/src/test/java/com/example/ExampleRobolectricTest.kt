package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.PayloadFormatter
import com.example.engine.VpnLinkParser
import com.example.model.VpnProfile
import com.example.model.VpnProtocol
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Salah VPN", appName)
    }

    @Test
    fun `test payload formatting macro replacement`() {
        val raw = "CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf]User-Agent: [ua][crlf][crlf]"
        val formatted = PayloadFormatter.formatPayload(
            rawPayload = raw,
            targetHost = "iraq.salahvpn.net",
            targetPort = 443,
            headerHost = "fast.iraq.net"
        )
        assertTrue(formatted.contains("CONNECT fast.iraq.net:443 HTTP/1.1\r\n"))
        assertTrue(formatted.contains("Host: fast.iraq.net\r\n"))
    }

    @Test
    fun `test link parser for vless`() {
        val link = "vless://12345678-1234-1234-1234-123456789012@example.com:443?type=ws&security=tls&sni=sni.example.com&path=%2Fvless-ws#TestNode"
        val parsed = VpnLinkParser.parseLink(link)
        assertNotNull(parsed)
        assertEquals(VpnProtocol.VLESS, parsed?.protocol)
        assertEquals("example.com", parsed?.server)
        assertEquals(443, parsed?.port)
        assertEquals("12345678-1234-1234-1234-123456789012", parsed?.uuidOrPassword)
        assertEquals("sni.example.com", parsed?.sni)
        assertEquals("/vless-ws", parsed?.path)
    }
}
