package com.example.service

import android.os.ParcelFileDescriptor
import android.util.Log
import com.example.data.repository.VpnRepository
import com.example.model.VpnProfile
import io.nekohasekai.libbox.ConnectionOwner
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.LocalDNSTransport
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.Notification
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState

class SalahPlatformInterface(
    private val vpnService: SalahVpnService,
    private val profile: VpnProfile,
    private val repo: VpnRepository,
    private val onLogStep: (String, String) -> Unit
) : PlatformInterface {

    private val tag = "SalahPlatformInterface"
    var createdPfd: ParcelFileDescriptor? = null
        private set

    override fun autoDetectInterfaceControl(fd: Int) {
        val success = vpnService.protect(fd)
        if (!success) {
            Log.w(tag, "Failed to protect interface control socket fd=$fd")
        }
    }

    override fun openTun(options: TunOptions): Int {
        onLogStep("النفق (TUN)", "تهيئة واجهة VpnService مع معلمات libbox...")

        val builder = vpnService.Builder()
        builder.setSession("Salah VPN - ${profile.protocol.displayName}")

        // MTU: use options MTU or default 1500
        val mtu = if (options.mtu > 0) options.mtu else 1500
        builder.setMtu(mtu)

        // Add IPv4 Addresses
        val inet4 = runCatching { options.inet4Address }.getOrNull()
        var hasAddedIpv4 = false
        if (inet4 != null) {
            while (inet4.hasNext()) {
                val prefix = inet4.next()
                if (prefix != null) {
                    builder.addAddress(prefix.address(), prefix.prefix())
                    hasAddedIpv4 = true
                }
            }
        }
        if (!hasAddedIpv4) {
            builder.addAddress("172.19.0.1", 30)
        }

        // Add Routes
        val inet4Routes = runCatching { options.inet4RouteAddress }.getOrNull()
        var hasAddedRoute = false
        if (inet4Routes != null && inet4Routes.hasNext()) {
            while (inet4Routes.hasNext()) {
                val prefix = inet4Routes.next()
                if (prefix != null) {
                    builder.addRoute(prefix.address(), prefix.prefix())
                    hasAddedRoute = true
                }
            }
        }
        if (!hasAddedRoute) {
            builder.addRoute("0.0.0.0", 0)
        }

        // DNS Server
        val dnsBox = runCatching { options.dnsServerAddress }.getOrNull()
        val dnsAddress = dnsBox?.value
        if (!dnsAddress.isNullOrBlank()) {
            builder.addDnsServer(dnsAddress)
        } else {
            val customDns = profile.customDns.split(",").map { it.trim() }.filter { it.isNotBlank() }
            if (customDns.isNotEmpty()) {
                customDns.forEach { dns ->
                    runCatching { builder.addDnsServer(dns) }
                }
            } else {
                builder.addDnsServer("1.1.1.1")
                builder.addDnsServer("8.8.8.8")
            }
        }

        // Protect Salah VPN app from looping into tunnel
        runCatching { builder.addDisallowedApplication(vpnService.packageName) }

        // Per-App Routing
        val bypassMode = repo.getPerAppMode()
        val selectedPackages = repo.getSelectedApps()
        if (selectedPackages.isNotEmpty()) {
            if (bypassMode) {
                selectedPackages.forEach { pkg ->
                    runCatching { builder.addDisallowedApplication(pkg) }
                }
            } else {
                selectedPackages.forEach { pkg ->
                    runCatching { builder.addAllowedApplication(pkg) }
                }
            }
        }

        val pfd = builder.establish() ?: throw IllegalStateException("فشل إنشاء واجهة TUN بواسطة VpnService")
        createdPfd = pfd

        onLogStep("النفق (TUN)", "تم فتح واجهة TUN (MTU: $mtu) وربطها بمحرك sing-box.")
        return pfd.detachFd()
    }

    override fun usePlatformAutoDetectInterfaceControl(): Boolean = true

    override fun clearDNSCache() {}

    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener?) {}

    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener?) {}

    override fun findConnectionOwner(
        ipProtocol: Int,
        sourceAddress: String?,
        sourcePort: Int,
        destinationAddress: String?,
        destinationPort: Int
    ): ConnectionOwner? = null

    override fun getInterfaces(): NetworkInterfaceIterator? = null

    override fun includeAllNetworks(): Boolean = false

    override fun localDNSTransport(): LocalDNSTransport? = null

    override fun readWIFIState(): WIFIState? = null

    override fun sendNotification(notification: Notification?) {}

    override fun systemCertificates(): StringIterator? = null

    override fun underNetworkExtension(): Boolean = false

    override fun useProcFS(): Boolean = false
}
