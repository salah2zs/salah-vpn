package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.SalahVpnDatabase
import com.example.data.repository.VpnRepository
import com.example.engine.BoxService
import com.example.engine.Libbox
import com.example.engine.PayloadForwarder
import com.example.engine.SingBoxConfigBuilder
import com.example.model.ConnectionStats
import com.example.model.ConnectionStatus
import com.example.model.LogStep
import com.example.model.ProxyMode
import com.example.model.VpnProfile
import io.nekohasekai.libbox.CommandClient
import io.nekohasekai.libbox.CommandClientHandler
import io.nekohasekai.libbox.CommandClientOptions
import io.nekohasekai.libbox.ConnectionEvents
import io.nekohasekai.libbox.Libbox as NativeLibbox
import io.nekohasekai.libbox.LogIterator
import io.nekohasekai.libbox.OutboundGroupIterator
import io.nekohasekai.libbox.ServiceStatusMessage
import io.nekohasekai.libbox.StatusMessage
import io.nekohasekai.libbox.StringIterator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class SalahVpnService : VpnService() {

    private val tag = "SalahVpnService"
    private var vpnInterface: ParcelFileDescriptor? = null
    private var payloadForwarder: PayloadForwarder? = null
    private var boxService: BoxService? = null
    private var commandClient: CommandClient? = null
    private var platformInterface: SalahPlatformInterface? = null
    private var statsJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)
    private val isStopping = AtomicBoolean(false)
    private val connectionDurationSeconds = AtomicLong(0L)

    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        setupNetworkMonitor()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when (action) {
            ACTION_STOP -> {
                disconnect()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val profileId = intent.getLongExtra(EXTRA_PROFILE_ID, -1L)
                scope.launch {
                    val db = SalahVpnDatabase.getDatabase(applicationContext)
                    val repo = VpnRepository(db.profileDao(), applicationContext)
                    val profile = if (profileId > 0) {
                        repo.getProfileById(profileId)
                    } else {
                        _currentProfile.value
                    }

                    if (profile != null) {
                        connect(profile, repo, isReconnect = false)
                    } else {
                        addLogStep("خطأ", "لم يتم العثور على إعدادات الاتصال المحددة", isError = true)
                        disconnect()
                    }
                }
                return START_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun connect(profile: VpnProfile, repo: VpnRepository, isReconnect: Boolean = false) {
        if (!isReconnect && (_connectionStatus.value == ConnectionStatus.CONNECTED || _connectionStatus.value == ConnectionStatus.CONNECTING)) {
            return
        }

        _connectionStatus.value = ConnectionStatus.CONNECTING
        _currentProfile.value = profile
        if (!isReconnect) {
            _logSteps.value = emptyList()
            connectionDurationSeconds.set(0L)
        }
        isStopping.set(false)

        val notification = buildNotification("جاري تهيئة نفق Salah VPN ومحرك sing-box…")
        startForeground(NOTIFICATION_ID, notification)

        scope.launch {
            try {
                addLogStep("بدء الاتصال", "بدء تشغيل النفق لبروفايل: ${profile.name.ifBlank { profile.protocol.displayName }}")
                addLogStep("ملخص الاتصال", profile.summaryLine)

                // Step 1: Handle Proxy + Payload if enabled
                var localForwarderPort = 0
                if (profile.proxyMode == ProxyMode.PROXY_PAYLOAD) {
                    addLogStep("وضع البروكسي", "تم تفعيل نمط Proxy + Payload. تشغيل Forwarder المحلي...")
                    payloadForwarder = PayloadForwarder(
                        proxyHost = profile.proxyHost,
                        proxyPort = profile.proxyPort,
                        targetHost = profile.server,
                        targetPort = profile.port,
                        headerHost = profile.headerHost,
                        rawPayload = profile.payload,
                        vpnServiceProtector = { socket: Socket ->
                            protect(socket)
                        },
                        onLogStep = { step ->
                            addLogStep(step.step, step.message, step.isError, step.isSuccess)
                        }
                    )
                    localForwarderPort = payloadForwarder!!.start()
                    if (localForwarderPort <= 0) {
                        throw IllegalStateException("فشل بدء الـ Payload Forwarder المحلي")
                    }
                } else {
                    addLogStep("اتصال مباشر", "الاتصال مباشر بالهدف بدون بروكسي وسيط.")
                }

                // Step 2: Build Sing-Box Configuration with MTU 1500 and auto_route false
                addLogStep("المحرك", "توليد ملف إعداد sing-box متوافق مع VpnService (MTU: 1500, auto_route: false)...")
                val singBoxJson = SingBoxConfigBuilder.buildConfig(
                    profile = profile,
                    localForwarderPort = localForwarderPort,
                    tunMtu = 1500
                )
                Log.d(tag, "Generated sing-box config: $singBoxJson")

                // Step 3: Initialize PlatformInterface for libbox
                val platform = SalahPlatformInterface(
                    vpnService = this@SalahVpnService,
                    profile = profile,
                    repo = repo,
                    onLogStep = { step, msg -> addLogStep(step, msg) }
                )
                platformInterface = platform

                // Step 4: Initialize and start libbox service via Libbox.newService
                addLogStep("المحرك", "تشغيل نواة sing-box (libbox.newService)...")
                val service = Libbox.newService(singBoxJson, platform)
                boxService = service
                service.start()
                addLogStep("المحرك", "تم بدء تشغيل محرك sing-box الرسمي بنجاح!", isSuccess = true)

                vpnInterface = platform.createdPfd

                // Step 5: Start real engine statistics monitor via CommandClient
                startRealEngineStatsMonitor()

                // Marked as CONNECTED
                _connectionStatus.value = ConnectionStatus.CONNECTED
                addLogStep("اكتمال الاتصال", "Salah VPN متصل الآن ويمرر الإنترنت بالكامل!", isSuccess = true)

            } catch (e: Exception) {
                Log.e(tag, "Connection failed", e)
                addLogStep("فشل الاتصال", "السبب: ${e.localizedMessage ?: e.javaClass.simpleName}", isError = true)
                disconnect()
            }
        }
    }

    private fun startRealEngineStatsMonitor() {
        statsJob?.cancel()
        statsJob = scope.launch {
            try {
                // Initialize CommandClient for real statistics and logs from libbox
                val clientOptions = CommandClientOptions().apply {
                    addCommand(NativeLibbox.CommandStatus)
                    statusInterval = 1000L
                }

                commandClient = NativeLibbox.newCommandClient(object : CommandClientHandler {
                    override fun clearLogs() {}
                    override fun connected() {}
                    override fun disconnected(message: String?) {}
                    override fun initializeClashMode(modes: StringIterator?, current: String?) {}
                    override fun setDefaultLogLevel(level: Int) {}
                    override fun updateClashMode(mode: String?) {}
                    override fun writeConnectionEvents(events: ConnectionEvents?) {}
                    override fun writeGroups(groups: OutboundGroupIterator?) {}
                    override fun writeLogs(logs: LogIterator?) {
                        if (logs != null) {
                            while (logs.hasNext()) {
                                val log = logs.next()
                                if (log != null && log.message.isNotBlank()) {
                                    addLogStep("sing-box", log.message)
                                }
                            }
                        }
                    }
                    override fun writeServiceStatus(status: ServiceStatusMessage?) {}
                    override fun writeStatus(status: StatusMessage?) {
                        if (status != null && !isStopping.get()) {
                            val fw = payloadForwarder
                            val fwUpTotal = fw?.totalBytesUploaded?.get() ?: 0L
                            val fwDownTotal = fw?.totalBytesDownloaded?.get() ?: 0L

                            val upSpeed = status.uplink
                            val downSpeed = status.downlink
                            val upTotal = status.uplinkTotal + fwUpTotal
                            val downTotal = status.downlinkTotal + fwDownTotal
                            val duration = connectionDurationSeconds.get()

                            _connectionStats.value = ConnectionStats(
                                uploadSpeedBps = upSpeed,
                                downloadSpeedBps = downSpeed,
                                totalUploadBytes = upTotal,
                                totalDownloadBytes = downTotal,
                                connectedDurationSeconds = duration
                            )

                            updateNotification(duration, upSpeed, downSpeed)
                        }
                    }
                }, clientOptions)

                commandClient?.connect()
            } catch (e: Exception) {
                Log.w(tag, "Could not start CommandClient: ${e.localizedMessage}")
            }

            // Duration timer ticker
            while (isActive && !isStopping.get()) {
                delay(1000)
                connectionDurationSeconds.incrementAndGet()
            }
        }
    }

    private fun updateNotification(durationSeconds: Long, upSpeed: Long, downSpeed: Long) {
        val formattedTime = String.format("%02d:%02d", durationSeconds / 60, durationSeconds % 60)
        val statusText = "متصل: $formattedTime · ↓ ${formatSpeed(downSpeed)} ↑ ${formatSpeed(upSpeed)}"
        val notification = buildNotification(statusText)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, notification)
    }

    private fun formatSpeed(bytesPerSec: Long): String {
        return when {
            bytesPerSec >= 1024 * 1024 -> String.format("%.1f MB/s", bytesPerSec / (1024.0 * 1024.0))
            bytesPerSec >= 1024 -> String.format("%.0f KB/s", bytesPerSec / 1024.0)
            else -> "$bytesPerSec B/s"
        }
    }

    private fun setupNetworkMonitor() {
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onLost(network: Network) {
                if (_connectionStatus.value == ConnectionStatus.CONNECTED && !isStopping.get()) {
                    addLogStep("الشبكة", "انقطاع في اتصال الشبكة! جاري إعادة الاتصال التلقائي...")
                    scope.launch {
                        delay(1500)
                        val profile = _currentProfile.value
                        if (profile != null && !isStopping.get()) {
                            val db = SalahVpnDatabase.getDatabase(applicationContext)
                            val repo = VpnRepository(db.profileDao(), applicationContext)
                            // Cleanly teardown previous session so openTun/connect succeeds
                            disconnectInternal()
                            connect(profile, repo, isReconnect = true)
                        }
                    }
                }
            }
        }
        connectivityManager?.registerNetworkCallback(request, networkCallback!!)
    }

    private fun disconnectInternal() {
        statsJob?.cancel()
        runCatching { commandClient?.disconnect() }
        commandClient = null

        runCatching { boxService?.close() }
        boxService = null

        payloadForwarder?.stop()
        payloadForwarder = null

        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (e: Exception) {
            Log.e(tag, "Error closing VPN interface", e)
        }
    }

    private fun disconnect() {
        if (isStopping.get()) return
        isStopping.set(true)
        _connectionStatus.value = ConnectionStatus.STOPPING

        addLogStep("إيقاف", "جاري إغلاق نفق sing-box واستعادة الإنترنت المباشر...")

        disconnectInternal()

        addLogStep("تم الفصل", "تم قطع اتصال Salah VPN وعاد الإنترنت للعمل مباشرة بدون وسيط.", isSuccess = true)
        _connectionStatus.value = ConnectionStatus.DISCONNECTED
        _connectionStats.value = ConnectionStats()

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnect()
        runCatching {
            networkCallback?.let { connectivityManager?.unregisterNetworkCallback(it) }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Salah VPN Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "VPN Connection and Payload Proxy status"
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingLaunch = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val disconnectIntent = Intent(this, SalahVpnService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingDisconnect = PendingIntent.getService(
            this,
            1,
            disconnectIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Salah VPN - مطورين النت في العراق")
            .setContentText(statusText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingLaunch)
            .setOngoing(true)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "قطع الاتصال",
                pendingDisconnect
            )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        const val ACTION_START = "com.example.salahvpn.START"
        const val ACTION_STOP = "com.example.salahvpn.STOP"
        const val EXTRA_PROFILE_ID = "extra_profile_id"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "salah_vpn_channel"

        private val _connectionStatus = MutableStateFlow(ConnectionStatus.DISCONNECTED)
        val connectionStatus = _connectionStatus.asStateFlow()

        private val _currentProfile = MutableStateFlow<VpnProfile?>(null)
        val currentProfile = _currentProfile.asStateFlow()

        private val _logSteps = MutableStateFlow<List<LogStep>>(emptyList())
        val logSteps = _logSteps.asStateFlow()

        private val _connectionStats = MutableStateFlow(ConnectionStats())
        val connectionStats = _connectionStats.asStateFlow()

        fun addLogStep(step: String, message: String, isError: Boolean = false, isSuccess: Boolean = false) {
            val list = _logSteps.value.toMutableList()
            list.add(LogStep(step = step, message = message, isError = isError, isSuccess = isSuccess))
            _logSteps.value = list
        }

        fun startVpn(context: Context, profile: VpnProfile) {
            _currentProfile.value = profile
            val intent = Intent(context, SalahVpnService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_PROFILE_ID, profile.id)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopVpn(context: Context) {
            val intent = Intent(context, SalahVpnService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
