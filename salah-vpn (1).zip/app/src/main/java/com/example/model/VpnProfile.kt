package com.example.model

data class VpnProfile(
    val id: Long = 0L,
    val name: String = "",
    val protocol: VpnProtocol = VpnProtocol.VLESS,
    val server: String = "",
    val port: Int = 443,
    val uuidOrPassword: String = "",
    val transport: TransportType = TransportType.WEBSOCKET,
    val security: SecurityType = SecurityType.TLS,
    val sni: String = "",
    val headerHost: String = "",
    val path: String = "",
    val flow: String = "",
    val realityPublicKey: String = "",
    val realityShortId: String = "",
    val proxyMode: ProxyMode = ProxyMode.DIRECT,
    val proxyHost: String = "",
    val proxyPort: Int = 8080,
    val payload: String = "",
    val customDns: String = "1.1.1.1,8.8.8.8",
    val isFavorite: Boolean = false,
    val pingMs: Long? = null,
    val lastPingTestTime: Long? = null,
    val subscriptionId: Long? = null,
    val xhttpMode: XhttpMode = XhttpMode.AUTO,
    val xhttpExtra: String = "",
    val isLocked: Boolean = false,
    val expiresAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    val isExpired: Boolean
        get() = expiresAt != null && expiresAt > 0L && System.currentTimeMillis() > expiresAt

    val summaryLine: String
        get() {
            val proto = protocol.displayName
            val trans = transport.displayName
            val sec = security.displayName
            val pxy = if (proxyMode == ProxyMode.PROXY_PAYLOAD) "Payload Proxy" else "Direct"
            val pathStr = if (path.isNotBlank()) " · $path" else ""
            val lockStr = if (isLocked) " · 🔒 مقفل" else ""
            return "$proto · $trans · $sec · $pxy$pathStr$lockStr"
        }

    fun isConfigured(): Boolean {
        return server.isNotBlank() && port > 0
    }
}

data class SubscriptionItem(
    val id: Long = 0L,
    val name: String,
    val url: String,
    val lastUpdated: Long = 0L,
    val profileCount: Int = 0
)

data class InstalledAppItem(
    val packageName: String,
    val appName: String,
    val isSelected: Boolean = false,
    val isSystemApp: Boolean = false
)
