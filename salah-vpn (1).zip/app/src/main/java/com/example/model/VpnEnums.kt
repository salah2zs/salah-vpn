package com.example.model

enum class VpnProtocol(val displayName: String, val scheme: String) {
    VLESS("VLESS", "vless"),
    VMESS("VMess", "vmess"),
    TROJAN("Trojan", "trojan"),
    SHADOWSOCKS("Shadowsocks", "ss"),
    HYSTERIA2("Hysteria 2", "hy2")
}

enum class TransportType(val displayName: String, val identifier: String) {
    TCP("TCP", "tcp"),
    WEBSOCKET("WebSocket", "ws"),
    GRPC("gRPC", "grpc"),
    HTTP_UPGRADE("HTTPUpgrade", "httpupgrade"),
    XHTTP("XHTTP (Splithttp)", "xhttp"),
    MKCP("mKCP", "kcp"),
    HTTP2("HTTP/2", "h2")
}

enum class XhttpMode(val value: String) {
    AUTO("auto"),
    PACKET_UP("packet-up"),
    STREAM_UP("stream-up"),
    STREAM_ONE("stream-one")
}

enum class SecurityType(val displayName: String) {
    NONE("None"),
    TLS("TLS"),
    REALITY("Reality")
}

enum class ProxyMode(val displayName: String) {
    DIRECT("مباشر (Direct)"),
    PROXY_PAYLOAD("بروكسي + Payload")
}

enum class VpnEngine(val displayName: String, val description: String) {
    SINGBOX("sing-box", "المحرك الأساسي للنفق عبر libbox"),
    DUAL_XRAY("sing-box + Xray-core", "نفق هجين يدمج TUN من sing-box مع بروتوكولات Xray (XHTTP/mKCP)")
}

enum class ConnectionStatus(val arabicLabel: String) {
    DISCONNECTED("غير متصل"),
    CONNECTING("جاري الاتصال…"),
    CONNECTED("متصل"),
    STOPPING("جاري الفصل…")
}

data class LogStep(
    val timestamp: Long = System.currentTimeMillis(),
    val step: String,
    val message: String,
    val isError: Boolean = false,
    val isSuccess: Boolean = false
)

data class ConnectionStats(
    val uploadSpeedBps: Long = 0L,
    val downloadSpeedBps: Long = 0L,
    val totalUploadBytes: Long = 0L,
    val totalDownloadBytes: Long = 0L,
    val connectedDurationSeconds: Long = 0L
)
