package com.example.engine

import com.example.model.TransportType
import com.example.model.VpnEngine
import com.example.model.VpnProfile
import com.example.model.VpnProtocol

data class EngineDecision(
    val engine: VpnEngine,
    val reason: String,
    val requiresXrayCore: Boolean
)

object EngineSelector {
    /**
     * Determines the optimal engine (sing-box vs Xray-core) for a given profile
     * and documents the precise technical reason.
     */
    fun selectEngine(profile: VpnProfile): EngineDecision {
        // 1. XHTTP (Splithttp) is exclusive to Xray-core
        if (profile.transport == TransportType.XHTTP) {
            return EngineDecision(
                engine = VpnEngine.DUAL_XRAY,
                reason = "تم اختيار Xray-core لأن نقل XHTTP (Splithttp) مدعوم أصلياً وحصرياً في Xray-core عبر جسر SOCKS مع sing-box TUN.",
                requiresXrayCore = true
            )
        }

        // 2. mKCP is best handled by Xray-core
        if (profile.transport == TransportType.MKCP) {
            return EngineDecision(
                engine = VpnEngine.DUAL_XRAY,
                reason = "تم اختيار Xray-core لتوافق نقل mKCP مع إعدادات حزم UDP في Xray.",
                requiresXrayCore = true
            )
        }

        // 3. HTTP/2 custom transport if used with VMess/Trojan
        if (profile.transport == TransportType.HTTP2 && profile.protocol == VpnProtocol.VMESS) {
            return EngineDecision(
                engine = VpnEngine.DUAL_XRAY,
                reason = "تم اختيار Xray-core لدعم نقل HTTP/2 مع بروتوكول VMess.",
                requiresXrayCore = true
            )
        }

        // 4. Default: sing-box (libbox) handles VLESS, VMess, Trojan, Shadowsocks, Hysteria2 with TCP/WS/gRPC/HTTPUpgrade natively
        return EngineDecision(
            engine = VpnEngine.SINGBOX,
            reason = "تم اختيار sing-box (libbox) كمحرك مباشر للنفق بكفاءة وسرعة عالية لبروتوكول ${profile.protocol.displayName} بنقل ${profile.transport.displayName}.",
            requiresXrayCore = false
        )
    }
}
