package com.example.engine

import android.util.Log
import com.example.model.LogStep
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class PayloadForwarder(
    private val proxyHost: String,
    private val proxyPort: Int,
    private val targetHost: String,
    private val targetPort: Int,
    private val headerHost: String,
    private val rawPayload: String,
    private val vpnServiceProtector: (Socket) -> Boolean,
    private val onLogStep: (LogStep) -> Unit
) {
    private val tag = "PayloadForwarder"
    private var serverSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private var listenJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    val totalBytesUploaded = AtomicLong(0L)
    val totalBytesDownloaded = AtomicLong(0L)

    var localPort: Int = 0
        private set

    fun start(): Int {
        try {
            serverSocket = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
            localPort = serverSocket!!.localPort
            isRunning.set(true)

            onLogStep(
                LogStep(
                    step = "البروكسي المحلي",
                    message = "تم تشغيل Forwarder المحلي على 127.0.0.1:$localPort",
                    isSuccess = true
                )
            )

            listenJob = scope.launch {
                acceptLoop()
            }
            return localPort
        } catch (e: Exception) {
            Log.e(tag, "Failed to start local forwarder", e)
            onLogStep(
                LogStep(
                    step = "خطأ تهيئة",
                    message = "تعذر بدء السيرفر المحلي: ${e.localizedMessage}",
                    isError = true
                )
            )
            return -1
        }
    }

    private suspend fun acceptLoop() {
        while (isRunning.get() && scope.isActive) {
            try {
                val clientSocket = serverSocket?.accept() ?: break
                scope.launch {
                    handleClientConnection(clientSocket)
                }
            } catch (e: Exception) {
                if (isRunning.get()) {
                    Log.e(tag, "Error accepting client", e)
                }
                break
            }
        }
    }

    private fun handleClientConnection(clientSocket: Socket) {
        var proxySocket: Socket? = null
        try {
            onLogStep(
                LogStep(
                    step = "اتصال وارد",
                    message = "استلام اتصال محلي جديد، جاري توجيهه عبر البروكسي $proxyHost:$proxyPort..."
                )
            )

            proxySocket = Socket()
            // CRITICAL: Protect upstream socket from being captured by VpnService TUN
            val protected = vpnServiceProtector(proxySocket)
            if (protected) {
                onLogStep(
                    LogStep(
                        step = "حماية النفق",
                        message = "تمت حماية سوكت البروكسي من الدخول في نفق VPN (Socket Protected)"
                    )
                )
            } else {
                onLogStep(
                    LogStep(
                        step = "تنبيه حماية",
                        message = "تنبيه: لم يتم تفعيل Protect على السوكت بنجاح",
                        isError = false
                    )
                )
            }

            // Connect to upstream proxy
            onLogStep(
                LogStep(
                    step = "البروكسي",
                    message = "جاري الاتصال بالبروكسي $proxyHost:$proxyPort (مهلة 10 ثوانٍ)..."
                )
            )
            proxySocket.connect(InetSocketAddress(proxyHost, proxyPort), 10000)
            proxySocket.tcpNoDelay = true

            onLogStep(
                LogStep(
                    step = "البروكسي",
                    message = "تم الاتصال بالبروكسي $proxyHost:$proxyPort بنجاح",
                    isSuccess = true
                )
            )

            // Format payload and inject
            val formattedPayload = PayloadFormatter.formatPayload(
                rawPayload = rawPayload.ifBlank { PayloadFormatter.getPresetPayload() },
                targetHost = targetHost,
                targetPort = targetPort,
                headerHost = headerHost
            )

            onLogStep(
                LogStep(
                    step = "Payload",
                    message = "إرسال رسالة الـ Payload المخصصة إلى البروكسي..."
                )
            )

            val proxyOut = proxySocket.getOutputStream()
            val proxyIn = proxySocket.getInputStream()

            proxyOut.write(formattedPayload.toByteArray(Charsets.UTF_8))
            proxyOut.flush()

            // Read proxy HTTP response
            val reader = BufferedReader(InputStreamReader(proxyIn, Charsets.US_ASCII))
            val statusLine = reader.readLine()

            if (statusLine == null) {
                onLogStep(
                    LogStep(
                        step = "رد البروكسي",
                        message = "فشل: لم يتم استلام أي رد من البروكسي (Connection Reset / Closed)",
                        isError = true
                    )
                )
                clientSocket.close()
                proxySocket.close()
                return
            }

            val (statusCode, reason) = PayloadFormatter.parseHttpStatus(statusLine)
            if (statusCode == 200) {
                onLogStep(
                    LogStep(
                        step = "رد البروكسي",
                        message = "تم قبول النفق بنجاح ($statusLine)",
                        isSuccess = true
                    )
                )

                // Consume remaining response headers until blank line
                var headerLine = reader.readLine()
                while (!headerLine.isNullOrEmpty()) {
                    headerLine = reader.readLine()
                }

                onLogStep(
                    LogStep(
                        step = "بدء تمرير البيانات",
                        message = "تم فتح النفق بنجاح، جاري تمرير بيانات بروتوكول $targetHost:$targetPort بالاتجاهين.",
                        isSuccess = true
                    )
                )

                // Bi-directional stream pump
                val clientIn = clientSocket.getInputStream()
                val clientOut = clientSocket.getOutputStream()

                val job1 = scope.launch {
                    pipeStreams(clientIn, proxyOut, totalBytesUploaded)
                }
                val job2 = scope.launch {
                    pipeStreams(proxyIn, clientOut, totalBytesDownloaded)
                }

                job1.invokeOnCompletion { runCatching { proxySocket.close() } }
                job2.invokeOnCompletion { runCatching { clientSocket.close() } }
            } else {
                onLogStep(
                    LogStep(
                        step = "رد البروكسي",
                        message = "فشل نفق البروكسي! كود الرد: $statusCode ($reason). تحقق من الـ Payload ومضيف الرأس.",
                        isError = true
                    )
                )
                clientSocket.close()
                proxySocket.close()
            }
        } catch (e: Exception) {
            Log.e(tag, "Tunnel forwarding failed", e)
            onLogStep(
                LogStep(
                    step = "خطأ اتصال",
                    message = "فشل في تمرير النفق: ${e.localizedMessage ?: e.javaClass.simpleName}",
                    isError = true
                )
            )
            runCatching { clientSocket.close() }
            runCatching { proxySocket?.close() }
        }
    }

    private fun pipeStreams(input: InputStream, output: OutputStream, counter: AtomicLong) {
        val buffer = ByteArray(16384)
        try {
            var bytesRead: Int
            while (isRunning.get()) {
                bytesRead = input.read(buffer)
                if (bytesRead == -1) break
                output.write(buffer, 0, bytesRead)
                output.flush()
                counter.addAndGet(bytesRead.toLong())
            }
        } catch (_: Exception) {
            // Socket closed normally or connection reset
        }
    }

    fun stop() {
        isRunning.set(false)
        listenJob?.cancel()
        runCatching { serverSocket?.close() }
        serverSocket = null
        onLogStep(
            LogStep(
                step = "إيقاف",
                message = "تم إيقاف Forwarder البروكسي المحلي."
            )
        )
    }
}
