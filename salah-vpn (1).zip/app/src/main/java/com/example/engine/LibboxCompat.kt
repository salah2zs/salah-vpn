package com.example.engine

import io.nekohasekai.libbox.CommandServerHandler
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.SystemProxyStatus

interface BoxService {
    fun start()
    fun close()
}

object LibboxCompat {
    fun newService(configJson: String, platform: PlatformInterface): BoxService {
        val handler = object : CommandServerHandler {
            override fun getSystemProxyStatus(): SystemProxyStatus? = null
            override fun serviceReload() {}
            override fun serviceStop() {}
            override fun setSystemProxyEnabled(enabled: Boolean) {}
            override fun writeDebugMessage(message: String?) {}
        }

        val server = io.nekohasekai.libbox.Libbox.newCommandServer(handler, platform)

        return object : BoxService {
            override fun start() {
                server.start()
                server.startOrReloadService(configJson, null)
            }

            override fun close() {
                runCatching { server.closeService() }
                runCatching { server.close() }
            }
        }
    }
}

/**
 * Libbox runner providing Libbox.newService(configJson, platform)
 */
object Libbox {
    fun newService(configJson: String, platform: PlatformInterface): BoxService =
        LibboxCompat.newService(configJson, platform)
}
