package com.example.engine

import android.net.Uri
import android.util.Base64
import com.example.model.ProxyMode
import com.example.model.SecurityType
import com.example.model.TransportType
import com.example.model.VpnProfile
import com.example.model.VpnProtocol
import com.example.model.XhttpMode
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder

object VpnLinkParser {

    /**
     * Parses standard proxy/VPN share URLs into VpnProfile instances.
     * Throws an exception or returns null if the protocol or transport is invalid/unsupported.
     */
    fun parseLink(link: String): VpnProfile? {
        val trimmed = link.trim()
        return try {
            when {
                trimmed.startsWith("vless://", ignoreCase = true) -> parseVless(trimmed)
                trimmed.startsWith("vmess://", ignoreCase = true) -> parseVmess(trimmed)
                trimmed.startsWith("trojan://", ignoreCase = true) -> parseTrojan(trimmed)
                trimmed.startsWith("ss://", ignoreCase = true) -> parseShadowsocks(trimmed)
                trimmed.startsWith("hy2://", ignoreCase = true) || trimmed.startsWith("hysteria2://", ignoreCase = true) -> parseHysteria2(trimmed)
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun parseVless(link: String): VpnProfile {
        val uri = Uri.parse(link)
        val userInfo = uri.userInfo ?: ""
        val host = uri.host ?: ""
        val port = if (uri.port > 0) uri.port else 443
        val fragment = uri.fragment?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrDefault(it) } ?: "VLESS Node"

        val typeParam = uri.getQueryParameter("type")?.lowercase() ?: "ws"
        val securityParam = uri.getQueryParameter("security") ?: "tls"
        val sni = uri.getQueryParameter("sni") ?: uri.getQueryParameter("peer") ?: ""
        val hostHeader = uri.getQueryParameter("host") ?: ""
        val path = uri.getQueryParameter("path")?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrDefault(it) } ?: "/"
        val flow = uri.getQueryParameter("flow") ?: ""
        val pbk = uri.getQueryParameter("pbk") ?: ""
        val sid = uri.getQueryParameter("sid") ?: ""
        val modeParam = uri.getQueryParameter("mode") ?: uri.getQueryParameter("xhttpMode")
        val extraParam = uri.getQueryParameter("extra")?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrDefault(it) } ?: ""

        val transport = when (typeParam) {
            "tcp" -> TransportType.TCP
            "ws", "websocket" -> TransportType.WEBSOCKET
            "grpc" -> TransportType.GRPC
            "httpupgrade" -> TransportType.HTTP_UPGRADE
            "xhttp", "splithttp" -> TransportType.XHTTP
            "kcp", "mkcp" -> TransportType.MKCP
            "h2", "http" -> TransportType.HTTP2
            else -> throw IllegalArgumentException("نوع النقل غير مدعوم: $typeParam")
        }

        val xhttpMode = when (modeParam?.lowercase()) {
            "packet-up" -> XhttpMode.PACKET_UP
            "stream-up" -> XhttpMode.STREAM_UP
            "stream-one" -> XhttpMode.STREAM_ONE
            else -> XhttpMode.AUTO
        }

        val security = when (securityParam.lowercase()) {
            "reality" -> SecurityType.REALITY
            "none" -> SecurityType.NONE
            else -> SecurityType.TLS
        }

        return VpnProfile(
            name = fragment,
            protocol = VpnProtocol.VLESS,
            server = host,
            port = port,
            uuidOrPassword = userInfo,
            transport = transport,
            security = security,
            sni = sni,
            headerHost = hostHeader,
            path = path,
            flow = flow,
            realityPublicKey = pbk,
            realityShortId = sid,
            xhttpMode = xhttpMode,
            xhttpExtra = extraParam
        )
    }

    private fun parseVmess(link: String): VpnProfile {
        val raw = link.substring(8)
        val decoded = String(Base64.decode(raw, Base64.DEFAULT or Base64.URL_SAFE), Charsets.UTF_8)
        val json = JSONObject(decoded)

        val remark = json.optString("ps", "VMess Node")
        val add = json.optString("add", "")
        val port = json.optInt("port", 443)
        val id = json.optString("id", "")
        val net = json.optString("net", "ws").lowercase()
        val tls = json.optString("tls", "tls")
        val host = json.optString("host", "")
        val path = json.optString("path", "/")
        val sni = json.optString("sni", host)

        val transport = when (net) {
            "tcp" -> TransportType.TCP
            "ws", "websocket" -> TransportType.WEBSOCKET
            "grpc" -> TransportType.GRPC
            "httpupgrade" -> TransportType.HTTP_UPGRADE
            "xhttp", "splithttp" -> TransportType.XHTTP
            "kcp", "mkcp" -> TransportType.MKCP
            "h2", "http" -> TransportType.HTTP2
            else -> throw IllegalArgumentException("نوع النقل غير مدعوم في VMess: $net")
        }

        val security = if (tls.equals("tls", ignoreCase = true)) SecurityType.TLS else SecurityType.NONE

        return VpnProfile(
            name = remark,
            protocol = VpnProtocol.VMESS,
            server = add,
            port = port,
            uuidOrPassword = id,
            transport = transport,
            security = security,
            sni = sni,
            headerHost = host,
            path = path
        )
    }

    private fun parseTrojan(link: String): VpnProfile {
        val uri = Uri.parse(link)
        val password = uri.userInfo ?: ""
        val host = uri.host ?: ""
        val port = if (uri.port > 0) uri.port else 443
        val fragment = uri.fragment?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrDefault(it) } ?: "Trojan Node"

        val typeParam = uri.getQueryParameter("type")?.lowercase() ?: "tcp"
        val sni = uri.getQueryParameter("sni") ?: ""
        val hostHeader = uri.getQueryParameter("host") ?: ""
        val path = uri.getQueryParameter("path")?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrDefault(it) } ?: "/"

        val transport = when (typeParam) {
            "ws", "websocket" -> TransportType.WEBSOCKET
            "grpc" -> TransportType.GRPC
            "httpupgrade" -> TransportType.HTTP_UPGRADE
            "xhttp", "splithttp" -> TransportType.XHTTP
            "kcp", "mkcp" -> TransportType.MKCP
            "h2", "http" -> TransportType.HTTP2
            "tcp" -> TransportType.TCP
            else -> throw IllegalArgumentException("نوع النقل غير مدعوم في Trojan: $typeParam")
        }

        return VpnProfile(
            name = fragment,
            protocol = VpnProtocol.TROJAN,
            server = host,
            port = port,
            uuidOrPassword = password,
            transport = transport,
            security = SecurityType.TLS,
            sni = sni,
            headerHost = hostHeader,
            path = path
        )
    }

    private fun parseShadowsocks(link: String): VpnProfile {
        val uri = Uri.parse(link)
        val fragment = uri.fragment?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrDefault(it) } ?: "Shadowsocks Node"
        val userInfo = uri.userInfo

        if (userInfo != null) {
            val decodedUserInfo = runCatching {
                String(Base64.decode(userInfo, Base64.DEFAULT or Base64.URL_SAFE), Charsets.UTF_8)
            }.getOrDefault(userInfo)
            val parts = decodedUserInfo.split(":", limit = 2)
            val password = if (parts.size >= 2) parts[1] else parts[0]
            val host = uri.host ?: ""
            val port = if (uri.port > 0) uri.port else 8388

            return VpnProfile(
                name = fragment,
                protocol = VpnProtocol.SHADOWSOCKS,
                server = host,
                port = port,
                uuidOrPassword = password,
                transport = TransportType.TCP,
                security = SecurityType.NONE
            )
        }
        return VpnProfile(
            name = fragment,
            protocol = VpnProtocol.SHADOWSOCKS,
            server = uri.host ?: "",
            port = if (uri.port > 0) uri.port else 8388
        )
    }

    private fun parseHysteria2(link: String): VpnProfile {
        val uri = Uri.parse(link)
        val password = uri.userInfo ?: ""
        val host = uri.host ?: ""
        val port = if (uri.port > 0) uri.port else 443
        val fragment = uri.fragment?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrDefault(it) } ?: "Hysteria 2 Node"
        val sni = uri.getQueryParameter("sni") ?: ""

        return VpnProfile(
            name = fragment,
            protocol = VpnProtocol.HYSTERIA2,
            server = host,
            port = port,
            uuidOrPassword = password,
            transport = TransportType.TCP,
            security = SecurityType.TLS,
            sni = sni
        )
    }

    /**
     * Converts a VpnProfile into a standard share URL
     */
    fun toShareLink(profile: VpnProfile): String {
        val encodedName = runCatching { URLEncoder.encode(profile.name.ifBlank { "SalahVPN" }, "UTF-8") }.getOrDefault("SalahVPN")
        return when (profile.protocol) {
            VpnProtocol.VLESS -> {
                val secStr = when (profile.security) {
                    SecurityType.REALITY -> "security=reality&pbk=${profile.realityPublicKey}&sid=${profile.realityShortId}"
                    SecurityType.TLS -> "security=tls"
                    SecurityType.NONE -> "security=none"
                }
                val transStr = "type=${profile.transport.identifier}"
                val sniStr = if (profile.sni.isNotBlank()) "&sni=${profile.sni}" else ""
                val hostStr = if (profile.headerHost.isNotBlank()) "&host=${profile.headerHost}" else ""
                val pathStr = if (profile.path.isNotBlank()) "&path=${URLEncoder.encode(profile.path, "UTF-8")}" else ""
                val flowStr = if (profile.flow.isNotBlank()) "&flow=${profile.flow}" else ""
                val modeStr = if (profile.transport == TransportType.XHTTP) "&mode=${profile.xhttpMode.value}" else ""
                val extraStr = if (profile.xhttpExtra.isNotBlank()) "&extra=${URLEncoder.encode(profile.xhttpExtra, "UTF-8")}" else ""
                "vless://${profile.uuidOrPassword}@${profile.server}:${profile.port}?$transStr&$secStr$sniStr$hostStr$pathStr$flowStr$modeStr$extraStr#$encodedName"
            }
            VpnProtocol.VMESS -> {
                val json = JSONObject().apply {
                    put("v", "2")
                    put("ps", profile.name.ifBlank { "SalahVPN" })
                    put("add", profile.server)
                    put("port", profile.port)
                    put("id", profile.uuidOrPassword)
                    put("aid", 0)
                    put("scy", "auto")
                    put("net", profile.transport.identifier)
                    put("type", "none")
                    put("host", profile.headerHost)
                    put("path", profile.path.ifBlank { "/" })
                    put("tls", if (profile.security == SecurityType.TLS) "tls" else "none")
                    put("sni", profile.sni)
                }
                val encoded = Base64.encodeToString(json.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                "vmess://$encoded"
            }
            VpnProtocol.TROJAN -> {
                val typeStr = "type=${profile.transport.identifier}"
                val sniStr = if (profile.sni.isNotBlank()) "&sni=${profile.sni}" else ""
                val pathStr = if (profile.path.isNotBlank()) "&path=${URLEncoder.encode(profile.path, "UTF-8")}" else ""
                "trojan://${profile.uuidOrPassword}@${profile.server}:${profile.port}?$typeStr$sniStr$pathStr#$encodedName"
            }
            VpnProtocol.SHADOWSOCKS -> {
                val userPart = "aes-256-gcm:${profile.uuidOrPassword}"
                val b64User = Base64.encodeToString(userPart.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                "ss://$b64User@${profile.server}:${profile.port}#$encodedName"
            }
            VpnProtocol.HYSTERIA2 -> {
                val sniStr = if (profile.sni.isNotBlank()) "?sni=${profile.sni}" else ""
                "hy2://${profile.uuidOrPassword}@${profile.server}:${profile.port}$sniStr#$encodedName"
            }
        }
    }
}
