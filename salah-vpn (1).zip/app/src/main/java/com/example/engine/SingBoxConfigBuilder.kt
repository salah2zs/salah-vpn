package com.example.engine

import com.example.model.ProxyMode
import com.example.model.SecurityType
import com.example.model.TransportType
import com.example.model.VpnProfile
import com.example.model.VpnProtocol
import org.json.JSONArray
import org.json.JSONObject

object SingBoxConfigBuilder {

    /**
     * Builds full sing-box JSON configuration for the specified VpnProfile.
     * When localForwarderPort > 0 (Proxy+Payload mode), the outbound connects via the local forwarder.
     */
    fun buildConfig(
        profile: VpnProfile,
        localForwarderPort: Int = 0,
        localSocksPort: Int = 0,
        dnsServers: List<String> = listOf("1.1.1.1", "8.8.8.8"),
        tunMtu: Int = 1500
    ): String {
        val root = JSONObject()

        // 1. Log block
        val log = JSONObject().apply {
            put("disabled", false)
            put("level", "info")
            put("timestamp", true)
        }
        root.put("log", log)

        // 2. DNS block
        val dns = JSONObject().apply {
            val servers = JSONArray()
            val effectiveDns = if (profile.customDns.isNotBlank()) {
                profile.customDns.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            } else {
                dnsServers
            }

            effectiveDns.forEach { serverIp ->
                val dnsObj = JSONObject().apply {
                    put("tag", "dns-$serverIp")
                    put("address", serverIp)
                    put("detour", "direct")
                }
                servers.put(dnsObj)
            }
            put("servers", servers)
            put("strategy", "prefer_ipv4")
        }
        root.put("dns", dns)

        // 3. Inbounds (TUN compatible with libbox and VpnService)
        val inbounds = JSONArray()
        val tunInbound = JSONObject().apply {
            put("type", "tun")
            put("tag", "tun-in")
            put("interface_name", "tun0")
            put("inet4_address", "172.19.0.1/30")
            put("auto_route", false) // Disabled because VpnService handles routing
            put("strict_route", false)
            put("mtu", tunMtu)
            put("stack", "system")
            put("sniff", true)
        }
        inbounds.put(tunInbound)
        root.put("inbounds", inbounds)

        // 4. Outbounds
        val outbounds = JSONArray()
        val mainOutbound = if (localSocksPort > 0) {
            // Forward TUN traffic to local Xray SOCKS server on 127.0.0.1:localSocksPort
            JSONObject().apply {
                put("type", "socks")
                put("tag", "proxy")
                put("server", "127.0.0.1")
                put("server_port", localSocksPort)
            }
        } else {
            buildOutbound(profile, localForwarderPort)
        }
        outbounds.put(mainOutbound)

        // Direct outbound
        val directOutbound = JSONObject().apply {
            put("type", "direct")
            put("tag", "direct")
        }
        outbounds.put(directOutbound)

        // Block outbound
        val blockOutbound = JSONObject().apply {
            put("type", "block")
            put("tag", "block")
        }
        outbounds.put(blockOutbound)

        // DNS outbound
        val dnsOutbound = JSONObject().apply {
            put("type", "dns")
            put("tag", "dns-out")
        }
        outbounds.put(dnsOutbound)

        root.put("outbounds", outbounds)

        // 5. Routing
        val route = JSONObject().apply {
            val rules = JSONArray()

            // DNS hijack rule
            val dnsRule = JSONObject().apply {
                put("protocol", "dns")
                put("outbound", "dns-out")
            }
            rules.put(dnsRule)

            // Local loopback protect rule
            val localRule = JSONObject().apply {
                val ipArray = JSONArray().apply {
                    put("127.0.0.1")
                    put("::1")
                }
                put("ip_cidr", ipArray)
                put("outbound", "direct")
            }
            rules.put(localRule)

            put("rules", rules)
            put("auto_detect_interface", true)
        }
        root.put("route", route)

        return root.toString(2)
    }

    private fun buildOutbound(profile: VpnProfile, localForwarderPort: Int): JSONObject {
        val out = JSONObject()
        val isPayloadProxy = profile.proxyMode == ProxyMode.PROXY_PAYLOAD && localForwarderPort > 0

        // If routing through local forwarder, server is 127.0.0.1 and port is local forwarder port.
        // The forwarder already completes Proxy handshake and routes raw stream to target!
        val connectHost = if (isPayloadProxy) "127.0.0.1" else profile.server
        val connectPort = if (isPayloadProxy) localForwarderPort else profile.port

        when (profile.protocol) {
            VpnProtocol.VLESS -> {
                out.put("type", "vless")
                out.put("tag", "proxy")
                out.put("server", connectHost)
                out.put("server_port", connectPort)
                out.put("uuid", profile.uuidOrPassword)
                if (profile.flow.isNotBlank()) {
                    out.put("flow", profile.flow)
                }
            }
            VpnProtocol.VMESS -> {
                out.put("type", "vmess")
                out.put("tag", "proxy")
                out.put("server", connectHost)
                out.put("server_port", connectPort)
                out.put("uuid", profile.uuidOrPassword)
                out.put("security", "auto")
                out.put("alter_id", 0)
            }
            VpnProtocol.TROJAN -> {
                out.put("type", "trojan")
                out.put("tag", "proxy")
                out.put("server", connectHost)
                out.put("server_port", connectPort)
                out.put("password", profile.uuidOrPassword)
            }
            VpnProtocol.SHADOWSOCKS -> {
                out.put("type", "shadowsocks")
                out.put("tag", "proxy")
                out.put("server", connectHost)
                out.put("server_port", connectPort)
                out.put("method", "aes-256-gcm")
                out.put("password", profile.uuidOrPassword)
            }
            VpnProtocol.HYSTERIA2 -> {
                out.put("type", "hysteria2")
                out.put("tag", "proxy")
                out.put("server", profile.server)
                out.put("server_port", profile.port)
                out.put("password", profile.uuidOrPassword)
            }
        }

        // Configure TLS or Reality
        val tlsObj = JSONObject()
        val effectiveSni = if (profile.sni.isNotBlank()) profile.sni else profile.server

        when (profile.security) {
            SecurityType.TLS -> {
                tlsObj.put("enabled", true)
                tlsObj.put("server_name", effectiveSni)
                tlsObj.put("insecure", true)
                val alpn = JSONArray().apply {
                    put("h2")
                    put("http/1.1")
                }
                tlsObj.put("alpn", alpn)
                out.put("tls", tlsObj)
            }
            SecurityType.REALITY -> {
                tlsObj.put("enabled", true)
                tlsObj.put("server_name", effectiveSni)
                val realityObj = JSONObject().apply {
                    put("enabled", true)
                    put("public_key", profile.realityPublicKey)
                    put("short_id", profile.realityShortId)
                }
                tlsObj.put("reality", realityObj)
                out.put("tls", tlsObj)
            }
            SecurityType.NONE -> {
                // TLS disabled
            }
        }

        // Configure Transport
        val transportObj = JSONObject()
        when (profile.transport) {
            TransportType.TCP -> {
                // Default TCP
            }
            TransportType.WEBSOCKET -> {
                transportObj.put("type", "ws")
                transportObj.put("path", profile.path.ifBlank { "/" })
                if (profile.headerHost.isNotBlank()) {
                    val headers = JSONObject()
                    headers.put("Host", profile.headerHost)
                    transportObj.put("headers", headers)
                }
                out.put("transport", transportObj)
            }
            TransportType.GRPC -> {
                transportObj.put("type", "grpc")
                transportObj.put("service_name", profile.path.ifBlank { "grpc" })
                out.put("transport", transportObj)
            }
            TransportType.HTTP_UPGRADE -> {
                transportObj.put("type", "httpupgrade")
                transportObj.put("path", profile.path.ifBlank { "/" })
                if (profile.headerHost.isNotBlank()) {
                    transportObj.put("host", profile.headerHost)
                }
                out.put("transport", transportObj)
            }
        }

        return out
    }
}
