package com.example.engine

object PayloadFormatter {
    const val DEFAULT_USER_AGENT = "Mozilla/5.0 (Linux; Android 14; Mobile; SalahVPN/1.0)"

    /**
     * Formats payload by replacing macro variables with actual target parameters.
     */
    fun formatPayload(
        rawPayload: String,
        targetHost: String,
        targetPort: Int,
        headerHost: String = "",
        customUserAgent: String = DEFAULT_USER_AGENT
    ): String {
        val effectiveHost = if (headerHost.isNotBlank()) headerHost else targetHost
        val hostPort = "$effectiveHost:$targetPort"

        var formatted = rawPayload
            // Standard CRLF replacements
            .replace("[crlf]", "\r\n", ignoreCase = true)
            .replace("[lf]", "\n", ignoreCase = true)
            .replace("[cr]", "\r", ignoreCase = true)
            // Host and port replacements
            .replace("[host_port]", hostPort, ignoreCase = true)
            .replace("[host]", effectiveHost, ignoreCase = true)
            .replace("[target_host]", targetHost, ignoreCase = true)
            .replace("[port]", targetPort.toString(), ignoreCase = true)
            // Protocol and user agent replacements
            .replace("[ua]", customUserAgent, ignoreCase = true)
            .replace("[protocol]", "HTTP/1.1", ignoreCase = true)
            .replace("[raw]", "\r\n", ignoreCase = true)

        // Ensure ending CRLFs if missing
        if (!formatted.endsWith("\r\n\r\n")) {
            if (formatted.endsWith("\r\n")) {
                formatted += "\r\n"
            } else {
                formatted += "\r\n\r\n"
            }
        }
        return formatted
    }

    /**
     * Parse HTTP status line like "HTTP/1.1 200 Connection established"
     */
    fun parseHttpStatus(responseLine: String): Pair<Int, String> {
        val parts = responseLine.trim().split(" ", limit = 3)
        if (parts.size >= 2) {
            val code = parts[1].toIntOrNull() ?: -1
            val message = if (parts.size >= 3) parts[2] else ""
            return Pair(code, message)
        }
        return Pair(-1, responseLine)
    }

    /**
     * Preset recommended payload template for quick filling
     */
    fun getPresetPayload(): String {
        return "CONNECT [host_port] [protocol][crlf]Host: [host][crlf]X-Online-Host: [host][crlf]User-Agent: [ua][crlf]Proxy-Connection: Keep-Alive[crlf][crlf]"
    }
}
