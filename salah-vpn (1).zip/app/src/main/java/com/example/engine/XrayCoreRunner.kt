package com.example.engine

import android.content.Context
import android.util.Log
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import java.io.File
import java.net.ServerSocket
import java.util.concurrent.atomic.AtomicBoolean

class XrayCoreRunner(
    private val context: Context,
    private val onLog: (String) -> Unit
) {
    private val tag = "XrayCoreRunner"
    private var controller: CoreController? = null
    private val isRunning = AtomicBoolean(false)

    var localSocksPort: Int = 0
        private set

    fun start(xrayConfigJson: String): Int {
        try {
            // Pick a free local port for SOCKS inbound
            localSocksPort = ServerSocket(0).use { it.localPort }

            // Initialize Xray environment directories
            val datDir = context.filesDir.absolutePath
            val cacheDir = context.cacheDir.absolutePath
            Libv2ray.initCoreEnv(datDir, cacheDir)

            val callback = object : CoreCallbackHandler {
                override fun onEmitStatus(status: Long, msg: String?): Long {
                    if (!msg.isNullOrBlank()) {
                        onLog("Xray status ($status): $msg")
                    }
                    return 0L
                }

                override fun shutdown(): Long {
                    onLog("Xray-core: shutdown signal received.")
                    return 0L
                }

                override fun startup(): Long {
                    onLog("Xray-core: startup completed successfully.")
                    return 0L
                }
            }

            val ctrl = Libv2ray.newCoreController(callback)
            controller = ctrl

            onLog("بدء تشغيل Xray-core مع SOCKS محلي على 127.0.0.1:$localSocksPort...")
            ctrl.startLoop(xrayConfigJson, 0)
            isRunning.set(true)

            return localSocksPort
        } catch (e: Exception) {
            Log.e(tag, "Failed to start Xray core", e)
            onLog("فشل تشغيل Xray-core: ${e.localizedMessage}")
            stop()
            return -1
        }
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) return
        try {
            controller?.stopLoop()
        } catch (e: Exception) {
            Log.w(tag, "Error stopping Xray core", e)
        }
        controller = null
        onLog("تم إيقاف محرك Xray-core.")
    }
}
