package com.example.engine

import android.util.Base64
import com.example.model.VpnProfile
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object CryptoManager {
    private const val ITERATIONS = 65536
    private const val KEY_LENGTH = 256
    private const val GCM_TAG_LENGTH = 128
    private const val MAGIC_HEADER = "SZ_ENCRYPTED_V1:"

    /**
     * Encrypts list of profiles into .sz format string using AES-GCM with password.
     */
    fun exportProfilesToSz(profiles: List<VpnProfile>, password: String): String {
        val jsonArray = JSONArray()
        profiles.forEach { profile ->
            val obj = JSONObject().apply {
                put("name", profile.name)
                put("protocol", profile.protocol.name)
                put("server", profile.server)
                put("port", profile.port)
                put("uuidOrPassword", profile.uuidOrPassword)
                put("transport", profile.transport.name)
                put("security", profile.security.name)
                put("sni", profile.sni)
                put("headerHost", profile.headerHost)
                put("path", profile.path)
                put("flow", profile.flow)
                put("realityPublicKey", profile.realityPublicKey)
                put("realityShortId", profile.realityShortId)
                put("proxyMode", profile.proxyMode.name)
                put("proxyHost", profile.proxyHost)
                put("proxyPort", profile.proxyPort)
                put("payload", profile.payload)
                put("customDns", profile.customDns)
            }
            jsonArray.put(obj)
        }

        val plainBytes = jsonArray.toString().toByteArray(Charsets.UTF_8)
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }

        val keySpec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val secretKey = SecretKeySpec(factory.generateSecret(keySpec).encoded, "AES")

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val gcmSpec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, gcmSpec)
        val cipherBytes = cipher.doFinal(plainBytes)

        // Combine salt (16) + iv (12) + cipherBytes
        val combined = ByteArray(salt.size + iv.size + cipherBytes.size)
        System.arraycopy(salt, 0, combined, 0, salt.size)
        System.arraycopy(iv, 0, combined, salt.size, iv.size)
        System.arraycopy(cipherBytes, 0, combined, salt.size + iv.size, cipherBytes.size)

        return MAGIC_HEADER + Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    /**
     * Decrypts .sz format string into list of profiles using password.
     */
    fun importProfilesFromSz(szData: String, password: String): List<VpnProfile> {
        val trimmed = szData.trim()
        val rawBase64 = if (trimmed.startsWith(MAGIC_HEADER)) {
            trimmed.removePrefix(MAGIC_HEADER)
        } else {
            trimmed
        }

        val combined = Base64.decode(rawBase64, Base64.DEFAULT)
        if (combined.size < 28) throw IllegalArgumentException("Invalid file format")

        val salt = ByteArray(16)
        val iv = ByteArray(12)
        val cipherBytes = ByteArray(combined.size - 28)

        System.arraycopy(combined, 0, salt, 0, 16)
        System.arraycopy(combined, 16, iv, 0, 12)
        System.arraycopy(combined, 28, cipherBytes, 0, cipherBytes.size)

        val keySpec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val secretKey = SecretKeySpec(factory.generateSecret(keySpec).encoded, "AES")

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val gcmSpec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
        cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec)
        val plainBytes = cipher.doFinal(cipherBytes)

        val jsonArray = JSONArray(String(plainBytes, Charsets.UTF_8))
        val profiles = mutableListOf<VpnProfile>()

        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)
            profiles.add(
                VpnProfile(
                    name = obj.optString("name", "Imported Node"),
                    protocol = runCatching { com.example.model.VpnProtocol.valueOf(obj.optString("protocol")) }.getOrDefault(com.example.model.VpnProtocol.VLESS),
                    server = obj.optString("server"),
                    port = obj.optInt("port", 443),
                    uuidOrPassword = obj.optString("uuidOrPassword"),
                    transport = runCatching { com.example.model.TransportType.valueOf(obj.optString("transport")) }.getOrDefault(com.example.model.TransportType.WEBSOCKET),
                    security = runCatching { com.example.model.SecurityType.valueOf(obj.optString("security")) }.getOrDefault(com.example.model.SecurityType.TLS),
                    sni = obj.optString("sni"),
                    headerHost = obj.optString("headerHost"),
                    path = obj.optString("path"),
                    flow = obj.optString("flow"),
                    realityPublicKey = obj.optString("realityPublicKey"),
                    realityShortId = obj.optString("realityShortId"),
                    proxyMode = runCatching { com.example.model.ProxyMode.valueOf(obj.optString("proxyMode")) }.getOrDefault(com.example.model.ProxyMode.DIRECT),
                    proxyHost = obj.optString("proxyHost"),
                    proxyPort = obj.optInt("proxyPort", 8080),
                    payload = obj.optString("payload"),
                    customDns = obj.optString("customDns", "1.1.1.1,8.8.8.8")
                )
            )
        }
        return profiles
    }
}
