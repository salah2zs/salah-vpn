package com.example.engine

import com.example.model.ProxyMode
import com.example.model.SecurityType
import com.example.model.TransportType
import com.example.model.VpnProfile
import com.example.model.VpnProtocol
import com.example.model.XhttpMode
import org.json.JSONArray
import org.json.JSONObject

object XrayConfigBuilder {

    /**
     * Builds Xray-core JSON configuration with a local SOCKS inbound on 127.0.0.1:localSocksPort
     * and the actual proxy outbound with XHTTP, mKCP, or TLS/Reality settings.
     */
    fun buildConfig(
        profile: VpnProfile,
        localSocksPort: Int,
        localForwarderPort: Int = 0
    ): String {
        val root = JSONObject()

        // 1. Log block
        val log = JSONObject().apply {
            put("loglevel", "warning")
        }
        root.put("log", log)

        // 2. Inbound: Local SOCKS proxy bound to 127.0.0.1
        val inbounds = JSONArray()
        val socksInbound = JSONObject().apply {
            put("tag", "socks-in")
            put("port", localSocksPort)
            put("listen", "127.0.0.1")
            put("protocol", "socks")
            put("settings", JSONObject().apply {
                put("auth", "noauth")
                put("udp", true)
            })
            put("sniffing", JSONObject().apply {
                put("enabled", true)
                put("destOverride", JSONArray().apply {
                    put("http")
                    put("tls")
                })
            })
        }
        inbounds.put(socksInbound)
        root.put("inbounds", inbounds)

        // 3. Outbounds
        val outbounds = JSONArray()
        val mainOutbound = buildXrayOutbound(profile, localForwarderPort)
        outbounds.put(mainOutbound)

        // Direct outbound
        val directOutbound = JSONObject().apply {
            put("tag", "direct")
            put("protocol", "freedom")
            put("settings", JSONObject())
        }
        outbounds.put(directOutbound)

        root.put("outbounds", outbounds)

        return root.toString(2)
    }

    private fun buildXrayOutbound(profile: VpnProfile, localForwarderPort: Int): JSONObject {
        val out = JSONObject()
        val isPayloadProxy = profile.proxyMode == ProxyMode.PROXY_PAYLOAD && localForwarderPort > 0

        val connectHost = if (isPayloadProxy) "127.0.0.1" else profile.server
        val connectPort = if (isPayloadProxy) localForwarderPort else profile.port

        out.put("tag", "proxy")

        when (profile.protocol) {
            VpnProtocol.VLESS -> {
                out.put("protocol", "vless")
                val vnext = JSONArray()
                val serverNode = JSONObject().apply {
                    put("address", connectHost)
                    put("port", connectPort)
                    val users = JSONArray().apply {
                        val user = JSONObject().apply {
                            put("id", profile.uuidOrPassword)
                            put("encryption", "none")
                            if (profile.flow.isNotBlank()) {
                                put("flow", profile.flow)
                            }
                        }
                        put(user)
                    }
                    put("users", users)
                }
                vnext.put(serverNode)
                out.put("settings", JSONObject().apply { put("vnext", vnext) })
            }
            VpnProtocol.VMESS -> {
                out.put("protocol", "vmess")
                val vnext = JSONArray()
                val serverNode = JSONObject().apply {
                    put("address", connectHost)
                    put("port", connectPort)
                    val users = JSONArray().apply {
                        val user = JSONObject().apply {
                            put("id", profile.uuidOrPassword)
                            put("alterId", 0)
                            put("security", "auto")
                        }
                        put(user)
                    }
                    put("users", users)
                }
                vnext.put(serverNode)
                out.put("settings", JSONObject().apply { put("vnext", vnext) })
            }
            VpnProtocol.TROJAN -> {
                out.put("protocol", "trojan")
                val servers = JSONArray()
                val serverNode = JSONObject().apply {
                    put("address", connectHost)
                    put("port", connectPort)
                    put("password", profile.uuidOrPassword)
                }
                servers.put(serverNode)
                out.put("settings", JSONObject().apply { put("servers", servers) })
            }
            VpnProtocol.SHADOWSOCKS -> {
                out.put("protocol", "shadowsocks")
                val servers = JSONArray()
                val serverNode = JSONObject().apply {
                    put("address", connectHost)
                    put("port", connectPort)
                    put("method", "aes-256-gcm")
                    put("password", profile.uuidOrPassword)
                }
                servers.put(serverNode)
                out.put("settings", JSONObject().apply { put("servers", servers) })
            }
            VpnProtocol.HYSTERIA2 -> {
                out.put("protocol", "vless") // fallback if routed to Xray
            }
        }

        // StreamSettings
        val stream = JSONObject()
        val effectiveSni = if (profile.sni.isNotBlank()) profile.sni else profile.server

        // Network / Transport
        when (profile.transport) {
            TransportType.XHTTP -> {
                stream.put("network", "xhttp")
                val xhttpSettings = JSONObject().apply {
                    put("mode", profile.xhttpMode.value)
                    put("path", profile.path.ifBlank { "/" })
                    if (profile.headerHost.isNotBlank()) {
                        put("host", profile.headerHost)
                    }
                    if (profile.xhttpExtra.isNotBlank()) {
                        runCatching {
                            put("extra", JSONObject(profile.xhttpExtra))
                        }.onFailure {
                            put("extra", profile.xhttpExtra)
                        }
                    }
                }
                stream.put("xhttpSettings", xhttpSettings)
            }
            TransportType.WEBSOCKET -> {
                stream.put("network", "ws")
                val wsSettings = JSONObject().apply {
                    put("path", profile.path.ifBlank { "/" })
                    if (profile.headerHost.isNotBlank()) {
                        put("headers", JSONObject().apply { put("Host", profile.headerHost) })
                    }
                }
                stream.put("wsSettings", wsSettings)
            }
            TransportType.GRPC -> {
                stream.put("network", "grpc")
                val grpcSettings = JSONObject().apply {
                    put("serviceName", profile.path.ifBlank { "grpc" })
                    put("multiMode", true)
                }
                stream.put("grpcSettings", grpcSettings)
            }
            TransportType.HTTP_UPGRADE -> {
                stream.put("network", "httpupgrade")
                val httpUpgradeSettings = JSONObject().apply {
                    put("path", profile.path.ifBlank { "/" })
                    if (profile.headerHost.isNotBlank()) {
                        put("host", profile.headerHost)
                    }
                }
                stream.put("httpupgradeSettings", httpUpgradeSettings)
            }
            TransportType.MKCP -> {
                stream.put("network", "kcp")
                val kcpSettings = JSONObject().apply {
                    put("mtu", 1350)
                    put("tti", 50)
                    put("uplinkCapacity", 100)
                    put("downlinkCapacity", 100)
                    put("congestion", false)
                    put("readBufferSize", 2)
                    put("writeBufferSize", 2)
                }
                stream.put("kcpSettings", kcpSettings)
            }
            TransportType.HTTP2 -> {
                stream.put("network", "h2")
                val h2Settings = JSONObject().apply {
                    put("path", profile.path.ifBlank { "/" })
                    if (profile.headerHost.isNotBlank()) {
                        put("host", JSONArray().apply { put(profile.headerHost) })
                    }
                }
                stream.put("httpSettings", h2Settings)
            }
            TransportType.TCP -> {
                stream.put("network", "tcp")
            }
        }

        // Security: TLS or Reality
        when (profile.security) {
            SecurityType.TLS -> {
                stream.put("security", "tls")
                val tlsSettings = JSONObject().apply {
                    put("serverName", effectiveSni)
                    put("allowInsecure", true)
                }
                stream.put("tlsSettings", tlsSettings)
            }
            SecurityType.REALITY -> {
                stream.put("security", "reality")
                val realitySettings = JSONObject().apply {
                    put("serverName", effectiveSni)
                    put("publicKey", profile.realityPublicKey)
                    put("shortId", profile.realityShortId)
                    put("fingerprint", "chrome")
                }
                stream.put("realitySettings", realitySettings)
            }
            SecurityType.NONE -> {
                stream.put("security", "none")
            }
        }

        out.put("streamSettings", stream)
        return out
    }
}
