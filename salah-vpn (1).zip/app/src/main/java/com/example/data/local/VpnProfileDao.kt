package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VpnProfileDao {
    @Query("SELECT * FROM vpn_profiles ORDER BY isFavorite DESC, createdAt DESC")
    fun getAllProfilesFlow(): Flow<List<VpnProfileEntity>>

    @Query("SELECT * FROM vpn_profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: Long): VpnProfileEntity?

    @Query("SELECT * FROM vpn_profiles WHERE subscriptionId = :subId")
    suspend fun getProfilesBySubscription(subId: Long): List<VpnProfileEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: VpnProfileEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfiles(profiles: List<VpnProfileEntity>): List<Long>

    @Update
    suspend fun updateProfile(profile: VpnProfileEntity)

    @Delete
    suspend fun deleteProfile(profile: VpnProfileEntity)

    @Query("DELETE FROM vpn_profiles WHERE id = :id")
    suspend fun deleteProfileById(id: Long)

    @Query("DELETE FROM vpn_profiles WHERE subscriptionId = :subId")
    suspend fun deleteBySubscriptionId(subId: Long)

    @Query("UPDATE vpn_profiles SET pingMs = :ping, lastPingTestTime = :testTime WHERE id = :id")
    suspend fun updatePing(id: Long, ping: Long?, testTime: Long)

    @Query("UPDATE vpn_profiles SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: Long, isFavorite: Boolean)

    // Subscriptions
    @Query("SELECT * FROM subscriptions ORDER BY lastUpdated DESC")
    fun getAllSubscriptionsFlow(): Flow<List<SubscriptionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscription(sub: SubscriptionEntity): Long

    @Delete
    suspend fun deleteSubscription(sub: SubscriptionEntity)

    @Query("DELETE FROM subscriptions WHERE id = :id")
    suspend fun deleteSubscriptionById(id: Long)

    @Query("UPDATE subscriptions SET profileCount = :count, lastUpdated = :now WHERE id = :id")
    suspend fun updateSubscriptionCount(id: Long, count: Int, now: Long)
}
