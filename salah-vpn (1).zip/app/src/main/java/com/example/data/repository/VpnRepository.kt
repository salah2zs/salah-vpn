package com.example.data.repository

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.example.data.local.SubscriptionEntity
import com.example.data.local.VpnProfileDao
import com.example.data.local.VpnProfileEntity
import com.example.engine.CryptoManager
import com.example.engine.VpnLinkParser
import com.example.model.InstalledAppItem
import com.example.model.SubscriptionItem
import com.example.model.VpnProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit

class VpnRepository(
    private val dao: VpnProfileDao,
    private val context: Context
) {
    private val sharedPrefs = context.getSharedPreferences("salah_vpn_prefs", Context.MODE_PRIVATE)
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    val profilesFlow: Flow<List<VpnProfile>> = dao.getAllProfilesFlow().map { entities ->
        entities.map { it.toDomain() }
    }

    val subscriptionsFlow: Flow<List<SubscriptionItem>> = dao.getAllSubscriptionsFlow().map { entities ->
        entities.map { entity ->
            SubscriptionItem(
                id = entity.id,
                name = entity.name,
                url = entity.url,
                lastUpdated = entity.lastUpdated,
                profileCount = entity.profileCount
            )
        }
    }

    suspend fun getProfileById(id: Long): VpnProfile? = withContext(Dispatchers.IO) {
        dao.getProfileById(id)?.toDomain()
    }

    suspend fun saveProfile(profile: VpnProfile): Long = withContext(Dispatchers.IO) {
        val entity = VpnProfileEntity.fromDomain(profile)
        dao.insertProfile(entity)
    }

    suspend fun deleteProfile(profile: VpnProfile) = withContext(Dispatchers.IO) {
        dao.deleteProfileById(profile.id)
    }

    suspend fun toggleFavorite(profile: VpnProfile) = withContext(Dispatchers.IO) {
        dao.updateFavorite(profile.id, !profile.isFavorite)
    }

    suspend fun testPing(profile: VpnProfile): Long? = withContext(Dispatchers.IO) {
        val host = if (profile.server.isNotBlank()) profile.server else return@withContext null
        val port = if (profile.port > 0) profile.port else 443
        val startTime = System.currentTimeMillis()
        var ping: Long? = null

        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 4000)
                ping = System.currentTimeMillis() - startTime
            }
        } catch (_: Exception) {
            ping = null
        }

        if (profile.id > 0) {
            dao.updatePing(profile.id, ping, System.currentTimeMillis())
        }
        ping
    }

    suspend fun testAllPings(profiles: List<VpnProfile>) = withContext(Dispatchers.IO) {
        profiles.forEach { profile ->
            testPing(profile)
        }
    }

    // Active Profile ID
    fun getActiveProfileId(): Long {
        return sharedPrefs.getLong("active_profile_id", -1L)
    }

    fun setActiveProfileId(id: Long) {
        sharedPrefs.edit().putLong("active_profile_id", id).apply()
    }

    // Per-App VPN settings
    fun getPerAppMode(): Boolean {
        // true: Only selected apps bypass, false: Only selected apps use VPN
        return sharedPrefs.getBoolean("per_app_bypass_mode", true)
    }

    fun setPerAppMode(bypass: Boolean) {
        sharedPrefs.edit().putBoolean("per_app_bypass_mode", bypass).apply()
    }

    fun getSelectedApps(): Set<String> {
        return sharedPrefs.getStringSet("per_app_packages", emptySet()) ?: emptySet()
    }

    fun setSelectedApps(packages: Set<String>) {
        sharedPrefs.edit().putStringSet("per_app_packages", packages).apply()
    }

    suspend fun getInstalledApps(): List<InstalledAppItem> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val selected = getSelectedApps()

        packages.mapNotNull { appInfo ->
            if (appInfo.packageName == context.packageName) return@mapNotNull null
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val appName = pm.getApplicationLabel(appInfo).toString()
            InstalledAppItem(
                packageName = appInfo.packageName,
                appName = appName,
                isSelected = selected.contains(appInfo.packageName),
                isSystemApp = isSystem
            )
        }.sortedBy { it.appName.lowercase() }
    }

    // Subscriptions
    suspend fun addSubscription(name: String, url: String): Long = withContext(Dispatchers.IO) {
        val subEntity = SubscriptionEntity(
            name = name,
            url = url,
            lastUpdated = System.currentTimeMillis(),
            profileCount = 0
        )
        val subId = dao.insertSubscription(subEntity)
        syncSubscription(subId, url)
        subId
    }

    suspend fun deleteSubscription(subId: Long) = withContext(Dispatchers.IO) {
        dao.deleteBySubscriptionId(subId)
        dao.deleteSubscriptionById(subId)
    }

    suspend fun syncSubscription(subId: Long, url: String): Int = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url).build()
            val response = okHttpClient.newCall(request).execute()
            val body = response.body?.string().orEmpty()

            var decodedText = body
            runCatching {
                val b64 = android.util.Base64.decode(body.trim(), android.util.Base64.DEFAULT)
                decodedText = String(b64, Charsets.UTF_8)
            }

            val lines = decodedText.lines()
            val parsedProfiles = mutableListOf<VpnProfileEntity>()

            lines.forEach { line ->
                val profile = VpnLinkParser.parseLink(line)
                if (profile != null) {
                    parsedProfiles.add(
                        VpnProfileEntity.fromDomain(profile.copy(subscriptionId = subId))
                    )
                }
            }

            if (parsedProfiles.isNotEmpty()) {
                dao.deleteBySubscriptionId(subId)
                dao.insertProfiles(parsedProfiles)
                dao.updateSubscriptionCount(subId, parsedProfiles.size, System.currentTimeMillis())
            }
            parsedProfiles.size
        } catch (_: Exception) {
            0
        }
    }

    // Export & Import .sz
    fun exportProfiles(profiles: List<VpnProfile>, pass: String): String {
        return CryptoManager.exportProfilesToSz(profiles, pass)
    }

    suspend fun importProfiles(szData: String, pass: String): Int = withContext(Dispatchers.IO) {
        val profiles = CryptoManager.importProfilesFromSz(szData, pass)
        val entities = profiles.map { VpnProfileEntity.fromDomain(it) }
        dao.insertProfiles(entities)
        entities.size
    }
}
