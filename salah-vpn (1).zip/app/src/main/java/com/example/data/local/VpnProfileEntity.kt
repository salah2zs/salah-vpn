package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.ProxyMode
import com.example.model.SecurityType
import com.example.model.TransportType
import com.example.model.VpnProfile
import com.example.model.VpnProtocol
import com.example.model.XhttpMode

@Entity(tableName = "vpn_profiles")
data class VpnProfileEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val protocol: String,
    val server: String,
    val port: Int,
    val uuidOrPassword: String,
    val transport: String,
    val security: String,
    val sni: String,
    val headerHost: String,
    val path: String,
    val flow: String,
    val realityPublicKey: String,
    val realityShortId: String,
    val proxyMode: String,
    val proxyHost: String,
    val proxyPort: Int,
    val payload: String,
    val customDns: String,
    val isFavorite: Boolean,
    val pingMs: Long?,
    val lastPingTestTime: Long?,
    val subscriptionId: Long?,
    val xhttpMode: String = "AUTO",
    val xhttpExtra: String = "",
    val isLocked: Boolean = false,
    val expiresAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): VpnProfile {
        return VpnProfile(
            id = id,
            name = name,
            protocol = runCatching { VpnProtocol.valueOf(protocol) }.getOrDefault(VpnProtocol.VLESS),
            server = server,
            port = port,
            uuidOrPassword = uuidOrPassword,
            transport = runCatching { TransportType.valueOf(transport) }.getOrDefault(TransportType.WEBSOCKET),
            security = runCatching { SecurityType.valueOf(security) }.getOrDefault(SecurityType.TLS),
            sni = sni,
            headerHost = headerHost,
            path = path,
            flow = flow,
            realityPublicKey = realityPublicKey,
            realityShortId = realityShortId,
            proxyMode = runCatching { ProxyMode.valueOf(proxyMode) }.getOrDefault(ProxyMode.DIRECT),
            proxyHost = proxyHost,
            proxyPort = proxyPort,
            payload = payload,
            customDns = customDns,
            isFavorite = isFavorite,
            pingMs = pingMs,
            lastPingTestTime = lastPingTestTime,
            subscriptionId = subscriptionId,
            xhttpMode = runCatching { XhttpMode.valueOf(xhttpMode) }.getOrDefault(XhttpMode.AUTO),
            xhttpExtra = xhttpExtra,
            isLocked = isLocked,
            expiresAt = expiresAt,
            createdAt = createdAt
        )
    }

    companion object {
        fun fromDomain(profile: VpnProfile): VpnProfileEntity {
            return VpnProfileEntity(
                id = profile.id,
                name = profile.name,
                protocol = profile.protocol.name,
                server = profile.server,
                port = profile.port,
                uuidOrPassword = profile.uuidOrPassword,
                transport = profile.transport.name,
                security = profile.security.name,
                sni = profile.sni,
                headerHost = profile.headerHost,
                path = profile.path,
                flow = profile.flow,
                realityPublicKey = profile.realityPublicKey,
                realityShortId = profile.realityShortId,
                proxyMode = profile.proxyMode.name,
                proxyHost = profile.proxyHost,
                proxyPort = profile.proxyPort,
                payload = profile.payload,
                customDns = profile.customDns,
                isFavorite = profile.isFavorite,
                pingMs = profile.pingMs,
                lastPingTestTime = profile.lastPingTestTime,
                subscriptionId = profile.subscriptionId,
                xhttpMode = profile.xhttpMode.name,
                xhttpExtra = profile.xhttpExtra,
                isLocked = profile.isLocked,
                expiresAt = profile.expiresAt,
                createdAt = profile.createdAt
            )
        }
    }
}

@Entity(tableName = "subscriptions")
data class SubscriptionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val url: String,
    val lastUpdated: Long,
    val profileCount: Int
)
