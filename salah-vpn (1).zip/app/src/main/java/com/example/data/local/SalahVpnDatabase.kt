package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [VpnProfileEntity::class, SubscriptionEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SalahVpnDatabase : RoomDatabase() {
    abstract fun profileDao(): VpnProfileDao

    companion object {
        @Volatile
        private var INSTANCE: SalahVpnDatabase? = null

        fun getDatabase(context: Context): SalahVpnDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SalahVpnDatabase::class.java,
                    "salah_vpn_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
