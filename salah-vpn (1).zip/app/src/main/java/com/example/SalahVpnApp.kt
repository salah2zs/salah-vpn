package com.example

import android.app.Application
import com.example.data.local.SalahVpnDatabase
import com.example.data.repository.VpnRepository

class SalahVpnApp : Application() {
    lateinit var repository: VpnRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val database = SalahVpnDatabase.getDatabase(this)
        repository = VpnRepository(database.profileDao(), this)
    }
}
