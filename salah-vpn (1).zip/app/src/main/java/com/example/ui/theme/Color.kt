package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sky Blue Salah VPN Palette (Dark & Light)
val SkyPrimary = Color(0xFF0288D1) // Deep Sky Blue
val SkyPrimaryVariant = Color(0xFF03A9F4) // Vibrant Azure Sky
val SkyAccent = Color(0xFF00E5FF) // Cyber Cyan Glow
val SkySecondary = Color(0xFF26C6DA)
val SkyTertiary = Color(0xFF4FC3F7)

// Dark Palette
val SkyDarkBackground = Color(0xFF09141F) // Midnight Deep Sky
val SkyDarkSurface = Color(0xFF102030) // Elevated Dark Slate Sky
val SkyDarkSurfaceVariant = Color(0xFF182E42)
val SkyDarkOnSurface = Color(0xFFE6F3FA)
val SkyDarkOnBackground = Color(0xFFF0F8FF)
val SkyDarkCardBorder = Color(0xFF22425E)

// Light Palette
val SkyLightBackground = Color(0xFFF3F8FC)
val SkyLightSurface = Color(0xFFFFFFFF)
val SkyLightSurfaceVariant = Color(0xFFE1EFF8)
val SkyLightOnSurface = Color(0xFF0B1F33)
val SkyLightOnBackground = Color(0xFF061424)

// Status & Indicators
val SkyConnectedGreen = Color(0xFF00E676)
val SkyConnectingAmber = Color(0xFFFFB300)
val SkyDisconnectedGray = Color(0xFF90A4AE)
val SkyErrorRed = Color(0xFFFF5252)
val SkyPingFast = Color(0xFF00E676)
val SkyPingMedium = Color(0xFFFFCA28)
val SkyPingSlow = Color(0xFFFF7043)
