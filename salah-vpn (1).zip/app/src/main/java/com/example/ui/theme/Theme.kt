package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = SkyPrimaryVariant,
    onPrimary = Color(0xFF001E30),
    primaryContainer = Color(0xFF004D73),
    onPrimaryContainer = Color(0xFFBAE5FF),
    secondary = SkySecondary,
    onSecondary = Color(0xFF00373D),
    secondaryContainer = Color(0xFF004F57),
    onSecondaryContainer = Color(0xFFA5EEF7),
    tertiary = SkyAccent,
    onTertiary = Color(0xFF00363D),
    background = SkyDarkBackground,
    onBackground = SkyDarkOnBackground,
    surface = SkyDarkSurface,
    onSurface = SkyDarkOnSurface,
    surfaceVariant = SkyDarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFC2D9E7),
    outline = SkyDarkCardBorder,
    error = SkyErrorRed
)

private val LightColorScheme = lightColorScheme(
    primary = SkyPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC7E7FF),
    onPrimaryContainer = Color(0xFF001E31),
    secondary = SkySecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFC8F5FA),
    onSecondaryContainer = Color(0xFF001F23),
    tertiary = SkyPrimaryVariant,
    onTertiary = Color.White,
    background = SkyLightBackground,
    onBackground = SkyLightOnBackground,
    surface = SkyLightSurface,
    onSurface = SkyLightOnSurface,
    surfaceVariant = SkyLightSurfaceVariant,
    onSurfaceVariant = Color(0xFF415160),
    outline = Color(0xFFB0C8DA),
    error = SkyErrorRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to deep sky dark mode for modern VPN experience
    dynamicColor: Boolean = false, // Keep branded Sky theme
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.background.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
