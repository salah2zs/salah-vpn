package com.example.ui.screens

import android.app.Activity
import android.net.VpnService
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.RssFeed
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.PowerSettingsNew
import androidx.compose.material.icons.outlined.RssFeed
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.model.VpnProfile
import com.example.ui.theme.SkyAccent
import com.example.ui.theme.SkyDarkCardBorder
import com.example.ui.theme.SkyDisconnectedGray
import com.example.ui.theme.SkyPrimary
import com.example.ui.theme.SkyPrimaryVariant
import com.example.ui.viewmodel.VpnViewModel
import kotlinx.coroutines.flow.collectLatest

enum class MainTab(val title: String) {
    HOME("الاتصال"),
    BOARD("لوحة السيرفرات"),
    SUBSCRIPTIONS("الاشتراكات"),
    SETTINGS("الإعدادات")
}

@Composable
fun MainScreen(viewModel: VpnViewModel) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(MainTab.HOME.ordinal) }
    val snackbarHostState = remember { SnackbarHostState() }

    var pendingConnectProfile by remember { androidx.compose.runtime.mutableStateOf<VpnProfile?>(null) }

    // Launcher for Android VpnService.prepare()
    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val target = pendingConnectProfile ?: viewModel.editingProfile.value
            viewModel.startVpn(context, target)
        } else {
            Toast.makeText(context, "تم رفض إذن نفق الـ VPN", Toast.LENGTH_SHORT).show()
        }
        pendingConnectProfile = null
    }

    fun prepareAndConnect(profile: VpnProfile) {
        val intent = VpnService.prepare(context)
        if (intent != null) {
            pendingConnectProfile = profile
            vpnPermissionLauncher.launch(intent)
        } else {
            viewModel.startVpn(context, profile)
        }
    }

    // Collect toast messages
    LaunchedEffect(Unit) {
        viewModel.toastMessages.collectLatest { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = androidx.compose.ui.unit.Dp(6f)
            ) {
                // Tab 0: Home
                NavigationBarItem(
                    selected = selectedTab == MainTab.HOME.ordinal,
                    onClick = { selectedTab = MainTab.HOME.ordinal },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == MainTab.HOME.ordinal) Icons.Default.PowerSettingsNew else Icons.Outlined.PowerSettingsNew,
                            contentDescription = MainTab.HOME.title
                        )
                    },
                    label = { Text(MainTab.HOME.title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = navigationBarItemColors(),
                    modifier = Modifier.testTag("nav_home")
                )

                // Tab 1: Proxy Board
                NavigationBarItem(
                    selected = selectedTab == MainTab.BOARD.ordinal,
                    onClick = { selectedTab = MainTab.BOARD.ordinal },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == MainTab.BOARD.ordinal) Icons.Default.Dashboard else Icons.Outlined.Dashboard,
                            contentDescription = MainTab.BOARD.title
                        )
                    },
                    label = { Text(MainTab.BOARD.title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = navigationBarItemColors(),
                    modifier = Modifier.testTag("nav_board")
                )

                // Tab 2: Subscriptions
                NavigationBarItem(
                    selected = selectedTab == MainTab.SUBSCRIPTIONS.ordinal,
                    onClick = { selectedTab = MainTab.SUBSCRIPTIONS.ordinal },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == MainTab.SUBSCRIPTIONS.ordinal) Icons.Default.RssFeed else Icons.Outlined.RssFeed,
                            contentDescription = MainTab.SUBSCRIPTIONS.title
                        )
                    },
                    label = { Text(MainTab.SUBSCRIPTIONS.title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = navigationBarItemColors(),
                    modifier = Modifier.testTag("nav_subscriptions")
                )

                // Tab 3: Settings
                NavigationBarItem(
                    selected = selectedTab == MainTab.SETTINGS.ordinal,
                    onClick = { selectedTab = MainTab.SETTINGS.ordinal },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == MainTab.SETTINGS.ordinal) Icons.Default.Settings else Icons.Outlined.Settings,
                            contentDescription = MainTab.SETTINGS.title
                        )
                    },
                    label = { Text(MainTab.SETTINGS.title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = navigationBarItemColors(),
                    modifier = Modifier.testTag("nav_settings")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = selectedTab, label = "tab_fade") { tabIndex ->
                when (tabIndex) {
                    MainTab.HOME.ordinal -> HomeScreen(
                        viewModel = viewModel,
                        onRequireVpnPermission = {
                            prepareAndConnect(viewModel.editingProfile.value)
                        }
                    )
                    MainTab.BOARD.ordinal -> ProxyBoardScreen(
                        viewModel = viewModel,
                        onNavigateToEdit = { profile ->
                            viewModel.setEditingProfile(profile)
                            selectedTab = MainTab.HOME.ordinal
                        },
                        onRequireVpnPermission = { profile ->
                            prepareAndConnect(profile)
                        }
                    )
                    MainTab.SUBSCRIPTIONS.ordinal -> SubscriptionsScreen(
                        viewModel = viewModel
                    )
                    MainTab.SETTINGS.ordinal -> SettingsScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

@Composable
fun navigationBarItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = SkyAccent,
    selectedTextColor = SkyAccent,
    indicatorColor = SkyPrimary.copy(alpha = 0.2f),
    unselectedIconColor = SkyDisconnectedGray,
    unselectedTextColor = SkyDisconnectedGray
)
