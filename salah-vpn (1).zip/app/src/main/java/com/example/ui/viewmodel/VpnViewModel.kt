package com.example.ui.viewmodel

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.SalahVpnApp
import com.example.engine.VpnLinkParser
import com.example.model.ConnectionStats
import com.example.model.ConnectionStatus
import com.example.model.InstalledAppItem
import com.example.model.LogStep
import com.example.model.SubscriptionItem
import com.example.model.VpnProfile
import com.example.service.SalahVpnService
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VpnViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = (application as SalahVpnApp).repository

    val connectionStatus: StateFlow<ConnectionStatus> = SalahVpnService.connectionStatus
    val currentConnectedProfile: StateFlow<VpnProfile?> = SalahVpnService.currentProfile
    val logSteps: StateFlow<List<LogStep>> = SalahVpnService.logSteps
    val connectionStats: StateFlow<ConnectionStats> = SalahVpnService.connectionStats

    val savedProfiles: StateFlow<List<VpnProfile>> = repo.profilesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val subscriptions: StateFlow<List<SubscriptionItem>> = repo.subscriptionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Profile currently being edited / configured on screen (all fields start empty by default as requested!)
    private val _editingProfile = MutableStateFlow(VpnProfile())
    val editingProfile = _editingProfile.asStateFlow()

    private val _toastMessages = MutableSharedFlow<String>()
    val toastMessages: SharedFlow<String> = _toastMessages.asSharedFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppItem>>(emptyList())
    val installedApps = _installedApps.asStateFlow()

    private val _perAppBypass = MutableStateFlow(repo.getPerAppMode())
    val perAppBypass = _perAppBypass.asStateFlow()

    private val _isLoadingApps = MutableStateFlow(false)
    val isLoadingApps = _isLoadingApps.asStateFlow()

    init {
        loadInstalledApps()
    }

    fun updateEditingProfile(transform: (VpnProfile) -> VpnProfile) {
        _editingProfile.value = transform(_editingProfile.value)
    }

    fun setEditingProfile(profile: VpnProfile) {
        _editingProfile.value = profile
    }

    fun clearEditingProfile() {
        _editingProfile.value = VpnProfile()
        emitToast("تم تفريغ جميع الحقول")
    }

    fun saveCurrentEditingProfile() {
        viewModelScope.launch {
            val current = _editingProfile.value
            val id = repo.saveProfile(current)
            _editingProfile.value = current.copy(id = id)
            emitToast("تم حفظ الاتصال بنجاح")
        }
    }

    fun deleteProfile(profile: VpnProfile) {
        viewModelScope.launch {
            repo.deleteProfile(profile)
            if (_editingProfile.value.id == profile.id) {
                _editingProfile.value = VpnProfile()
            }
            emitToast("تم حذف الاتصال: ${profile.name.ifBlank { profile.protocol.displayName }}")
        }
    }

    fun duplicateProfile(profile: VpnProfile) {
        viewModelScope.launch {
            val copy = profile.copy(
                id = 0L,
                name = "${profile.name} (نسخة)",
                isFavorite = false,
                pingMs = null,
                createdAt = System.currentTimeMillis()
            )
            val id = repo.saveProfile(copy)
            emitToast("تم تكرار الاتصال بنجاح")
        }
    }

    fun toggleFavorite(profile: VpnProfile) {
        viewModelScope.launch {
            repo.toggleFavorite(profile)
        }
    }

    fun testPing(profile: VpnProfile) {
        viewModelScope.launch {
            emitToast("جاري قياس سرعة الاستجابة (Ping)...")
            val ping = repo.testPing(profile)
            if (ping != null) {
                emitToast("زمن الاستجابة: $ping مللي ثانية")
            } else {
                emitToast("فشل الاتصال بالسيرفر أو انتهت المهلة")
            }
        }
    }

    fun testAllPings() {
        viewModelScope.launch {
            emitToast("جاري اختبار بنج جميع السيرفرات...")
            repo.testAllPings(savedProfiles.value)
            emitToast("اكتمل اختبار البنج")
        }
    }

    fun startVpn(context: Context, profile: VpnProfile) {
        if (!profile.isConfigured()) {
            emitToast("يرجى إدخال عنوان السيرفر والمنفذ على الأقل")
            return
        }
        repo.setActiveProfileId(profile.id)
        SalahVpnService.startVpn(context, profile)
    }

    fun stopVpn(context: Context) {
        SalahVpnService.stopVpn(context)
    }

    fun clearLogs() {
        // Clear logs by resetting service state flow or adding marker
        SalahVpnService.addLogStep("مسح", "تم مسح سجل العمليات السابق.")
    }

    fun importFromLink(link: String): Boolean {
        val parsed = VpnLinkParser.parseLink(link)
        return if (parsed != null) {
            _editingProfile.value = parsed
            viewModelScope.launch {
                val id = repo.saveProfile(parsed)
                _editingProfile.value = parsed.copy(id = id)
            }
            emitToast("تم استيراد ${parsed.protocol.displayName} بنجاح!")
            true
        } else {
            emitToast("رابط غير صالح! يدعم: vless://, vmess://, trojan://, ss://, hy2://")
            false
        }
    }

    fun importFromClipboard(context: Context) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = clipboard.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
        if (text.isBlank()) {
            emitToast("الحافظة فارغة")
            return
        }
        importFromLink(text)
    }

    fun copyShareLink(context: Context, profile: VpnProfile) {
        val link = VpnLinkParser.toShareLink(profile)
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("VPN Link", link))
        emitToast("تم نسخ الرابط إلى الحافظة")
    }

    // Subscriptions
    fun addSubscription(name: String, url: String) {
        viewModelScope.launch {
            if (url.isBlank()) {
                emitToast("يرجى إدخال رابط الاشتراك")
                return@launch
            }
            emitToast("جاري تحميل سيرفرات الاشتراك...")
            val id = repo.addSubscription(name.ifBlank { "اشتراك جديد" }, url)
            emitToast("تمت إضافة وتحديث الاشتراك بنجاح!")
        }
    }

    fun syncSubscription(item: SubscriptionItem) {
        viewModelScope.launch {
            emitToast("جاري تحديث: ${item.name}...")
            val count = repo.syncSubscription(item.id, item.url)
            emitToast("تم التحديث: تم جلب $count سيرفر")
        }
    }

    fun deleteSubscription(item: SubscriptionItem) {
        viewModelScope.launch {
            repo.deleteSubscription(item.id)
            emitToast("تم حذف الاشتراك وسيرفراته")
        }
    }

    // Per-App VPN
    fun loadInstalledApps() {
        viewModelScope.launch {
            _isLoadingApps.value = true
            val apps = repo.getInstalledApps()
            _installedApps.value = apps
            _isLoadingApps.value = false
        }
    }

    fun toggleAppSelection(packageName: String) {
        val currentSet = repo.getSelectedApps().toMutableSet()
        if (currentSet.contains(packageName)) {
            currentSet.remove(packageName)
        } else {
            currentSet.add(packageName)
        }
        repo.setSelectedApps(currentSet)
        _installedApps.value = _installedApps.value.map {
            if (it.packageName == packageName) it.copy(isSelected = currentSet.contains(packageName)) else it
        }
    }

    fun setPerAppBypass(bypass: Boolean) {
        repo.setPerAppMode(bypass)
        _perAppBypass.value = bypass
    }

    // Encrypted Export & Import (.sz)
    fun exportProfilesEncrypted(password: String): String {
        return repo.exportProfiles(savedProfiles.value, password)
    }

    fun importProfilesEncrypted(szData: String, password: String) {
        viewModelScope.launch {
            try {
                val count = repo.importProfiles(szData, password)
                emitToast("تم استيراد $count اتصال مشفر بنجاح!")
            } catch (e: Exception) {
                emitToast("فشل فك التشفير: تأكد من صحة كلمة المرور وتنسيق الملف")
            }
        }
    }

    private fun emitToast(message: String) {
        viewModelScope.launch {
            _toastMessages.emit(message)
        }
    }
}
