package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AssignmentReturned
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NetworkPing
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionStatus
import com.example.model.ProxyMode
import com.example.model.VpnProfile
import com.example.ui.theme.SkyAccent
import com.example.ui.theme.SkyConnectedGreen
import com.example.ui.theme.SkyConnectingAmber
import com.example.ui.theme.SkyDarkCardBorder
import com.example.ui.theme.SkyDisconnectedGray
import com.example.ui.theme.SkyPrimary
import com.example.ui.theme.SkyPrimaryVariant
import com.example.ui.theme.SkyPingFast
import com.example.ui.theme.SkyPingMedium
import com.example.ui.theme.SkyPingSlow
import com.example.ui.viewmodel.VpnViewModel

@Composable
fun ProxyBoardScreen(
    viewModel: VpnViewModel,
    onNavigateToEdit: (VpnProfile) -> Unit,
    onRequireVpnPermission: (VpnProfile) -> Unit
) {
    val context = LocalContext.current
    val profiles by viewModel.savedProfiles.collectAsState()
    val activeProfile by viewModel.currentConnectedProfile.collectAsState()
    val connectionStatus by viewModel.connectionStatus.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterProtocol by remember { mutableStateOf<String?>(null) }

    val filteredProfiles = remember(profiles, searchQuery, selectedFilterProtocol) {
        profiles.filter { profile ->
            val matchesQuery = searchQuery.isBlank() ||
                profile.name.contains(searchQuery, ignoreCase = true) ||
                profile.server.contains(searchQuery, ignoreCase = true)
            val matchesProto = selectedFilterProtocol == null ||
                profile.protocol.displayName.equals(selectedFilterProtocol, ignoreCase = true)
            matchesQuery && matchesProto
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                // Title and Batch Ping
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "لوحة الاتصالات (Proxy Board)",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${profiles.size} اتصال محفوظ",
                            fontSize = 12.sp,
                            color = SkyAccent
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.testAllPings() },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, SkyPrimary.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.NetworkPing, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("فحص الكل", fontSize = 11.sp)
                        }

                        Button(
                            onClick = { viewModel.importFromClipboard(context) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SkyPrimary)
                        ) {
                            Icon(Icons.Default.AssignmentReturned, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("استيراد رابط", fontSize = 11.sp)
                        }
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث عن سيرفر أو اسم...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SkyAccent) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true,
                    colors = outlinedFieldColors()
                )
            }

            // Empty State
            if (filteredProfiles.isEmpty()) {
                item {
                    EmptyBoardView(
                        onImportClipboard = { viewModel.importFromClipboard(context) }
                    )
                }
            } else {
                items(filteredProfiles, key = { it.id }) { profile ->
                    val isConnectedToThis = activeProfile?.id == profile.id &&
                        connectionStatus == ConnectionStatus.CONNECTED

                    ProxyProfileCard(
                        profile = profile,
                        isConnected = isConnectedToThis,
                        onConnect = { onRequireVpnPermission(profile) },
                        onEdit = { onNavigateToEdit(profile) },
                        onDuplicate = { viewModel.duplicateProfile(profile) },
                        onDelete = { viewModel.deleteProfile(profile) },
                        onCopyLink = { viewModel.copyShareLink(context, profile) },
                        onToggleFavorite = { viewModel.toggleFavorite(profile) },
                        onTestPing = { viewModel.testPing(profile) }
                    )
                }
            }
        }
    }
}

@Composable
fun ProxyProfileCard(
    profile: VpnProfile,
    isConnected: Boolean,
    onConnect: () -> Unit,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    onCopyLink: () -> Unit,
    onToggleFavorite: () -> Unit,
    onTestPing: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEdit() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isConnected) SkyPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            if (isConnected) 1.5.dp else 1.dp,
            if (isConnected) SkyAccent else SkyDarkCardBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header Row: Favorite + Name + Menu
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (profile.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = "Favorite",
                            tint = if (profile.isFavorite) Color(0xFFFFD700) else SkyDisconnectedGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = profile.name.ifBlank { "${profile.protocol.displayName} Server" },
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Box {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Menu", tint = SkyDisconnectedGray)
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("تعديل") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onEdit()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("نسخ (تكرار)") },
                            leadingIcon = { Icon(Icons.Outlined.ContentCopy, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onDuplicate()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("نسخ الرابط") },
                            leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onCopyLink()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("حذف", color = SkyDisconnectedGray) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = SkyDisconnectedGray) },
                            onClick = {
                                showMenu = false
                                onDelete()
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Protocol, Transport & Mode Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BadgeChip(label = profile.protocol.displayName, color = SkyPrimaryVariant)
                BadgeChip(label = profile.transport.displayName, color = SkyAccent)
                BadgeChip(label = profile.security.displayName, color = SkyPrimary)
                if (profile.proxyMode == ProxyMode.PROXY_PAYLOAD) {
                    BadgeChip(label = "Proxy+Payload", color = Color(0xFFFF9100))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Server Address & Ping / Connect Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${profile.server}:${profile.port}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Ping pill
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, SkyDarkCardBorder),
                        modifier = Modifier.clickable { onTestPing() }
                    ) {
                        Text(
                            text = if (profile.pingMs != null) "${profile.pingMs} ms" else "ping ↺",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = when {
                                profile.pingMs == null -> SkyDisconnectedGray
                                profile.pingMs < 120 -> SkyConnectedGreen
                                profile.pingMs < 300 -> SkyConnectingAmber
                                else -> SkyDisconnectedGray
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    // Connect Button
                    Button(
                        onClick = onConnect,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isConnected) SkyConnectedGreen else SkyPrimary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Connect",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isConnected) "متصل" else "اتصال",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BadgeChip(label: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = color,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun EmptyBoardView(onImportClipboard: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, SkyDarkCardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.NetworkPing,
                contentDescription = null,
                tint = SkyAccent.copy(alpha = 0.6f),
                modifier = Modifier.size(54.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "لا توجد اتصالات محفوظة بعد",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "يمكنك إنشاء اتصال جديد يدوياً من الشاشة الأولى أو استيراد رابط vless:// أو vmess:// مباشرة من الحافظة.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onImportClipboard,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SkyPrimary)
            ) {
                Icon(Icons.Default.AssignmentReturned, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("استيراد من الحافظة الآن", fontSize = 12.sp)
            }
        }
    }
}
