package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.PayloadFormatter
import com.example.model.ConnectionStatus
import com.example.model.LogStep
import com.example.model.ProxyMode
import com.example.model.SecurityType
import com.example.model.TransportType
import com.example.model.VpnProtocol
import com.example.ui.theme.SkyAccent
import com.example.ui.theme.SkyConnectedGreen
import com.example.ui.theme.SkyConnectingAmber
import com.example.ui.theme.SkyDarkCardBorder
import com.example.ui.theme.SkyDisconnectedGray
import com.example.ui.theme.SkyErrorRed
import com.example.ui.theme.SkyPrimary
import com.example.ui.theme.SkyPrimaryVariant
import com.example.ui.viewmodel.VpnViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    viewModel: VpnViewModel,
    onRequireVpnPermission: () -> Unit
) {
    val context = LocalContext.current
    val connectionStatus by viewModel.connectionStatus.collectAsState()
    val connectionStats by viewModel.connectionStats.collectAsState()
    val profile by viewModel.editingProfile.collectAsState()
    val logSteps by viewModel.logSteps.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // App Header
            HeaderSection()
        }

        // Summary Line Badge
        item {
            SummaryLineCard(summary = profile.summaryLine)
        }

        // Master Connection Status & Connect Button
        item {
            ConnectionStatusCard(
                status = connectionStatus,
                durationSeconds = connectionStats.connectedDurationSeconds,
                uploadSpeed = connectionStats.uploadSpeedBps,
                downloadSpeed = connectionStats.downloadSpeedBps,
                pingMs = profile.pingMs,
                onToggleConnect = {
                    if (connectionStatus == ConnectionStatus.CONNECTED || connectionStatus == ConnectionStatus.CONNECTING) {
                        viewModel.stopVpn(context)
                    } else {
                        onRequireVpnPermission()
                    }
                }
            )
        }

        // Connection Configuration Fields (Default Empty)
        item {
            ConfigEditorSection(
                viewModel = viewModel
            )
        }

        // Live Steps Log Card
        item {
            LiveLogSection(
                logSteps = logSteps,
                onClearLog = { viewModel.clearLogs() }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun HeaderSection() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, SkyDarkCardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Shield",
                        tint = SkyAccent,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Salah VPN",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Text(
                    text = "مطورين النت في العراق",
                    fontSize = 12.sp,
                    color = SkyAccent,
                    fontWeight = FontWeight.Medium
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SkyPrimary.copy(alpha = 0.2f),
                border = BorderStroke(1.dp, SkyPrimary.copy(alpha = 0.5f))
            ) {
                Text(
                    text = "V 1.0 Pro",
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SkyPrimaryVariant
                )
            }
        }
    }
}

@Composable
fun SummaryLineCard(summary: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = SkyPrimary.copy(alpha = 0.12f)
        ),
        border = BorderStroke(1.dp, SkyPrimary.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Speed,
                contentDescription = null,
                tint = SkyAccent,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = summary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ConnectionStatusCard(
    status: ConnectionStatus,
    durationSeconds: Long,
    uploadSpeed: Long,
    downloadSpeed: Long,
    pingMs: Long?,
    onToggleConnect: () -> Unit
) {
    val isConnected = status == ConnectionStatus.CONNECTED
    val isConnecting = status == ConnectionStatus.CONNECTING

    val statusColor by animateColorAsState(
        targetValue = when (status) {
            ConnectionStatus.CONNECTED -> SkyConnectedGreen
            ConnectionStatus.CONNECTING -> SkyConnectingAmber
            ConnectionStatus.STOPPING -> SkyConnectingAmber
            ConnectionStatus.DISCONNECTED -> SkyDisconnectedGray
        },
        label = "statusColor"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isConnected || isConnecting) 1.08f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("connection_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.5.dp, statusColor.copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Pulse & Big Power Button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(130.dp)
            ) {
                // Outer glow
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(statusColor.copy(alpha = if (isConnected || isConnecting) 0.22f else 0.08f))
                )

                // Master Connect Button
                Button(
                    onClick = onToggleConnect,
                    modifier = Modifier
                        .size(92.dp)
                        .testTag("connect_button"),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isConnected) SkyErrorRed else SkyPrimaryVariant
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = "Power",
                        tint = Color.White,
                        modifier = Modifier.size(42.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Status Text
            Text(
                text = status.arabicLabel,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = statusColor
            )

            // Duration timer if connected
            if (isConnected) {
                val formattedTime = String.format(
                    Locale.US,
                    "%02d:%02d:%02d",
                    durationSeconds / 3600,
                    (durationSeconds % 3600) / 60,
                    durationSeconds % 60
                )
                Text(
                    text = "مدة الاتصال: $formattedTime",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = SkyDarkCardBorder)
            Spacer(modifier = Modifier.height(14.dp))

            // Speeds & Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatItem(
                    label = "التنزيل (Down)",
                    value = formatBytesSpeed(downloadSpeed),
                    color = SkyAccent
                )
                StatItem(
                    label = "الرفع (Up)",
                    value = formatBytesSpeed(uploadSpeed),
                    color = SkyPrimaryVariant
                )
                StatItem(
                    label = "البنج (Ping)",
                    value = if (pingMs != null) "$pingMs ms" else "--",
                    color = if (pingMs != null && pingMs < 120) SkyConnectedGreen else SkyConnectingAmber
                )
            }
        }
    }
}

@Composable
fun StatItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

fun formatBytesSpeed(bytesPerSec: Long): String {
    return when {
        bytesPerSec >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB/s", bytesPerSec / (1024.0 * 1024.0))
        bytesPerSec >= 1024 -> String.format(Locale.US, "%.0f KB/s", bytesPerSec / 1024.0)
        else -> "$bytesPerSec B/s"
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ConfigEditorSection(
    viewModel: VpnViewModel
) {
    val context = LocalContext.current
    val profile by viewModel.editingProfile.collectAsState()

    var showProtocolMenu by remember { mutableStateOf(false) }
    var showTransportMenu by remember { mutableStateOf(false) }
    var showSecurityMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("config_editor_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, SkyDarkCardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "إعدادات الاتصال والتخصيص",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(
                    onClick = { viewModel.clearEditingProfile() },
                    modifier = Modifier.testTag("clear_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Clear",
                        tint = SkyDisconnectedGray
                    )
                }
            }

            // Connection Name / Remarks
            OutlinedTextField(
                value = profile.name,
                onValueChange = { viewModel.updateEditingProfile { p -> p.copy(name = it) } },
                label = { Text("اسم الاتصال (اختياري)") },
                placeholder = { Text("مثلاً: My VLESS Iraq Server") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = outlinedFieldColors()
            )

            // Select Protocol, Transport, and Security Pickers
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Protocol Dropdown
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { showProtocolMenu = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SkyPrimary.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = profile.protocol.displayName,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(
                        expanded = showProtocolMenu,
                        onDismissRequest = { showProtocolMenu = false }
                    ) {
                        VpnProtocol.values().forEach { proto ->
                            DropdownMenuItem(
                                text = { Text(proto.displayName) },
                                onClick = {
                                    viewModel.updateEditingProfile { it.copy(protocol = proto) }
                                    showProtocolMenu = false
                                }
                            )
                        }
                    }
                }

                // Transport Dropdown
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { showTransportMenu = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SkyPrimary.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = profile.transport.displayName,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(
                        expanded = showTransportMenu,
                        onDismissRequest = { showTransportMenu = false }
                    ) {
                        TransportType.values().forEach { trans ->
                            DropdownMenuItem(
                                text = { Text(trans.displayName) },
                                onClick = {
                                    viewModel.updateEditingProfile { it.copy(transport = trans) }
                                    showTransportMenu = false
                                }
                            )
                        }
                    }
                }

                // Security Dropdown
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { showSecurityMenu = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SkyPrimary.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = profile.security.displayName,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(
                        expanded = showSecurityMenu,
                        onDismissRequest = { showSecurityMenu = false }
                    ) {
                        SecurityType.values().forEach { sec ->
                            DropdownMenuItem(
                                text = { Text(sec.displayName) },
                                onClick = {
                                    viewModel.updateEditingProfile { it.copy(security = sec) }
                                    showSecurityMenu = false
                                }
                            )
                        }
                    }
                }
            }

            // Target Server and Port (Independent Fields)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = profile.server,
                    onValueChange = { viewModel.updateEditingProfile { p -> p.copy(server = it.trim()) } },
                    label = { Text("السيرفر الهدف (Target Server)") },
                    placeholder = { Text("مثلاً: server.domain.com") },
                    modifier = Modifier.weight(2.2f).testTag("server_input"),
                    singleLine = true,
                    colors = outlinedFieldColors()
                )
                OutlinedTextField(
                    value = if (profile.port > 0) profile.port.toString() else "",
                    onValueChange = {
                        val num = it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0
                        viewModel.updateEditingProfile { p -> p.copy(port = num) }
                    },
                    label = { Text("المنفذ (Port)") },
                    placeholder = { Text("443") },
                    modifier = Modifier.weight(1f).testTag("port_input"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = outlinedFieldColors()
                )
            }

            // UUID or Password
            OutlinedTextField(
                value = profile.uuidOrPassword,
                onValueChange = { viewModel.updateEditingProfile { p -> p.copy(uuidOrPassword = it.trim()) } },
                label = {
                    Text(
                        when (profile.protocol) {
                            VpnProtocol.VLESS, VpnProtocol.VMESS -> "معرّف UUID"
                            VpnProtocol.TROJAN, VpnProtocol.SHADOWSOCKS, VpnProtocol.HYSTERIA2 -> "كلمة المرور (Password)"
                        }
                    )
                },
                placeholder = { Text("UUID أو كلمة المرور الخاصة بالسيرفر") },
                modifier = Modifier.fillMaxWidth().testTag("uuid_password_input"),
                singleLine = true,
                colors = outlinedFieldColors()
            )

            // SNI & Header Host (Independent Fields)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = profile.sni,
                    onValueChange = { viewModel.updateEditingProfile { p -> p.copy(sni = it.trim()) } },
                    label = { Text("SNI (Server Name)") },
                    placeholder = { Text("sni.domain.com") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    colors = outlinedFieldColors()
                )
                OutlinedTextField(
                    value = profile.headerHost,
                    onValueChange = { viewModel.updateEditingProfile { p -> p.copy(headerHost = it.trim()) } },
                    label = { Text("Header Host") },
                    placeholder = { Text("host.domain.com") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    colors = outlinedFieldColors()
                )
            }

            // Path (Shown for WebSocket / HTTPUpgrade / gRPC)
            if (profile.transport != TransportType.TCP) {
                OutlinedTextField(
                    value = profile.path,
                    onValueChange = { viewModel.updateEditingProfile { p -> p.copy(path = it.trim()) } },
                    label = {
                        Text(if (profile.transport == TransportType.GRPC) "اسم الخدمة (Service Name)" else "المسار (Path)")
                    },
                    placeholder = { Text(if (profile.transport == TransportType.GRPC) "grpc" else "/vless-ws") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = outlinedFieldColors()
                )
            }

            // Reality Parameters (Shown only if Security == Reality)
            if (profile.security == SecurityType.REALITY) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = profile.realityPublicKey,
                        onValueChange = { viewModel.updateEditingProfile { p -> p.copy(realityPublicKey = it.trim()) } },
                        label = { Text("Reality Public Key (pbk)") },
                        modifier = Modifier.weight(2f),
                        singleLine = true,
                        colors = outlinedFieldColors()
                    )
                    OutlinedTextField(
                        value = profile.realityShortId,
                        onValueChange = { viewModel.updateEditingProfile { p -> p.copy(realityShortId = it.trim()) } },
                        label = { Text("Short ID (sid)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = outlinedFieldColors()
                    )
                }
            }

            // VLESS Flow (Shown only if VLESS)
            if (profile.protocol == VpnProtocol.VLESS) {
                OutlinedTextField(
                    value = profile.flow,
                    onValueChange = { viewModel.updateEditingProfile { p -> p.copy(flow = it.trim()) } },
                    label = { Text("Flow (اختياري، مثلاً: xtls-rprx-vision)") },
                    placeholder = { Text("xtls-rprx-vision") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = outlinedFieldColors()
                )
            }

            HorizontalDivider(color = SkyDarkCardBorder)

            // Proxy + Payload Mode Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "تمرير الاتصال عبر بروكسي + Payload",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Forwarder محلي مع حماية السوكت وإرسال Payload مخصص",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
                Switch(
                    checked = profile.proxyMode == ProxyMode.PROXY_PAYLOAD,
                    onCheckedChange = { checked ->
                        viewModel.updateEditingProfile {
                            it.copy(proxyMode = if (checked) ProxyMode.PROXY_PAYLOAD else ProxyMode.DIRECT)
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = SkyPrimaryVariant,
                        checkedTrackColor = SkyPrimary.copy(alpha = 0.5f)
                    )
                )
            }

            // Proxy + Payload Configuration Fields
            AnimatedVisibility(visible = profile.proxyMode == ProxyMode.PROXY_PAYLOAD) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = profile.proxyHost,
                            onValueChange = { viewModel.updateEditingProfile { p -> p.copy(proxyHost = it.trim()) } },
                            label = { Text("عنوان البروكسي (Proxy IP / Host)") },
                            placeholder = { Text("مثلاً: 104.16.0.1 أو بروكسي محلي") },
                            modifier = Modifier.weight(2f),
                            singleLine = true,
                            colors = outlinedFieldColors()
                        )
                        OutlinedTextField(
                            value = if (profile.proxyPort > 0) profile.proxyPort.toString() else "",
                            onValueChange = {
                                val num = it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 8080
                                viewModel.updateEditingProfile { p -> p.copy(proxyPort = num) }
                            },
                            label = { Text("منفذ البروكسي") },
                            placeholder = { Text("8080") },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = outlinedFieldColors()
                        )
                    }

                    // Variable insertion chips for Payload
                    Text(
                        text = "متغيرات الـ Payload الجاهزة (انقر للإضافة):",
                        fontSize = 11.sp,
                        color = SkyAccent,
                        fontWeight = FontWeight.SemiBold
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val macros = listOf("[crlf]", "[host_port]", "[host]", "[port]", "[ua]", "[protocol]")
                        macros.forEach { macro ->
                            FilterChip(
                                selected = false,
                                onClick = {
                                    viewModel.updateEditingProfile { p ->
                                        p.copy(payload = p.payload + macro)
                                    }
                                },
                                label = { Text(macro, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = SkyPrimary.copy(alpha = 0.15f),
                                    labelColor = SkyAccent
                                )
                            )
                        }
                        // Insert preset button
                        FilterChip(
                            selected = false,
                            onClick = {
                                viewModel.updateEditingProfile { p ->
                                    p.copy(payload = PayloadFormatter.getPresetPayload())
                                }
                            },
                            label = { Text("+ نموذج CONNECT جاهز", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = SkyPrimaryVariant.copy(alpha = 0.25f),
                                labelColor = Color.White
                            )
                        )
                    }

                    // Payload Input
                    OutlinedTextField(
                        value = profile.payload,
                        onValueChange = { viewModel.updateEditingProfile { p -> p.copy(payload = it) } },
                        label = { Text("رسالة الـ Payload") },
                        placeholder = { Text("CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf]...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp),
                        maxLines = 5,
                        colors = outlinedFieldColors()
                    )
                }
            }

            HorizontalDivider(color = SkyDarkCardBorder)

            // Action Buttons: Save, Copy Link, Clear
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.saveCurrentEditingProfile() },
                    modifier = Modifier.weight(1f).testTag("save_config_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SkyPrimary)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ الاتصال", fontSize = 13.sp)
                }

                OutlinedButton(
                    onClick = { viewModel.copyShareLink(context, profile) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SkyPrimary.copy(alpha = 0.6f))
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("نسخ الرابط", fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun LiveLogSection(
    logSteps: List<LogStep>,
    onClearLog: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("live_log_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, SkyDarkCardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = SkyAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "سجل الاتصال المباشر (Live Log)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                IconButton(onClick = onClearLog) {
                    Icon(Icons.Default.Refresh, contentDescription = "Clear Log", tint = SkyDisconnectedGray)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (logSteps.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لا توجد خطوات اتصال حالية. اضغط على زر الاتصال لبدء النفق وتسجيل الخطوات بالترتيب.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    logSteps.takeLast(15).forEach { step ->
                        LogStepItem(step = step)
                    }
                }
            }
        }
    }
}

@Composable
fun LogStepItem(step: LogStep) {
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
    val formattedTime = timeFormat.format(Date(step.timestamp))

    val badgeColor = when {
        step.isError -> SkyErrorRed
        step.isSuccess -> SkyConnectedGreen
        else -> SkyPrimaryVariant
    }

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = badgeColor.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = if (step.isError) Icons.Default.ErrorOutline else Icons.Default.CheckCircle,
                contentDescription = null,
                tint = badgeColor,
                modifier = Modifier
                    .size(16.dp)
                    .padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "[${step.step}]",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = badgeColor
                    )
                    Text(
                        text = formattedTime,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = step.message,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f)
                )
            }
        }
    }
}

@Composable
fun outlinedFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = SkyAccent,
    unfocusedBorderColor = SkyDarkCardBorder,
    focusedLabelColor = SkyAccent,
    cursorColor = SkyAccent
)
