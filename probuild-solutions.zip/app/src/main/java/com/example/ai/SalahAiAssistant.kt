package com.example.ai

import com.example.BuildConfig
import com.example.data.ProtocolType
import com.example.data.SecurityLayer
import com.example.data.TransportType
import com.example.data.VpnServerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@Serializable
data class GenerateContentRequest(
    val contents: List<Content>,
    val systemInstruction: Content? = null,
    val generationConfig: GenerationConfig? = null
)

@Serializable
data class Content(
    val parts: List<Part>
)

@Serializable
data class Part(
    val text: String
)

@Serializable
data class GenerationConfig(
    val temperature: Float = 0.4f
)

@Serializable
data class GenerateContentResponse(
    val candidates: List<Candidate> = emptyList()
)

@Serializable
data class Candidate(
    val content: Content? = null
)

interface GeminiRestApi {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

data class DiagnosticReport(
    val title: String,
    val probableCause: String,
    val suggestedFix: String,
    val recommendedTransport: TransportType? = null,
    val recommendedPort: Int? = null,
    val recommendedSni: String? = null,
    val isPoweredByGemini: Boolean = false
)

object SalahAiAssistant {
    private val json = Json { ignoreUnknownKeys = true }

    private val api: GeminiRestApi by lazy {
        val client = OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl("https://generativelanguage.googleapis.com/")
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(GeminiRestApi::class.java)
    }

    /**
     * AI Smart Server Selection algorithm combining Ping, Stability Score, Security Layer, and History.
     */
    fun selectBestServer(servers: List<VpnServerConfig>): VpnServerConfig? {
        if (servers.isEmpty()) return null
        return servers.maxByOrNull { server ->
            val pingScore = when {
                server.pingMs <= 0 -> 40.0
                server.pingMs < 70 -> 100.0
                server.pingMs < 130 -> 85.0
                server.pingMs < 220 -> 65.0
                else -> (300.0 - server.pingMs).coerceAtLeast(10.0) / 3.0
            }
            val stabilityWeight = server.stabilityScore * 0.6
            val securityBonus = when (server.securityEnum) {
                SecurityLayer.REALITY, SecurityLayer.XTLS_VISION -> 18.0
                SecurityLayer.TLS -> 12.0
                SecurityLayer.NONE -> 0.0
            }
            val recentBonus = if (server.lastConnectedAt > 0L) 8.0 else 0.0
            pingScore + stabilityWeight + securityBonus + recentBonus
        }
    }

    /**
     * Diagnoses connection problems or optimizes a VpnServerConfig using Gemini AI (if key set)
     * plus deterministic Xray protocol heuristics.
     */
    suspend fun diagnoseServerConfig(
        server: VpnServerConfig,
        networkType: String = "Wi-Fi / 5G"
    ): DiagnosticReport = withContext(Dispatchers.IO) {
        val heuristicReport = buildHeuristicDiagnosis(server)
        val apiKey = BuildConfig.GEMINI_API_KEY

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            runCatching {
                val prompt = """
                    أنت خبير شبكات وبروتوكولات Xray-core (VMess و VLESS) داخل تطبيق Salah VPN.
                    قم بتحليل إعداد السيرفر التالي وتشخيص أي مشاكل محتملة أو تحسينات مقترحة باختصار وباللغة العربية:
                    - الاسم: ${server.name}
                    - البروتوكول: ${server.protocol}
                    - العنوان والمنفذ: ${server.address}:${server.port}
                    - وسيلة النقل (Transport): ${server.transport}
                    - الأمان (Security): ${server.security}
                    - SNI: ${server.sni}
                    - المسار (Path): ${server.path}
                    - البصمة (Fingerprint): ${server.fingerprint}
                    - زمن الاستجابة (Ping): ${if (server.pingMs > 0) "${server.pingMs}ms" else "غير مقاس"}
                    - نوع الشبكة الحالية: $networkType
                    
                    أعطني:
                    1. السبب المحتمل لأي بطء أو فشل اتصال.
                    2. الحل المقترح العملي لتسريع وتثبيت الاتصال.
                """.trimIndent()

                val response = api.generateContent(
                    apiKey = apiKey,
                    request = GenerateContentRequest(
                        contents = listOf(Content(parts = listOf(Part(text = prompt)))),
                        systemInstruction = Content(
                            parts = listOf(Part(text = "أجب باختصار ووضوح في فقرتين: (التشخيص) و(الحل المقترح)."))
                        )
                    )
                )
                val aiText = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!aiText.isNullOrBlank()) {
                    return@withContext heuristicReport.copy(
                        title = "تشخيص الذكاء الاصطناعي لـ ${server.name}",
                        probableCause = aiText.substringBefore("الحل").trim().ifBlank { heuristicReport.probableCause },
                        suggestedFix = aiText.substringAfter("الحل", heuristicReport.suggestedFix).trim(),
                        isPoweredByGemini = true
                    )
                }
            }
        }
        heuristicReport
    }

    fun buildHeuristicDiagnosis(server: VpnServerConfig): DiagnosticReport {
        val sec = server.securityEnum
        val net = server.transportEnum

        return when {
            sec == SecurityLayer.NONE && server.port != 80 && server.port != 8080 -> {
                DiagnosticReport(
                    title = "تنبيه أمان: طبقة التشفير غير مفعلة (None)",
                    probableCause = "الاتصال يستخدم المنفذ ${server.port} بدون طبقة TLS أو Reality، مما يجعله عرضة للحجب الفوري عبر فحص الحزم العميق (DPI).",
                    suggestedFix = "يُنصح بتفعيل TLS أو Reality على المنفذ 443 مع تعيين SNI مطابق للنطاق وبصمة متصفح Chrome.",
                    recommendedTransport = TransportType.WEBSOCKET,
                    recommendedPort = 443,
                    recommendedSni = server.host.ifBlank { server.address }
                )
            }
            (sec == SecurityLayer.TLS || sec == SecurityLayer.REALITY) && server.sni.isBlank() -> {
                DiagnosticReport(
                    title = "نقص في إعداد SNI (Server Name Indication)",
                    probableCause = "فشل مصافحة TLS/Reality بسبب ترك حقل SNI فارغاً، مما يؤدي لرفض السيرفر للاتصال.",
                    suggestedFix = "قم بتعبئة حقل SNI ليكون مطابقاً لاسم النطاق (${server.address}) مع تفعيل ALPN (h2,http/1.1).",
                    recommendedSni = server.address,
                    recommendedPort = 443
                )
            }
            sec == SecurityLayer.REALITY && server.publicKey.isBlank() -> {
                DiagnosticReport(
                    title = "مفتاح Reality العام (PublicKey) مفقود",
                    probableCause = "بروتوكول VLESS Reality يتطلب مفتاحاً عاماً (pbk) للتحقق من هوية السيرفر وتجاوز الحجب.",
                    suggestedFix = "أضف قيمة Public Key في المحرر أو قم بالتبديل إلى طبقة أمان TLS عبر WebSocket.",
                    recommendedTransport = TransportType.WEBSOCKET
                )
            }
            server.pingMs > 250 -> {
                DiagnosticReport(
                    title = "زمن استجابة مرتفع (${server.pingMs} ms)",
                    probableCause = "المسار الحالي عبر ناقل ${net.displayName} يواجه ازدحاماً أو تقييداً لسرعة الـ TCP من مزود الخدمة.",
                    suggestedFix = "جرّب التبديل إلى ناقل gRPC أو WebSocket مع بصمة uTLS (chrome) لتقليل زمن المصافحة وتحسين الاستقرار.",
                    recommendedTransport = if (net == TransportType.TCP) TransportType.GRPC else TransportType.WEBSOCKET,
                    recommendedPort = 443
                )
            }
            else -> {
                DiagnosticReport(
                    title = "إعداد السيرفر مثالي ومستقر ✨",
                    probableCause = "الإعداد يستخدم ${server.protocolEnum.displayName} عبر ناقل ${net.displayName} مع حماية ${sec.displayName} وبصمة ${server.fingerprint.ifBlank { "chrome" }}.",
                    suggestedFix = "للحفاظ على أقصى سرعة وتوفير البطارية، أبقِ خيار إعادة الاتصال الذكي مفعلاً واستخدم ALPN بقيمة h2,http/1.1."
                )
            }
        }
    }
}
