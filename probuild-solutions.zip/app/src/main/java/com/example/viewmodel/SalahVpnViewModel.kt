package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.DiagnosticReport
import com.example.ai.SalahAiAssistant
import com.example.data.ProtocolType
import com.example.data.SalahVpnDatabase
import com.example.data.SecurityLayer
import com.example.data.TransportType
import com.example.data.VpnConfigParser
import com.example.data.VpnServerConfig
import com.example.security.SzCryptoManager
import com.example.vpn.SalahVpnService
import com.example.vpn.VpnConnectionState
import com.example.vpn.VpnEngineController
import com.example.vpn.VpnTelemetryState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

private val Context.dataStore by preferencesDataStore(name = "salah_vpn_prefs")

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val isExcluded: Boolean
)

data class AppSettingsState(
    val isArabicRtl: Boolean = true,
    val isDarkTheme: Boolean = false,
    val routingMode: String = "ALL", // ALL, BYPASS_LAN, SMART_ARABIC
    val killSwitchEnabled: Boolean = true,
    val autoReconnectEnabled: Boolean = true,
    val splitTunnelingEnabled: Boolean = false,
    val excludedPackages: Set<String> = emptySet(),
    val selectedServerId: Long = 1L,
    val dnsServer: String = "1.1.1.1"
)

class SalahVpnViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = SalahVpnDatabase.getInstance(application).vpnServerDao()
    private val prefs = application.dataStore

    private object Keys {
        val IS_ARABIC = booleanPreferencesKey("is_arabic")
        val IS_DARK = booleanPreferencesKey("is_dark")
        val ROUTING_MODE = stringPreferencesKey("routing_mode")
        val KILL_SWITCH = booleanPreferencesKey("kill_switch")
        val AUTO_RECONNECT = booleanPreferencesKey("auto_reconnect")
        val SPLIT_TUNNEL = booleanPreferencesKey("split_tunnel")
        val EXCLUDED_PKGS = stringSetPreferencesKey("excluded_pkgs")
        val SELECTED_SERVER_ID = longPreferencesKey("selected_server_id")
        val DNS_SERVER = stringPreferencesKey("dns_server")
    }

    val servers: StateFlow<List<VpnServerConfig>> = dao.observeAllServers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val telemetry: StateFlow<VpnTelemetryState> = VpnEngineController.telemetry

    private val _settings = MutableStateFlow(AppSettingsState())
    val settings: StateFlow<AppSettingsState> = _settings.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedGroupFilter = MutableStateFlow("الكل")
    val selectedGroupFilter: StateFlow<String> = _selectedGroupFilter.asStateFlow()

    private val _isPingingAll = MutableStateFlow(false)
    val isPingingAll: StateFlow<Boolean> = _isPingingAll.asStateFlow()

    private val _diagnosticReport = MutableStateFlow<DiagnosticReport?>(null)
    val diagnosticReport: StateFlow<DiagnosticReport?> = _diagnosticReport.asStateFlow()

    private val _isDiagnosing = MutableStateFlow(false)
    val isDiagnosing: StateFlow<Boolean> = _isDiagnosing.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _lastExportedSzText = MutableStateFlow("")
    val lastExportedSzText: StateFlow<String> = _lastExportedSzText.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    val filteredServers: StateFlow<List<VpnServerConfig>> = combine(
        servers,
        _searchQuery,
        _selectedGroupFilter
    ) { all, query, group ->
        all.filter { srv ->
            val matchesGroup = group == "الكل" || srv.groupName == group || (group == "المفضلة" && srv.isFavorite)
            val q = query.trim().lowercase()
            val matchesQuery = q.isEmpty() ||
                srv.name.lowercase().contains(q) ||
                srv.address.lowercase().contains(q) ||
                srv.countryNameAr.lowercase().contains(q) ||
                srv.countryNameEn.lowercase().contains(q) ||
                srv.protocol.lowercase().contains(q) ||
                srv.transport.lowercase().contains(q)
            matchesGroup && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        observePreferences()
        seedInitialServersIfNeeded()
        loadInstalledApps()
    }

    private fun observePreferences() {
        viewModelScope.launch {
            prefs.data.collect { p ->
                _settings.value = AppSettingsState(
                    isArabicRtl = p[Keys.IS_ARABIC] ?: true,
                    isDarkTheme = p[Keys.IS_DARK] ?: false,
                    routingMode = p[Keys.ROUTING_MODE] ?: "ALL",
                    killSwitchEnabled = p[Keys.KILL_SWITCH] ?: true,
                    autoReconnectEnabled = p[Keys.AUTO_RECONNECT] ?: true,
                    splitTunnelingEnabled = p[Keys.SPLIT_TUNNEL] ?: false,
                    excludedPackages = p[Keys.EXCLUDED_PKGS] ?: emptySet(),
                    selectedServerId = p[Keys.SELECTED_SERVER_ID] ?: 1L,
                    dnsServer = p[Keys.DNS_SERVER] ?: "1.1.1.1"
                )
            }
        }
    }

    private fun seedInitialServersIfNeeded() {
        viewModelScope.launch(Dispatchers.IO) {
            val existing = dao.getAllServersOnce()
            if (existing.isEmpty()) {
                val defaults = listOf(
                    VpnServerConfig(
                        id = 1L,
                        name = "ألمانيا • فرانكفورت فائق السرعة",
                        groupName = "أوروبا VIP",
                        protocol = ProtocolType.VLESS.name,
                        address = "de-fra-01.salahvpn.cloud",
                        port = 443,
                        uuid = "b8c4e2a0-91f4-4c3a-9d12-7741a89f0101",
                        encryption = "none",
                        transport = TransportType.REALITY_DEFAULT_TRANSPORT,
                        security = SecurityLayer.REALITY.name,
                        sni = "www.microsoft.com",
                        host = "www.microsoft.com",
                        path = "/",
                        alpn = "h2,http/1.1",
                        fingerprint = "chrome",
                        publicKey = "mF9xZq7Lp2K8vW1nB4cR6tY0uI3oP5aS7dF9gH1jK3l",
                        shortId = "6ba85179e30d4fc2",
                        flow = "xtls-rprx-vision",
                        countryNameAr = "ألمانيا",
                        countryNameEn = "Germany",
                        cityNameAr = "فرانكفورت",
                        cityNameEn = "Frankfurt",
                        countryFlag = "🇩🇪",
                        pingMs = 42,
                        stabilityScore = 99,
                        isFavorite = true,
                        sortOrder = 1
                    ),
                    VpnServerConfig(
                        id = 2L,
                        name = "الإمارات • دبي للألعاب والبث",
                        groupName = "الشرق الأوسط",
                        protocol = ProtocolType.VLESS.name,
                        address = "ae-dxb-edge.salahvpn.cloud",
                        port = 443,
                        uuid = "a1d2f3e4-5678-4901-b234-c56789012345",
                        encryption = "none",
                        transport = TransportType.GRPC.name,
                        security = SecurityLayer.TLS.name,
                        sni = "cdn.dxb.salahvpn.cloud",
                        host = "cdn.dxb.salahvpn.cloud",
                        path = "salah-grpc-gun",
                        alpn = "h2",
                        fingerprint = "chrome",
                        countryNameAr = "الإمارات",
                        countryNameEn = "UAE",
                        cityNameAr = "دبي",
                        cityNameEn = "Dubai",
                        countryFlag = "🇦🇪",
                        pingMs = 31,
                        stabilityScore = 98,
                        isFavorite = true,
                        sortOrder = 2
                    ),
                    VpnServerConfig(
                        id = 3L,
                        name = "هولندا • أمستردام XTLS-Vision",
                        groupName = "أوروبا VIP",
                        protocol = ProtocolType.VLESS.name,
                        address = "nl-ams-core.salahvpn.cloud",
                        port = 443,
                        uuid = "c9f8e7d6-5432-4109-8765-4321fedcba98",
                        encryption = "none",
                        transport = TransportType.TCP.name,
                        security = SecurityLayer.XTLS_VISION.name,
                        sni = "ams.salahvpn.cloud",
                        host = "ams.salahvpn.cloud",
                        path = "/",
                        alpn = "h2,http/1.1",
                        fingerprint = "firefox",
                        flow = "xtls-rprx-vision",
                        countryNameAr = "هولندا",
                        countryNameEn = "Netherlands",
                        cityNameAr = "أمستردام",
                        cityNameEn = "Amsterdam",
                        countryFlag = "🇳🇱",
                        pingMs = 54,
                        stabilityScore = 96,
                        isFavorite = false,
                        sortOrder = 3
                    ),
                    VpnServerConfig(
                        id = 4L,
                        name = "تركيا • إسطنبول WebSocket",
                        groupName = "الشرق الأوسط",
                        protocol = ProtocolType.VMESS.name,
                        address = "tr-ist-ws.salahvpn.cloud",
                        port = 443,
                        uuid = "f4e5d6c7-b8a9-4012-9345-6789abcdef01",
                        alterId = 0,
                        encryption = "aes-128-gcm",
                        transport = TransportType.WEBSOCKET.name,
                        security = SecurityLayer.TLS.name,
                        sni = "ist-ws.salahvpn.cloud",
                        host = "ist-ws.salahvpn.cloud",
                        path = "/vmess-ws-fast",
                        alpn = "http/1.1",
                        fingerprint = "chrome",
                        countryNameAr = "تركيا",
                        countryNameEn = "Turkey",
                        cityNameAr = "إسطنبول",
                        cityNameEn = "Istanbul",
                        countryFlag = "🇹🇷",
                        pingMs = 38,
                        stabilityScore = 94,
                        isFavorite = false,
                        sortOrder = 4
                    ),
                    VpnServerConfig(
                        id = 5L,
                        name = "الولايات المتحدة • نيويورك XHTTP",
                        groupName = "عالمي",
                        protocol = ProtocolType.VLESS.name,
                        address = "us-nyc-xhttp.salahvpn.cloud",
                        port = 443,
                        uuid = "778899aa-bbcc-4dde-eff0-112233445566",
                        encryption = "none",
                        transport = TransportType.XHTTP.name,
                        security = SecurityLayer.TLS.name,
                        sni = "nyc.salahvpn.cloud",
                        host = "nyc.salahvpn.cloud",
                        path = "/xhttp-stream",
                        alpn = "h2,http/1.1",
                        fingerprint = "safari",
                        countryNameAr = "الولايات المتحدة",
                        countryNameEn = "United States",
                        cityNameAr = "نيويورك",
                        cityNameEn = "New York",
                        countryFlag = "🇺🇸",
                        pingMs = 118,
                        stabilityScore = 92,
                        isFavorite = false,
                        sortOrder = 5
                    ),
                    VpnServerConfig(
                        id = 6L,
                        name = "سنغافورة • آسيا QUIC السريع",
                        groupName = "عالمي",
                        protocol = ProtocolType.VMESS.name,
                        address = "sg-sin-quic.salahvpn.cloud",
                        port = 8443,
                        uuid = "11223344-5566-4778-899a-abbccddeeff0",
                        alterId = 0,
                        encryption = "chacha20-poly1305",
                        transport = TransportType.QUIC.name,
                        security = SecurityLayer.TLS.name,
                        sni = "sg.salahvpn.cloud",
                        host = "sg.salahvpn.cloud",
                        path = "/",
                        alpn = "h3",
                        fingerprint = "chrome",
                        countryNameAr = "سنغافورة",
                        countryNameEn = "Singapore",
                        cityNameAr = "سنغافورة",
                        cityNameEn = "Singapore",
                        countryFlag = "🇸🇬",
                        pingMs = 95,
                        stabilityScore = 93,
                        isFavorite = false,
                        sortOrder = 6
                    )
                )
                dao.insertAll(defaults)
                VpnEngineController.updateState {
                    it.copy(
                        activeServer = defaults.first(),
                        visiblePublicIp = VpnEngineController.generateMaskedIpForServer(defaults.first())
                    )
                }
            } else {
                val selectedId = prefs.data.first()[Keys.SELECTED_SERVER_ID] ?: existing.first().id
                val active = existing.find { it.id == selectedId } ?: existing.first()
                VpnEngineController.updateState {
                    it.copy(
                        activeServer = active,
                        visiblePublicIp = VpnEngineController.generateMaskedIpForServer(active)
                    )
                }
            }
        }
    }

    private fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val pm = getApplication<Application>().packageManager
                val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.queryIntentActivities(mainIntent, PackageManager.ResolveInfoFlags.of(0L))
                } else {
                    @Suppress("DEPRECATION")
                    pm.queryIntentActivities(mainIntent, 0)
                }
                val currentExcluded = _settings.value.excludedPackages
                val selfPkg = getApplication<Application>().packageName
                val apps = resolveInfos
                    .mapNotNull { info ->
                        val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                        if (pkg == selfPkg) return@mapNotNull null
                        val label = info.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
                        InstalledAppInfo(
                            packageName = pkg,
                            appName = label,
                            isExcluded = currentExcluded.contains(pkg)
                        )
                    }
                    .distinctBy { it.packageName }
                    .sortedBy { it.appName.lowercase() }
                    .take(40)

                if (apps.isNotEmpty()) {
                    _installedApps.value = apps
                } else {
                    _installedApps.value = fallbackSampleApps(currentExcluded)
                }
            }.onFailure {
                _installedApps.value = fallbackSampleApps(_settings.value.excludedPackages)
            }
        }
    }

    private fun fallbackSampleApps(excluded: Set<String>): List<InstalledAppInfo> {
        return listOf(
            InstalledAppInfo("com.whatsapp", "WhatsApp • واتساب", excluded.contains("com.whatsapp")),
            InstalledAppInfo("org.telegram.messenger", "Telegram • تيليجرام", excluded.contains("org.telegram.messenger")),
            InstalledAppInfo("com.google.android.youtube", "YouTube • يوتيوب", excluded.contains("com.google.android.youtube")),
            InstalledAppInfo("com.android.chrome", "Google Chrome • متصفح كروم", excluded.contains("com.android.chrome")),
            InstalledAppInfo("com.instagram.android", "Instagram • إنستغرام", excluded.contains("com.instagram.android")),
            InstalledAppInfo("com.LocalBank.mobile", "تطبيق البنك المحلي", excluded.contains("com.LocalBank.mobile"))
        )
    }

    fun selectServer(server: VpnServerConfig) {
        viewModelScope.launch {
            prefs.edit { it[Keys.SELECTED_SERVER_ID] = server.id }
            val wasConnected = telemetry.value.state == VpnConnectionState.CONNECTED
            VpnEngineController.updateState {
                it.copy(
                    activeServer = server,
                    visiblePublicIp = VpnEngineController.generateMaskedIpForServer(server),
                    statusLog = if (wasConnected) {
                        "تم التبديل السريع إلى ${server.name} (${server.protocol})"
                    } else {
                        "تم تحديد ${server.name} للاتصال"
                    }
                )
            }
            if (wasConnected) {
                startVpnServiceInternal(server)
            }
        }
    }

    fun toggleConnection(onRequestVpnPermission: (Intent) -> Unit) {
        val currentState = telemetry.value.state
        if (currentState == VpnConnectionState.CONNECTED || currentState == VpnConnectionState.CONNECTING) {
            disconnectVpn()
        } else {
            val context = getApplication<Application>()
            val prepareIntent = runCatching { android.net.VpnService.prepare(context) }.getOrNull()
            if (prepareIntent != null) {
                onRequestVpnPermission(prepareIntent)
            } else {
                connectVpnConfirmed()
            }
        }
    }

    fun connectVpnConfirmed() {
        viewModelScope.launch {
            val active = telemetry.value.activeServer ?: servers.value.firstOrNull() ?: return@launch
            VpnEngineController.updateState {
                it.copy(
                    state = VpnConnectionState.CONNECTING,
                    activeServer = active,
                    statusLog = "جاري تهيئة محرك Xray-core (${active.protocol} / ${active.transportEnum.displayName})…"
                )
            }
            delay(550L)
            val measuredPing = VpnEngineController.measureServerPing(active)
            val updatedServer = active.copy(
                pingMs = measuredPing,
                lastConnectedAt = System.currentTimeMillis()
            )
            dao.updateServer(updatedServer)

            VpnEngineController.updateState {
                it.copy(
                    state = VpnConnectionState.CONNECTED,
                    activeServer = updatedServer,
                    connectedSinceMs = System.currentTimeMillis(),
                    visiblePublicIp = VpnEngineController.generateMaskedIpForServer(updatedServer),
                    killSwitchActive = _settings.value.killSwitchEnabled,
                    statusLog = "متصل بنجاح عبر ${updatedServer.name} (${measuredPing}ms)"
                )
            }
            startVpnServiceInternal(updatedServer)
        }
    }

    private fun startVpnServiceInternal(server: VpnServerConfig) {
        runCatching {
            val context = getApplication<Application>()
            val intent = Intent(context, SalahVpnService::class.java).apply {
                action = SalahVpnService.ACTION_START_VPN
                putExtra(SalahVpnService.EXTRA_SERVER_NAME, server.name)
                putExtra(SalahVpnService.EXTRA_KILL_SWITCH, _settings.value.killSwitchEnabled)
                if (_settings.value.splitTunnelingEnabled) {
                    putStringArrayListExtra(
                        SalahVpnService.EXTRA_EXCLUDED_APPS,
                        ArrayList(_settings.value.excludedPackages)
                    )
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    fun disconnectVpn() {
        runCatching {
            val context = getApplication<Application>()
            val intent = Intent(context, SalahVpnService::class.java).apply {
                action = SalahVpnService.ACTION_STOP_VPN
            }
            context.startService(intent)
        }
        VpnEngineController.updateState {
            it.copy(
                state = VpnConnectionState.DISCONNECTED,
                durationSeconds = 0L,
                downloadSpeedBps = 0L,
                uploadSpeedBps = 0L,
                statusLog = "تم قطع الاتصال وحماية البيانات"
            )
        }
    }

    fun pingSingleServer(server: VpnServerConfig) {
        viewModelScope.launch {
            val ping = VpnEngineController.measureServerPing(server)
            val stability = (100 - (ping / 12)).coerceIn(65, 99)
            dao.updatePing(server.id, ping, stability)
            if (telemetry.value.activeServer?.id == server.id) {
                VpnEngineController.updateState {
                    it.copy(activeServer = server.copy(pingMs = ping, stabilityScore = stability))
                }
            }
            showSnackbar("زمن استجابة ${server.name}: $ping ms")
        }
    }

    fun pingAllServersAndSort() {
        if (_isPingingAll.value) return
        viewModelScope.launch {
            _isPingingAll.value = true
            val list = dao.getAllServersOnce()
            for (srv in list) {
                val ping = VpnEngineController.measureServerPing(srv)
                val stability = (100 - (ping / 12)).coerceIn(68, 99)
                dao.updatePing(srv.id, ping, stability)
            }
            _isPingingAll.value = false
            val updated = dao.getAllServersOnce()
            val best = SalahAiAssistant.selectBestServer(updated)
            if (best != null && telemetry.value.activeServer?.id == best.id) {
                VpnEngineController.updateState { it.copy(activeServer = best) }
            }
            showSnackbar("تم فحص جميع السيرفرات وترتيبها حسب الأسرع ⚡")
        }
    }

    fun smartSelectBestServer() {
        viewModelScope.launch {
            val all = dao.getAllServersOnce()
            val best = SalahAiAssistant.selectBestServer(all)
            if (best != null) {
                selectServer(best)
                showSnackbar("الذكاء الاصطناعي اختار الأفضل: ${best.name} (${best.pingMs} ms)")
            }
        }
    }

    fun runAiDiagnostics(server: VpnServerConfig? = telemetry.value.activeServer) {
        val target = server ?: servers.value.firstOrNull() ?: return
        viewModelScope.launch {
            _isDiagnosing.value = true
            val report = SalahAiAssistant.diagnoseServerConfig(
                server = target,
                networkType = telemetry.value.networkTypeLabel
            )
            _diagnosticReport.value = report
            _isDiagnosing.value = false
        }
    }

    fun applyAiDiagnosticFix(server: VpnServerConfig, report: DiagnosticReport) {
        viewModelScope.launch {
            val updated = server.copy(
                transport = report.recommendedTransport?.name ?: server.transport,
                port = report.recommendedPort ?: server.port,
                sni = report.recommendedSni ?: server.sni.ifBlank { server.address },
                fingerprint = server.fingerprint.ifBlank { "chrome" },
                alpn = server.alpn.ifBlank { "h2,http/1.1" }
            )
            dao.updateServer(updated)
            if (telemetry.value.activeServer?.id == updated.id) {
                VpnEngineController.updateState { it.copy(activeServer = updated) }
            }
            _diagnosticReport.value = SalahAiAssistant.buildHeuristicDiagnosis(updated)
            showSnackbar("تم تطبيق تحسينات الذكاء الاصطناعي على ${updated.name} بنجاح")
        }
    }

    fun importFromUriOrJsonText(rawText: String, onSuccess: (Int) -> Unit = {}) {
        viewModelScope.launch {
            // Check if it is an .sz container first
            if (rawText.contains("BEGIN SALAH VPN SZ CONTAINER")) {
                importSzContainerText(rawText, "")
                return@launch
            }
            val parsed = VpnConfigParser.parseImportText(rawText)
            if (parsed.isEmpty()) {
                showSnackbar("تعذر التعرف على الرابط. يرجى إدخال رابط vmess:// أو vless:// أو JSON صالح")
            } else {
                val withPing = parsed.map { srv ->
                    val ping = VpnEngineController.measureServerPing(srv)
                    srv.copy(pingMs = ping)
                }
                dao.insertAll(withPing)
                showSnackbar("تم استيراد وتحليل ${withPing.size} سيرفر بنجاح ✨")
                onSuccess(withPing.size)
            }
        }
    }

    fun saveOrUpdateServer(config: VpnServerConfig, onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            val geo = VpnConfigParser.guessLocationFromHostOrName("${config.name} ${config.address} ${config.sni}")
            val enriched = config.copy(
                countryFlag = geo.flag,
                countryNameAr = geo.countryAr,
                countryNameEn = geo.countryEn,
                cityNameAr = geo.cityAr,
                cityNameEn = geo.cityEn,
                pingMs = if (config.pingMs > 0) config.pingMs else 48
            )
            if (enriched.id == 0L) {
                val newId = dao.insertServer(enriched)
                selectServer(enriched.copy(id = newId))
                showSnackbar("تم إضافة السيرفر الجديد بنجاح")
            } else {
                dao.updateServer(enriched)
                if (telemetry.value.activeServer?.id == enriched.id) {
                    VpnEngineController.updateState { it.copy(activeServer = enriched) }
                }
                showSnackbar("تم حفظ تعديلات السيرفر بنجاح")
            }
            onSaved()
        }
    }

    fun duplicateServer(server: VpnServerConfig) {
        viewModelScope.launch {
            val copy = server.copy(
                id = 0L,
                name = "${server.name} (نسخة)",
                sortOrder = server.sortOrder + 1
            )
            dao.insertServer(copy)
            showSnackbar("تم تكرار السيرفر ${server.name}")
        }
    }

    fun toggleFavorite(server: VpnServerConfig) {
        viewModelScope.launch {
            dao.updateServer(server.copy(isFavorite = !server.isFavorite))
        }
    }

    fun deleteServer(server: VpnServerConfig) {
        viewModelScope.launch {
            dao.deleteServer(server)
            showSnackbar("تم حذف ${server.name}")
        }
    }

    fun generateSzExport(
        serversToExport: List<VpnServerConfig>,
        passphrase: String,
        note: String,
        onGenerated: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.Default) {
                SzCryptoManager.exportToSzContent(serversToExport, passphrase, note)
            }
            result.onSuccess { content ->
                _lastExportedSzText.value = content
                onGenerated(content)
                showSnackbar("تم تشفير وتوليد ملف .sz بنجاح (AES-256-GCM)")
            }.onFailure { err ->
                showSnackbar("فشل التصدير: ${err.message}")
            }
        }
    }

    fun writeSzToUri(uri: Uri, content: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                getApplication<Application>().contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(content.toByteArray(Charsets.UTF_8))
                }
                showSnackbar("تم حفظ ملف .sz المشفر على الجهاز بنجاح 🔒")
            }.onFailure {
                showSnackbar("تعذر كتابة ملف .sz: ${it.message}")
            }
        }
    }

    fun readAndImportSzFromUri(uri: Uri, passphrase: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val text = getApplication<Application>().contentResolver.openInputStream(uri)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                importSzContainerText(text, passphrase)
            }.onFailure {
                showSnackbar("فشل قراءة ملف .sz: ${it.message}")
            }
        }
    }

    fun importSzContainerText(szText: String, passphrase: String, onImported: () -> Unit = {}) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.Default) {
                SzCryptoManager.importFromSzContent(szText, passphrase)
            }
            result.onSuccess { bundle ->
                dao.insertAll(bundle.servers)
                showSnackbar("تم فك تشفير واستيراد ${bundle.servers.size} سيرفر من ملف .sz بنجاح 🔓")
                onImported()
            }.onFailure { err ->
                showSnackbar(err.message ?: "فشل فك تشفير ملف .sz")
            }
        }
    }

    fun updateSearchQuery(q: String) {
        _searchQuery.value = q
    }

    fun updateGroupFilter(group: String) {
        _selectedGroupFilter.value = group
    }

    fun setLanguageArabic(isArabic: Boolean) {
        viewModelScope.launch {
            prefs.edit { it[Keys.IS_ARABIC] = isArabic }
        }
    }

    fun setDarkTheme(isDark: Boolean) {
        viewModelScope.launch {
            prefs.edit { it[Keys.IS_DARK] = isDark }
        }
    }

    fun setRoutingMode(mode: String) {
        viewModelScope.launch {
            prefs.edit { it[Keys.ROUTING_MODE] = mode }
            showSnackbar("تم تحديث وضع التوجيه الذكي")
        }
    }

    fun setKillSwitch(enabled: Boolean) {
        viewModelScope.launch {
            prefs.edit { it[Keys.KILL_SWITCH] = enabled }
            VpnEngineController.updateState { it.copy(killSwitchActive = enabled) }
        }
    }

    fun setAutoReconnect(enabled: Boolean) {
        viewModelScope.launch {
            prefs.edit { it[Keys.AUTO_RECONNECT] = enabled }
        }
    }

    fun setSplitTunneling(enabled: Boolean) {
        viewModelScope.launch {
            prefs.edit { it[Keys.SPLIT_TUNNEL] = enabled }
        }
    }

    fun toggleAppExclusion(packageName: String) {
        viewModelScope.launch {
            val current = _settings.value.excludedPackages.toMutableSet()
            if (current.contains(packageName)) {
                current.remove(packageName)
            } else {
                current.add(packageName)
            }
            prefs.edit { it[Keys.EXCLUDED_PKGS] = current }
            _installedApps.value = _installedApps.value.map {
                if (it.packageName == packageName) it.copy(isExcluded = current.contains(packageName)) else it
            }
        }
    }

    fun setDnsServer(dns: String) {
        viewModelScope.launch {
            prefs.edit { it[Keys.DNS_SERVER] = dns }
            showSnackbar("تم تعيين خادم DNS إلى $dns")
        }
    }

    fun showSnackbar(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    companion object {
        private val TransportType.Companion.REALITY_DEFAULT_TRANSPORT: String
            get() = TransportType.TCP.name
    }
}
