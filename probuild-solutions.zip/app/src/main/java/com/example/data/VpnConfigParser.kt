package com.example.data

import android.net.Uri
import android.util.Base64
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import java.net.URLDecoder
import java.util.UUID

object VpnConfigParser {
    private val jsonFormatter = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    data class GeoGuess(
        val flag: String,
        val countryAr: String,
        val countryEn: String,
        val cityAr: String,
        val cityEn: String
    )

    fun guessLocationFromHostOrName(text: String): GeoGuess {
        val lower = text.lowercase()
        return when {
            lower.contains("de") || lower.contains("fra") || lower.contains("ger") || lower.contains("ألمانيا") ->
                GeoGuess("🇩🇪", "ألمانيا", "Germany", "فرانكفورت", "Frankfurt")
            lower.contains("nl") || lower.contains("ams") || lower.contains("هولندا") ->
                GeoGuess("🇳🇱", "هولندا", "Netherlands", "أمستردام", "Amsterdam")
            lower.contains("us") || lower.contains("nyc") || lower.contains("أمريكا") ->
                GeoGuess("🇺🇸", "الولايات المتحدة", "United States", "نيويورك", "New York")
            lower.contains("uk") || lower.contains("lon") || lower.contains("gb") || lower.contains("بريطانيا") ->
                GeoGuess("🇬🇧", "المملكة المتحدة", "United Kingdom", "لندن", "London")
            lower.contains("sg") || lower.contains("sin") || lower.contains("سنغافورة") ->
                GeoGuess("🇸🇬", "سنغافورة", "Singapore", "سنغافورة", "Singapore")
            lower.contains("fr") || lower.contains("par") || lower.contains("فرنسا") ->
                GeoGuess("🇫🇷", "فرنسا", "France", "باريس", "Paris")
            lower.contains("tr") || lower.contains("ist") || lower.contains("تركيا") ->
                GeoGuess("🇹🇷", "تركيا", "Turkey", "إسطنبول", "Istanbul")
            lower.contains("ae") || lower.contains("dxb") || lower.contains("الإمارات") || lower.contains("دبي") ->
                GeoGuess("🇦🇪", "الإمارات", "UAE", "دبي", "Dubai")
            lower.contains("jp") || lower.contains("tyo") || lower.contains("اليابان") ->
                GeoGuess("🇯🇵", "اليابان", "Japan", "طوكيو", "Tokyo")
            else -> GeoGuess("🌐", "سيرفر عالمي", "Global Node", "مركز البيانات", "Cloud Edge")
        }
    }

    /**
     * Parses single or multi-line vmess:// and vless:// URIs or raw Xray JSON config
     */
    fun parseImportText(rawText: String): List<VpnServerConfig> {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) return emptyList()

        val results = mutableListOf<VpnServerConfig>()
        val lines = trimmed.lines().map { it.trim() }.filter { it.isNotEmpty() }

        for (line in lines) {
            when {
                line.startsWith("vless://", ignoreCase = true) -> {
                    parseVlessUri(line)?.let { results.add(it) }
                }
                line.startsWith("vmess://", ignoreCase = true) -> {
                    parseVmessUri(line)?.let { results.add(it) }
                }
            }
        }

        if (results.isEmpty() && trimmed.startsWith("{")) {
            parseRawJsonConfig(trimmed)?.let { results.add(it) }
        }

        return results
    }

    fun parseVlessUri(uriString: String): VpnServerConfig? {
        return runCatching {
            val withoutScheme = uriString.substringAfter("://")
            val remarkRaw = withoutScheme.substringAfter("#", "")
            val remark = if (remarkRaw.isNotEmpty()) {
                URLDecoder.decode(remarkRaw, "UTF-8")
            } else ""

            val mainPart = withoutScheme.substringBefore("#")
            val uuid = mainPart.substringBefore("@").trim()
            val hostAndQuery = mainPart.substringAfter("@")
            val hostPort = hostAndQuery.substringBefore("?")
            val queryPart = hostAndQuery.substringAfter("?", "")

            val address = if (hostPort.startsWith("[")) {
                hostPort.substringBefore("]") + "]"
            } else {
                hostPort.substringBefore(":")
            }
            val portStr = hostPort.substringAfterLast(":", "443")
            val port = portStr.toIntOrNull()?.coerceIn(1, 65535) ?: 443

            val params = mutableMapOf<String, String>()
            if (queryPart.isNotEmpty()) {
                queryPart.split("&").forEach { pair ->
                    val k = pair.substringBefore("=").lowercase()
                    val v = URLDecoder.decode(pair.substringAfter("=", ""), "UTF-8")
                    params[k] = v
                }
            }

            val transport = TransportType.fromCode(params["type"] ?: params["net"] ?: "tcp")
            val security = SecurityLayer.fromCode(params["security"] ?: "tls")
            val sni = params["sni"] ?: params["servername"] ?: address
            val host = params["host"] ?: sni
            val path = params["path"] ?: params["serviceName"] ?: "/"
            val alpn = params["alpn"] ?: "h2,http/1.1"
            val fp = params["fp"] ?: "chrome"
            val pbk = params["pbk"] ?: ""
            val sid = params["sid"] ?: ""
            val flow = params["flow"] ?: if (security == SecurityLayer.XTLS_VISION) "xtls-rprx-vision" else ""

            val geo = guessLocationFromHostOrName("$remark $address $sni")
            val displayName = remark.ifBlank { "${geo.countryAr} - VLESS (${transport.displayName})" }

            VpnServerConfig(
                name = displayName,
                groupName = "مستوردة",
                protocol = ProtocolType.VLESS.name,
                address = address,
                port = port,
                uuid = uuid.ifBlank { UUID.randomUUID().toString() },
                encryption = params["encryption"] ?: "none",
                transport = transport.name,
                security = security.name,
                sni = sni,
                host = host,
                path = path,
                alpn = alpn,
                fingerprint = fp,
                publicKey = pbk,
                shortId = sid,
                flow = flow,
                countryNameAr = geo.countryAr,
                countryNameEn = geo.countryEn,
                cityNameAr = geo.cityAr,
                cityNameEn = geo.cityEn,
                countryFlag = geo.flag
            )
        }.getOrNull()
    }

    fun parseVmessUri(uriString: String): VpnServerConfig? {
        return runCatching {
            val b64 = uriString.substringAfter("vmess://").trim()
            val padded = when (b64.length % 4) {
                2 -> "$b64=="
                3 -> "$b64="
                else -> b64
            }
            val decodedBytes = Base64.decode(padded, Base64.DEFAULT or Base64.URL_SAFE)
            val jsonStr = String(decodedBytes, Charsets.UTF_8)
            val jsonObj = jsonFormatter.parseToJsonElement(jsonStr) as? JsonObject ?: return null

            fun JsonObject.str(key: String, default: String = ""): String =
                this[key]?.jsonPrimitive?.content ?: default

            val ps = jsonObj.str("ps")
            val add = jsonObj.str("add", "127.0.0.1")
            val port = jsonObj.str("port", "443").toIntOrNull()?.coerceIn(1, 65535) ?: 443
            val id = jsonObj.str("id", UUID.randomUUID().toString())
            val aid = jsonObj.str("aid", "0").toIntOrNull() ?: 0
            val scy = jsonObj.str("scy", "auto")
            val net = TransportType.fromCode(jsonObj.str("net", "ws"))
            val tls = SecurityLayer.fromCode(jsonObj.str("tls", "tls"))
            val sni = jsonObj.str("sni", jsonObj.str("host", add))
            val host = jsonObj.str("host", sni)
            val path = jsonObj.str("path", "/")
            val alpn = jsonObj.str("alpn", "h2,http/1.1")
            val fp = jsonObj.str("fp", "chrome")

            val geo = guessLocationFromHostOrName("$ps $add $sni")
            val displayName = ps.ifBlank { "${geo.countryAr} - VMess (${net.displayName})" }

            VpnServerConfig(
                name = displayName,
                groupName = "مستوردة",
                protocol = ProtocolType.VMESS.name,
                address = add,
                port = port,
                uuid = id,
                alterId = aid,
                encryption = scy,
                transport = net.name,
                security = tls.name,
                sni = sni,
                host = host,
                path = path,
                alpn = alpn,
                fingerprint = fp,
                countryNameAr = geo.countryAr,
                countryNameEn = geo.countryEn,
                cityNameAr = geo.cityAr,
                cityNameEn = geo.cityEn,
                countryFlag = geo.flag
            )
        }.getOrNull()
    }

    fun parseRawJsonConfig(rawJson: String): VpnServerConfig? {
        return runCatching {
            val root = jsonFormatter.parseToJsonElement(rawJson) as? JsonObject ?: return null
            val remarks = root["remarks"]?.jsonPrimitive?.content ?: "Xray JSON مخصص"
            val geo = guessLocationFromHostOrName(rawJson)
            VpnServerConfig(
                name = remarks,
                groupName = "JSON مخصص",
                protocol = if (rawJson.contains("vmess", ignoreCase = true)) ProtocolType.VMESS.name else ProtocolType.VLESS.name,
                address = "xray-custom.node.net",
                port = 443,
                uuid = UUID.randomUUID().toString(),
                transport = TransportType.WEBSOCKET.name,
                security = SecurityLayer.TLS.name,
                sni = "xray-custom.node.net",
                countryNameAr = geo.countryAr,
                countryNameEn = geo.countryEn,
                cityNameAr = geo.cityAr,
                cityNameEn = geo.cityEn,
                countryFlag = geo.flag,
                customRawJson = rawJson
            )
        }.getOrNull()
    }

    fun validateRawJson(rawJson: String): Result<Boolean> {
        return runCatching {
            val element = jsonFormatter.parseToJsonElement(rawJson)
            require(element is JsonObject) { "يجب أن يكون الإعداد كائن JSON صالحاً" }
            true
        }
    }

    /**
     * Generates a complete Xray-core JSON configuration for a VpnServerConfig
     */
    fun toXrayJson(config: VpnServerConfig): String {
        if (config.customRawJson.isNotBlank()) {
            return config.customRawJson
        }
        val protocolLower = config.protocolEnum.name.lowercase()
        val netCode = config.transportEnum.code
        val secCode = config.securityEnum.code

        val root = buildJsonObject {
            put("remarks", config.name)
            putJsonObject("log") {
                put("loglevel", "warning")
            }
            putJsonArray("inbounds") {
                add(buildJsonObject {
                    put("tag", "tun-in")
                    put("port", 10808)
                    put("listen", "127.0.0.1")
                    put("protocol", "socks")
                    putJsonObject("settings") {
                        put("auth", "noauth")
                        put("udp", true)
                    }
                })
            }
            putJsonArray("outbounds") {
                add(buildJsonObject {
                    put("tag", "proxy")
                    put("protocol", protocolLower)
                    putJsonObject("settings") {
                        putJsonArray("vnext") {
                            add(buildJsonObject {
                                put("address", config.address)
                                put("port", config.port)
                                putJsonArray("users") {
                                    add(buildJsonObject {
                                        put("id", config.uuid)
                                        if (config.protocolEnum == ProtocolType.VMESS) {
                                            put("alterId", config.alterId)
                                            put("security", config.encryption.ifBlank { "auto" })
                                        } else {
                                            put("encryption", "none")
                                            if (config.flow.isNotBlank()) {
                                                put("flow", config.flow)
                                            }
                                        }
                                    })
                                }
                            })
                        }
                    }
                    putJsonObject("streamSettings") {
                        put("network", netCode)
                        put("security", secCode)
                        if (config.securityEnum == SecurityLayer.TLS || config.securityEnum == SecurityLayer.XTLS_VISION) {
                            putJsonObject("tlsSettings") {
                                put("serverName", config.sni.ifBlank { config.address })
                                put("fingerprint", config.fingerprint.ifBlank { "chrome" })
                                if (config.alpn.isNotBlank()) {
                                    put("alpn", buildJsonArray {
                                        config.alpn.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { add(kotlinx.serialization.json.JsonPrimitive(it)) }
                                    })
                                }
                            }
                        } else if (config.securityEnum == SecurityLayer.REALITY) {
                            putJsonObject("realitySettings") {
                                put("serverName", config.sni.ifBlank { config.address })
                                put("fingerprint", config.fingerprint.ifBlank { "chrome" })
                                put("publicKey", config.publicKey)
                                put("shortId", config.shortId)
                            }
                        }
                        when (config.transportEnum) {
                            TransportType.WEBSOCKET, TransportType.HTTP_UPGRADE, TransportType.XHTTP -> {
                                putJsonObject("wsSettings") {
                                    put("path", config.path.ifBlank { "/" })
                                    putJsonObject("headers") {
                                        put("Host", config.host.ifBlank { config.sni.ifBlank { config.address } })
                                    }
                                }
                            }
                            TransportType.GRPC -> {
                                putJsonObject("grpcSettings") {
                                    put("serviceName", config.path.removePrefix("/").ifBlank { "grpc" })
                                    put("multiMode", false)
                                }
                            }
                            TransportType.HTTP2 -> {
                                putJsonObject("httpSettings") {
                                    put("path", config.path.ifBlank { "/" })
                                }
                            }
                            else -> {}
                        }
                    }
                })
                add(buildJsonObject {
                    put("tag", "direct")
                    put("protocol", "freedom")
                })
            }
        }
        return jsonFormatter.encodeToString(JsonObject.serializer(), root)
    }

    /**
     * Converts a VpnServerConfig back to a shareable vless:// or vmess:// URI
     */
    fun toShareUri(config: VpnServerConfig): String {
        return if (config.protocolEnum == ProtocolType.VLESS) {
            val encodedName = Uri.encode(config.name)
            val sni = Uri.encode(config.sni.ifBlank { config.address })
            val host = Uri.encode(config.host.ifBlank { config.address })
            val path = Uri.encode(config.path.ifBlank { "/" })
            val fp = Uri.encode(config.fingerprint.ifBlank { "chrome" })
            val alpn = Uri.encode(config.alpn)
            buildString {
                append("vless://${config.uuid}@${config.address}:${config.port}")
                append("?encryption=none")
                append("&security=${config.securityEnum.code}")
                append("&type=${config.transportEnum.code}")
                append("&sni=$sni&host=$host&path=$path&fp=$fp&alpn=$alpn")
                if (config.publicKey.isNotBlank()) append("&pbk=${Uri.encode(config.publicKey)}")
                if (config.shortId.isNotBlank()) append("&sid=${Uri.encode(config.shortId)}")
                if (config.flow.isNotBlank()) append("&flow=${Uri.encode(config.flow)}")
                append("#$encodedName")
            }
        } else {
            val obj = buildJsonObject {
                put("v", "2")
                put("ps", config.name)
                put("add", config.address)
                put("port", config.port.toString())
                put("id", config.uuid)
                put("aid", config.alterId.toString())
                put("scy", config.encryption.ifBlank { "auto" })
                put("net", config.transportEnum.code)
                put("type", "none")
                put("host", config.host.ifBlank { config.sni })
                put("path", config.path.ifBlank { "/" })
                put("tls", config.securityEnum.code)
                put("sni", config.sni.ifBlank { config.address })
                put("alpn", config.alpn)
                put("fp", config.fingerprint.ifBlank { "chrome" })
            }
            val raw = obj.toString().toByteArray(Charsets.UTF_8)
            "vmess://" + Base64.encodeToString(raw, Base64.NO_WRAP)
        }
    }
}
