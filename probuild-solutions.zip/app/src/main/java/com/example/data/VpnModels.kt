package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.Serializable

@Serializable
enum class ProtocolType(val displayName: String) {
    VMESS("VMess"),
    VLESS("VLESS")
}

@Serializable
enum class TransportType(val displayName: String, val code: String) {
    TCP("TCP", "tcp"),
    WEBSOCKET("WebSocket", "ws"),
    GRPC("gRPC", "grpc"),
    HTTP2("HTTP/2", "h2"),
    MKCP("mKCP", "kcp"),
    QUIC("QUIC", "quic"),
    HTTP_UPGRADE("HTTPUpgrade", "httpupgrade"),
    XHTTP("XHTTP", "xhttp");

    companion object {
        fun fromCode(code: String): TransportType {
            return entries.find {
                it.code.equals(code.trim(), ignoreCase = true) ||
                    it.displayName.equals(code.trim(), ignoreCase = true)
            } ?: TCP
        }
    }
}

@Serializable
enum class SecurityLayer(val displayName: String, val code: String) {
    NONE("None", "none"),
    TLS("TLS", "tls"),
    REALITY("Reality", "reality"),
    XTLS_VISION("XTLS-Vision", "xtls-rprx-vision");

    companion object {
        fun fromCode(code: String): SecurityLayer {
            val normalized = code.trim().lowercase()
            return when {
                normalized.contains("vision") || normalized.contains("xtls") -> XTLS_VISION
                normalized.contains("reality") -> REALITY
                normalized.contains("tls") -> TLS
                else -> NONE
            }
        }
    }
}

enum class PingQuality(val labelAr: String, val labelEn: String) {
    EXCELLENT("ممتاز", "Excellent"),
    GOOD("جيد", "Good"),
    POOR("ضعيف", "Poor"),
    UNTESTED("غير مفحوص", "Untested")
}

@Serializable
@Entity(tableName = "vpn_servers")
data class VpnServerConfig(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val groupName: String = "الافتراضية",
    val protocol: String = ProtocolType.VLESS.name,
    val address: String,
    val port: Int = 443,
    val uuid: String,
    val alterId: Int = 0,
    val encryption: String = "none", // none for VLESS, auto/aes-128-gcm/chacha20-poly1305 for VMess
    val transport: String = TransportType.WEBSOCKET.name,
    val security: String = SecurityLayer.TLS.name,
    val sni: String = "",
    val host: String = "",
    val path: String = "/",
    val alpn: String = "h2,http/1.1",
    val fingerprint: String = "chrome",
    val publicKey: String = "", // Reality pbk
    val shortId: String = "", // Reality sid
    val flow: String = "", // xtls-rprx-vision
    val countryNameAr: String = "ألمانيا",
    val countryNameEn: String = "Germany",
    val cityNameAr: String = "فرانكفورت",
    val cityNameEn: String = "Frankfurt",
    val countryFlag: String = "🇩🇪",
    val pingMs: Int = -1,
    val stabilityScore: Int = 95, // 0..100
    val isFavorite: Boolean = false,
    val sortOrder: Int = 0,
    val customRawJson: String = "",
    val lastConnectedAt: Long = 0L
) {
    val protocolEnum: ProtocolType
        get() = runCatching { ProtocolType.valueOf(protocol) }.getOrDefault(ProtocolType.VLESS)

    val transportEnum: TransportType
        get() = runCatching { TransportType.valueOf(transport) }.getOrDefault(TransportType.TCP)

    val securityEnum: SecurityLayer
        get() = runCatching { SecurityLayer.valueOf(security) }.getOrDefault(SecurityLayer.TLS)

    val pingQuality: PingQuality
        get() = when {
            pingMs <= 0 -> PingQuality.UNTESTED
            pingMs < 110 -> PingQuality.EXCELLENT
            pingMs < 240 -> PingQuality.GOOD
            else -> PingQuality.POOR
        }
}

@Dao
interface VpnServerDao {
    @Query("SELECT * FROM vpn_servers ORDER BY isFavorite DESC, CASE WHEN pingMs > 0 THEN pingMs ELSE 99999 END ASC, sortOrder ASC")
    fun observeAllServers(): Flow<List<VpnServerConfig>>

    @Query("SELECT * FROM vpn_servers")
    suspend fun getAllServersOnce(): List<VpnServerConfig>

    @Query("SELECT * FROM vpn_servers WHERE id = :id LIMIT 1")
    suspend fun getServerById(id: Long): VpnServerConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServer(server: VpnServerConfig): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(servers: List<VpnServerConfig>)

    @Update
    suspend fun updateServer(server: VpnServerConfig)

    @Delete
    suspend fun deleteServer(server: VpnServerConfig)

    @Query("DELETE FROM vpn_servers WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE vpn_servers SET pingMs = :pingMs, stabilityScore = :stability WHERE id = :id")
    suspend fun updatePing(id: Long, pingMs: Int, stability: Int)
}

@Database(entities = [VpnServerConfig::class], version = 1, exportSchema = false)
abstract class SalahVpnDatabase : RoomDatabase() {
    abstract fun vpnServerDao(): VpnServerDao

    companion object {
        @Volatile
        private var INSTANCE: SalahVpnDatabase? = null

        fun getInstance(context: Context): SalahVpnDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SalahVpnDatabase::class.java,
                    "salah_vpn_encrypted_store.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
