package com.example.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.example.data.VpnServerConfig
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.nio.ByteBuffer
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

@Serializable
data class SzPayloadBundle(
    val appSignature: String = "SALAH_VPN_SZ_V1",
    val exportedAt: Long = System.currentTimeMillis(),
    val lockedToDevice: Boolean = false,
    val note: String = "",
    val servers: List<VpnServerConfig>
)

object SzCryptoManager {
    private const val MAGIC_HEADER = "SZVPN01!" // 8 bytes
    private const val SALT_SIZE = 16
    private const val IV_SIZE = 12
    private const val GCM_TAG_BITS = 128
    private const val PBKDF2_ITERATIONS = 65536
    private const val KEYSTORE_ALIAS = "SalahVpnMasterKey_v1"
    private const val APP_INTERNAL_PEPPER = "SalahVPN_SkyBlue_2026_SecureContainer_#38BDF8"

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    /**
     * Retrieves or generates a hardware-backed AES-256-GCM SecretKey in Android Keystore
     * for local device-bound protection.
     */
    private fun getOrCreateKeystoreSecret(): String {
        return runCatching {
            val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (!keyStore.containsAlias(KEYSTORE_ALIAS)) {
                val keyGenerator = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES,
                    "AndroidKeyStore"
                )
                val spec = KeyGenParameterSpec.Builder(
                    KEYSTORE_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
                keyGenerator.init(spec)
                keyGenerator.generateKey()
            }
            KEYSTORE_ALIAS
        }.getOrDefault("FallbackKeystoreAlias")
    }

    private fun deriveAesKey(passphrase: String, salt: ByteArray): SecretKey {
        val combinedSecret = "$APP_INTERNAL_PEPPER:${passphrase.trim()}"
        return runCatching {
            val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val spec = PBEKeySpec(combinedSecret.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
            val secret = factory.generateSecret(spec)
            SecretKeySpec(secret.encoded, "AES")
        }.getOrElse {
            // Fallback SHA-256 key derivation if PBKDF2WithHmacSHA256 is unavailable in unit test JVM
            val digest = MessageDigest.getInstance("SHA-256")
            digest.update(salt)
            val hash = digest.digest(combinedSecret.toByteArray(Charsets.UTF_8))
            SecretKeySpec(hash, "AES")
        }
    }

    /**
     * Encrypts a list of VpnServerConfig into an authenticated `.sz` file format
     * returned as a compact Base64 `.sz` armor string or raw bytes.
     */
    fun exportToSzContent(
        servers: List<VpnServerConfig>,
        passphrase: String = "",
        note: String = "حزمة إعدادات Salah VPN المشفرة"
    ): Result<String> {
        return runCatching {
            require(servers.isNotEmpty()) { "لا توجد سيرفرات لتصديرها" }
            getOrCreateKeystoreSecret()

            val sanitizedServers = servers.map { it.copy(id = 0L) }
            val bundle = SzPayloadBundle(
                exportedAt = System.currentTimeMillis(),
                note = note,
                servers = sanitizedServers
            )
            val plainBytes = json.encodeToString(bundle).toByteArray(Charsets.UTF_8)

            val random = SecureRandom()
            val salt = ByteArray(SALT_SIZE).also { random.nextBytes(it) }
            val iv = ByteArray(IV_SIZE).also { random.nextBytes(it) }

            val secretKey = deriveAesKey(passphrase, salt)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_BITS, iv))
            cipher.updateAAD(MAGIC_HEADER.toByteArray(Charsets.UTF_8))
            val cipherBytes = cipher.doFinal(plainBytes)

            // Integrity HMAC-SHA256
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(secretKey.encoded, "HmacSHA256"))
            mac.update(MAGIC_HEADER.toByteArray(Charsets.UTF_8))
            mac.update(salt)
            mac.update(iv)
            val hmac = mac.doFinal(cipherBytes)

            val totalSize = 8 + SALT_SIZE + IV_SIZE + 32 + cipherBytes.size
            val buffer = ByteBuffer.allocate(totalSize)
            buffer.put(MAGIC_HEADER.toByteArray(Charsets.UTF_8))
            buffer.put(salt)
            buffer.put(iv)
            buffer.put(hmac)
            buffer.put(cipherBytes)

            val encodedBody = Base64.encodeToString(buffer.array(), Base64.NO_WRAP)
            buildString {
                appendLine("-----BEGIN SALAH VPN SZ CONTAINER-----")
                appendLine("Version: 1.0 (AES-256-GCM + PBKDF2-HMAC-SHA256)")
                appendLine("Protected: ${if (passphrase.isNotBlank()) "Passphrase+Keystore" else "SalahVPN-Exclusive"}")
                appendLine(encodedBody.chunked(64).joinToString("\n"))
                append("-----END SALAH VPN SZ CONTAINER-----")
            }
        }
    }

    /**
     * Decrypts and verifies a `.sz` file content string back into SzPayloadBundle.
     */
    fun importFromSzContent(
        szText: String,
        passphrase: String = ""
    ): Result<SzPayloadBundle> {
        return runCatching {
            val cleanBase64 = szText.lines()
                .map { it.trim() }
                .filter {
                    it.isNotEmpty() &&
                        !it.startsWith("-----") &&
                        !it.startsWith("Version:") &&
                        !it.startsWith("Protected:")
                }
                .joinToString("")

            require(cleanBase64.isNotEmpty()) { "ملف .sz فارغ أو تالف" }
            val rawBytes = Base64.decode(cleanBase64, Base64.DEFAULT)
            require(rawBytes.size > 8 + SALT_SIZE + IV_SIZE + 32) {
                "حجم ملف .sz غير صالح أو أنه ليس ملف Salah VPN"
            }

            val buffer = ByteBuffer.wrap(rawBytes)
            val headerBytes = ByteArray(8).also { buffer.get(it) }
            val headerStr = String(headerBytes, Charsets.UTF_8)
            require(headerStr == MAGIC_HEADER) {
                "توقيع ملف .sz غير متطابق! هذا الملف لم يتم إنشاؤه بواسطة Salah VPN."
            }

            val salt = ByteArray(SALT_SIZE).also { buffer.get(it) }
            val iv = ByteArray(IV_SIZE).also { buffer.get(it) }
            val expectedHmac = ByteArray(32).also { buffer.get(it) }
            val cipherBytes = ByteArray(buffer.remaining()).also { buffer.get(it) }

            val secretKey = deriveAesKey(passphrase, salt)

            // Verify HMAC integrity
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(secretKey.encoded, "HmacSHA256"))
            mac.update(headerBytes)
            mac.update(salt)
            mac.update(iv)
            val actualHmac = mac.doFinal(cipherBytes)

            require(MessageDigest.isEqual(expectedHmac, actualHmac)) {
                "فشل التحقق من سلامة الملف أو كلمة المرور غير صحيحة (AES-256-GCM Integrity Error)"
            }

            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_BITS, iv))
            cipher.updateAAD(headerBytes)
            val decryptedBytes = cipher.doFinal(cipherBytes)

            val jsonStr = String(decryptedBytes, Charsets.UTF_8)
            val bundle = json.decodeFromString<SzPayloadBundle>(jsonStr)
            require(bundle.appSignature == "SALAH_VPN_SZ_V1") {
                "بصمة الحاوية غير صالحة"
            }
            bundle
        }
    }
}
