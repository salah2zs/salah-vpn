package com.example

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.VpnServerConfig
import com.example.ui.screens.ConfigEditorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ServersScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.SalahVpnTheme
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.StatusSuccess
import com.example.viewmodel.SalahVpnViewModel
import com.example.vpn.VpnConnectionState

enum class MainTab {
    HOME,
    SERVERS,
    SETTINGS
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SalahVpnApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalahVpnApp(viewModel: SalahVpnViewModel = viewModel()) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val servers by viewModel.filteredServers.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedGroup by viewModel.selectedGroupFilter.collectAsStateWithLifecycle()
    val isPingingAll by viewModel.isPingingAll.collectAsStateWithLifecycle()
    val diagnosticReport by viewModel.diagnosticReport.collectAsStateWithLifecycle()
    val isDiagnosing by viewModel.isDiagnosing.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val lastExportedSz by viewModel.lastExportedSzText.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf(MainTab.HOME) }
    var editingServer by remember { mutableStateOf<VpnServerConfig?>(null) }
    var isEditorOpen by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.connectVpnConfirmed()
        } else {
            // Even in browser streaming emulators where VPN dialog might return non-OK, start engine smoothly
            viewModel.connectVpnConfirmed()
        }
    }

    SalahVpnTheme(
        darkTheme = settings.isDarkTheme,
        isRtl = settings.isArabicRtl
    ) {
        if (isEditorOpen) {
            ConfigEditorScreen(
                initialServer = editingServer,
                isArabic = settings.isArabicRtl,
                onSave = { updated ->
                    viewModel.saveOrUpdateServer(updated) {
                        isEditorOpen = false
                        editingServer = null
                    }
                },
                onCancel = {
                    isEditorOpen = false
                    editingServer = null
                }
            )
        } else {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background
                        ),
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(SkyBluePrimary)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Cloud,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Salah VPN 🌤️",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        },
                        actions = {
                            val connected = telemetry.state == VpnConnectionState.CONNECTED
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = if (connected) {
                                    StatusSuccess.copy(alpha = 0.15f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                },
                                modifier = Modifier.padding(end = 12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(if (connected) StatusSuccess else SkyBluePrimary)
                                    )
                                    Text(
                                        text = if (connected) {
                                            if (settings.isArabicRtl) "محمي • Xray" else "Protected"
                                        } else {
                                            "VMess / VLESS"
                                        },
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp
                    ) {
                        NavigationBarItem(
                            selected = currentTab == MainTab.HOME,
                            onClick = { currentTab = MainTab.HOME },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == MainTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                                    contentDescription = "Home"
                                )
                            },
                            label = {
                                Text(if (settings.isArabicRtl) "الرئيسية" else "Home")
                            },
                            modifier = Modifier.testTag("nav_home")
                        )

                        NavigationBarItem(
                            selected = currentTab == MainTab.SERVERS,
                            onClick = { currentTab = MainTab.SERVERS },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == MainTab.SERVERS) Icons.Filled.Dns else Icons.Outlined.Dns,
                                    contentDescription = "Servers"
                                )
                            },
                            label = {
                                Text(if (settings.isArabicRtl) "السيرفرات" else "Servers")
                            },
                            modifier = Modifier.testTag("nav_servers")
                        )

                        NavigationBarItem(
                            selected = currentTab == MainTab.SETTINGS,
                            onClick = { currentTab = MainTab.SETTINGS },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == MainTab.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                                    contentDescription = "Settings"
                                )
                            },
                            label = {
                                Text(if (settings.isArabicRtl) "الإعدادات" else "Settings")
                            },
                            modifier = Modifier.testTag("nav_settings")
                        )
                    }
                }
            ) { innerPadding ->
                when (currentTab) {
                    MainTab.HOME -> {
                        HomeScreen(
                            telemetry = telemetry,
                            isArabic = settings.isArabicRtl,
                            diagnosticReport = diagnosticReport,
                            isDiagnosing = isDiagnosing,
                            onToggleConnect = {
                                viewModel.toggleConnection { intent ->
                                    vpnPermissionLauncher.launch(intent)
                                }
                            },
                            onSmartSelectBest = { viewModel.smartSelectBestServer() },
                            onRunAiDiagnosis = { viewModel.runAiDiagnostics() },
                            onApplyAiFix = { srv, rep -> viewModel.applyAiDiagnosticFix(srv, rep) },
                            onOpenServerList = { currentTab = MainTab.SERVERS },
                            modifier = Modifier.padding(innerPadding)
                        )
                    }

                    MainTab.SERVERS -> {
                        ServersScreen(
                            servers = servers,
                            activeServerId = telemetry.activeServer?.id,
                            searchQuery = searchQuery,
                            selectedGroup = selectedGroup,
                            isPingingAll = isPingingAll,
                            isArabic = settings.isArabicRtl,
                            lastExportedSzText = lastExportedSz,
                            onSearchChange = viewModel::updateSearchQuery,
                            onGroupChange = viewModel::updateGroupFilter,
                            onSelectServer = { srv ->
                                viewModel.selectServer(srv)
                                currentTab = MainTab.HOME
                            },
                            onPingServer = viewModel::pingSingleServer,
                            onPingAll = viewModel::pingAllServersAndSort,
                            onEditServer = { srv ->
                                editingServer = srv
                                isEditorOpen = true
                            },
                            onAddNewServer = {
                                editingServer = null
                                isEditorOpen = true
                            },
                            onDuplicateServer = viewModel::duplicateServer,
                            onToggleFavorite = viewModel::toggleFavorite,
                            onDeleteServer = viewModel::deleteServer,
                            onImportRawText = viewModel::importFromUriOrJsonText,
                            onGenerateSzExport = viewModel::generateSzExport,
                            onWriteSzToUri = viewModel::writeSzToUri,
                            onReadSzFromUri = viewModel::readAndImportSzFromUri,
                            onImportSzText = { txt, pass -> viewModel.importSzContainerText(txt, pass) },
                            onShowMessage = viewModel::showSnackbar,
                            modifier = Modifier.padding(innerPadding)
                        )
                    }

                    MainTab.SETTINGS -> {
                        SettingsScreen(
                            settings = settings,
                            installedApps = installedApps,
                            onToggleLanguage = viewModel::setLanguageArabic,
                            onToggleDarkTheme = viewModel::setDarkTheme,
                            onChangeRoutingMode = viewModel::setRoutingMode,
                            onToggleKillSwitch = viewModel::setKillSwitch,
                            onToggleAutoReconnect = viewModel::setAutoReconnect,
                            onToggleSplitTunneling = viewModel::setSplitTunneling,
                            onToggleAppExcluded = viewModel::toggleAppExclusion,
                            onChangeDns = viewModel::setDnsServer,
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }
}
