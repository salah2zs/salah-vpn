package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ai.DiagnosticReport
import com.example.data.PingQuality
import com.example.data.VpnServerConfig
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SkyBlueGlow
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.vpn.VpnConnectionState
import com.example.vpn.VpnTelemetryState
import java.util.Locale

@Composable
fun HomeScreen(
    telemetry: VpnTelemetryState,
    isArabic: Boolean,
    diagnosticReport: DiagnosticReport?,
    isDiagnosing: Boolean,
    onToggleConnect: () -> Unit,
    onSmartSelectBest: () -> Unit,
    onRunAiDiagnosis: () -> Unit,
    onApplyAiFix: (VpnServerConfig, DiagnosticReport) -> Unit,
    onOpenServerList: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isConnected = telemetry.state == VpnConnectionState.CONNECTED
    val isConnecting = telemetry.state == VpnConnectionState.CONNECTING
    val activeServer = telemetry.activeServer

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isConnected || isConnecting) 1.18f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.42f,
        targetValue = 0.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 600.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Hero Banner Card with Status & Visible IP
            HeroStatusBanner(
                telemetry = telemetry,
                isArabic = isArabic,
                isConnected = isConnected
            )

            Spacer(modifier = Modifier.height(22.dp))

            // Central Mobile-First Thumb-Friendly Connect Orb
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(220.dp)
                    .padding(8.dp)
            ) {
                val ringColor = when (telemetry.state) {
                    VpnConnectionState.CONNECTED -> StatusSuccess
                    VpnConnectionState.CONNECTING, VpnConnectionState.RECONNECTING -> SkyBlueLight
                    VpnConnectionState.DISCONNECTED -> SkyBluePrimary
                }

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .scale(pulseScale)
                ) {
                    drawCircle(
                        color = ringColor.copy(alpha = pulseAlpha),
                        radius = size.minDimension / 2f
                    )
                    drawCircle(
                        color = ringColor.copy(alpha = pulseAlpha * 1.4f),
                        radius = size.minDimension / 2.25f,
                        style = Stroke(width = 4.dp.toPx())
                    )
                }

                Surface(
                    shape = CircleShape,
                    tonalElevation = 10.dp,
                    shadowElevation = 14.dp,
                    color = Color.Transparent,
                    modifier = Modifier
                        .size(168.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(
                                colors = when (telemetry.state) {
                                    VpnConnectionState.CONNECTED -> listOf(
                                        Color(0xFF22C55E),
                                        Color(0xFF0EA5E9)
                                    )
                                    VpnConnectionState.CONNECTING, VpnConnectionState.RECONNECTING -> listOf(
                                        SkyBlueLight,
                                        SkyBluePrimary
                                    )
                                    VpnConnectionState.DISCONNECTED -> listOf(
                                        SkyBlueLight,
                                        Color(0xFF0284C7)
                                    )
                                }
                            )
                        )
                        .border(3.dp, Color.White.copy(alpha = 0.65f), CircleShape)
                        .clickable { onToggleConnect() }
                        .testTag("main_connect_button")
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxSize().padding(12.dp)
                    ) {
                        if (isConnecting) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(44.dp)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.PowerSettingsNew,
                                contentDescription = if (isArabic) "زر الاتصال" else "Connect Button",
                                tint = Color.White,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = when (telemetry.state) {
                                VpnConnectionState.CONNECTED -> if (isArabic) "متصل" else "CONNECTED"
                                VpnConnectionState.CONNECTING, VpnConnectionState.RECONNECTING ->
                                    if (isArabic) "يتصل..." else "CONNECTING"
                                VpnConnectionState.DISCONNECTED -> if (isArabic) "اتصال" else "CONNECT"
                            },
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        if (isConnected) {
                            Text(
                                text = formatDuration(telemetry.durationSeconds),
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 13.sp,
                                color = Color.White.copy(alpha = 0.92f)
                            )
                        } else {
                            Text(
                                text = if (isArabic) "بنقرة واحدة" else "One-Tap Xray",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.88f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Lightweight Engine & Network Handover Badge
            Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.padding(horizontal = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.BatteryChargingFull,
                        contentDescription = null,
                        tint = StatusSuccess,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = telemetry.statusLog,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Live Download / Upload Speeds & Ping Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TelemetryMetricCard(
                    title = if (isArabic) "التنزيل" else "Download",
                    value = formatSpeed(telemetry.downloadSpeedBps),
                    subValue = formatTotalBytes(telemetry.totalDownloadedBytes),
                    icon = Icons.Filled.CloudDownload,
                    accentColor = SkyBluePrimary,
                    modifier = Modifier.weight(1f)
                )
                TelemetryMetricCard(
                    title = if (isArabic) "الرفع" else "Upload",
                    value = formatSpeed(telemetry.uploadSpeedBps),
                    subValue = formatTotalBytes(telemetry.totalUploadedBytes),
                    icon = Icons.Filled.CloudUpload,
                    accentColor = StatusSuccess,
                    modifier = Modifier.weight(1f)
                )
                val pingVal = activeServer?.pingMs ?: -1
                val pingColor = when (activeServer?.pingQuality) {
                    PingQuality.EXCELLENT -> StatusSuccess
                    PingQuality.GOOD -> StatusWarning
                    PingQuality.POOR -> StatusError
                    else -> SkyBluePrimary
                }
                TelemetryMetricCard(
                    title = "Ping",
                    value = if (pingVal > 0) "$pingVal ms" else "-- ms",
                    subValue = if (isArabic) {
                        activeServer?.pingQuality?.labelAr ?: "ممتاز"
                    } else {
                        activeServer?.pingQuality?.labelEn ?: "Good"
                    },
                    icon = Icons.Filled.Speed,
                    accentColor = pingColor,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Active Server Selector Card
            if (activeServer != null) {
                ActiveServerCard(
                    server = activeServer,
                    isArabic = isArabic,
                    onClick = onOpenServerList
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Smart AI Actions Row: Smart Best Server & AI Fault Diagnostics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalButton(
                    onClick = onSmartSelectBest,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("smart_select_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isArabic) "اختيار الأفضل ذكياً" else "AI Best Node",
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1
                    )
                }

                OutlinedButton(
                    onClick = onRunAiDiagnosis,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("ai_diagnose_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    if (isDiagnosing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.BugReport,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isArabic) "تشخيص الأعطال AI" else "AI Diagnose",
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1
                    )
                }
            }

            // Expandable AI Diagnostic Result Card
            AnimatedVisibility(visible = diagnosticReport != null) {
                diagnosticReport?.let { report ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 14.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = null,
                                    tint = SkyBluePrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = report.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "السبب المحتمل: ${report.probableCause}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "الحل المقترح: ${report.suggestedFix}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )
                            if (activeServer != null && (report.recommendedTransport != null || report.recommendedSni != null)) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = { onApplyAiFix(activeServer, report) },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = SkyBluePrimary),
                                    modifier = Modifier.testTag("apply_ai_fix_button")
                                ) {
                                    Text(
                                        text = if (isArabic) "تطبيق الإصلاح التلقائي الآن" else "Apply Smart Fix",
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun HeroStatusBanner(
    telemetry: VpnTelemetryState,
    isArabic: Boolean,
    isConnected: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth().height(148.dp)) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_globe_1791612154653),
                contentDescription = "Global Network Map",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0x99061320),
                                Color(0xE60C4A6E)
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (isConnected) StatusSuccess else SkyBlueGlow)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isConnected) {
                                if (isArabic) "اتصال مشفر ومحمي (Xray-core)" else "Encrypted Tunnel Active"
                            } else {
                                if (isArabic) "جاهز للاتصال الخفيف" else "Ready to Connect"
                            },
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        color = Color.White.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = null,
                                tint = SkyBlueGlow,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (telemetry.killSwitchActive) "Kill Switch ON" else "No-Logs",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }

                HorizontalDivider(color = Color.White.copy(alpha = 0.15f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = if (isArabic) "الموقع الظاهر وعنوان IP" else "Visible Location & IP",
                            color = SkyBlueGlow,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${telemetry.activeServer?.countryFlag ?: "🇩🇪"} ${
                                    if (isArabic) {
                                        "${telemetry.activeServer?.countryNameAr ?: "ألمانيا"} • ${telemetry.activeServer?.cityNameAr ?: "فرانكفورت"}"
                                    } else {
                                        "${telemetry.activeServer?.countryNameEn ?: "Germany"} • ${telemetry.activeServer?.cityNameEn ?: "Frankfurt"}"
                                    }
                                }",
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Surface(
                        color = Color(0xFF042F49).copy(alpha = 0.85f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Public,
                                contentDescription = null,
                                tint = SkyBlueLight,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = telemetry.visiblePublicIp,
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryMetricCard(
    title: String,
    value: String,
    subValue: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subValue,
                style = MaterialTheme.typography.labelSmall,
                color = accentColor,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ActiveServerCard(
    server: VpnServerConfig,
    isArabic: Boolean,
    onClick: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("active_server_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Text(
                        text = server.countryFlag,
                        fontSize = 24.sp
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = server.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ProtocolBadge(text = server.protocolEnum.displayName)
                        ProtocolBadge(text = server.transportEnum.displayName)
                        ProtocolBadge(text = server.securityEnum.displayName)
                    }
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = if (isArabic) "تغيير السيرفر" else "Change Server",
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun ProtocolBadge(
    text: String,
    containerColor: Color = MaterialTheme.colorScheme.secondaryContainer,
    contentColor: Color = MaterialTheme.colorScheme.onSecondaryContainer
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = containerColor
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = contentColor,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

private fun formatDuration(seconds: Long): String {
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return String.format(Locale.US, "%02d:%02d:%02d", hrs, mins, secs)
}

private fun formatSpeed(bps: Long): String {
    if (bps <= 0L) return "0 KB/s"
    val kb = bps / 1024.0
    return if (kb >= 1024.0) {
        String.format(Locale.US, "%.2f MB/s", kb / 1024.0)
    } else {
        String.format(Locale.US, "%.1f KB/s", kb)
    }
}

private fun formatTotalBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 MB"
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024.0) {
        String.format(Locale.US, "%.2f GB", mb / 1024.0)
    } else {
        String.format(Locale.US, "%.1f MB", mb)
    }
}
