package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProtocolType
import com.example.data.SecurityLayer
import com.example.data.TransportType
import com.example.data.VpnConfigParser
import com.example.data.VpnServerConfig
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfigEditorScreen(
    initialServer: VpnServerConfig?,
    isArabic: Boolean,
    onSave: (VpnServerConfig) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onCancel() }

    val base = initialServer ?: VpnServerConfig(
        id = 0L,
        name = "سيرفر جديد • VLESS",
        groupName = "مخصصة",
        protocol = ProtocolType.VLESS.name,
        address = "edge.salahvpn.cloud",
        port = 443,
        uuid = UUID.randomUUID().toString(),
        transport = TransportType.WEBSOCKET.name,
        security = SecurityLayer.TLS.name,
        sni = "edge.salahvpn.cloud",
        host = "edge.salahvpn.cloud",
        path = "/ws",
        alpn = "h2,http/1.1",
        fingerprint = "chrome"
    )

    var isRawJsonMode by remember { mutableStateOf(false) }

    var name by remember { mutableStateOf(base.name) }
    var groupName by remember { mutableStateOf(base.groupName) }
    var protocol by remember { mutableStateOf(base.protocolEnum) }
    var address by remember { mutableStateOf(base.address) }
    var portText by remember { mutableStateOf(base.port.toString()) }
    var uuid by remember { mutableStateOf(base.uuid) }
    var alterIdText by remember { mutableStateOf(base.alterId.toString()) }
    var encryption by remember { mutableStateOf(base.encryption) }
    var transport by remember { mutableStateOf(base.transportEnum) }
    var security by remember { mutableStateOf(base.securityEnum) }
    var sni by remember { mutableStateOf(base.sni) }
    var host by remember { mutableStateOf(base.host) }
    var path by remember { mutableStateOf(base.path) }
    var alpn by remember { mutableStateOf(base.alpn) }
    var fingerprint by remember { mutableStateOf(base.fingerprint) }
    var publicKey by remember { mutableStateOf(base.publicKey) }
    var shortId by remember { mutableStateOf(base.shortId) }
    var flow by remember { mutableStateOf(base.flow) }

    fun buildCurrentConfig(customJson: String = ""): VpnServerConfig {
        return base.copy(
            name = name.ifBlank { "Salah VPN Node" },
            groupName = groupName.ifBlank { "الافتراضية" },
            protocol = protocol.name,
            address = address.trim().ifBlank { "127.0.0.1" },
            port = portText.toIntOrNull()?.coerceIn(1, 65535) ?: 443,
            uuid = uuid.trim().ifBlank { UUID.randomUUID().toString() },
            alterId = alterIdText.toIntOrNull() ?: 0,
            encryption = encryption.ifBlank { if (protocol == ProtocolType.VLESS) "none" else "auto" },
            transport = transport.name,
            security = security.name,
            sni = sni.trim(),
            host = host.trim(),
            path = path.trim().ifBlank { "/" },
            alpn = alpn.trim(),
            fingerprint = fingerprint.trim().ifBlank { "chrome" },
            publicKey = publicKey.trim(),
            shortId = shortId.trim(),
            flow = flow.trim(),
            customRawJson = customJson
        )
    }

    var rawJsonText by remember {
        mutableStateOf(
            base.customRawJson.ifBlank { VpnConfigParser.toXrayJson(base) }
        )
    }
    var jsonValidationStatus by remember { mutableStateOf<String?>(null) }
    var isJsonValid by remember { mutableStateOf(true) }

    // AI Config Assistant warnings
    val aiHint = remember(protocol, transport, security, portText, sni, publicKey, flow) {
        when {
            security == SecurityLayer.REALITY && publicKey.isBlank() ->
                "⚠️ تنبيه المساعد الذكي: طبقة Reality تتطلب إدخال مفتاح عام (Public Key - pbk) ومُعرف قصير (ShortId)."
            (security == SecurityLayer.TLS || security == SecurityLayer.XTLS_VISION) && sni.isBlank() ->
                "💡 نصيحة المساعد الذكي: حقل SNI فارغ. يُفضل مطابقته مع العنوان ($address) لتفادي فشل مصافحة TLS."
            security == SecurityLayer.XTLS_VISION && flow.isBlank() ->
                "💡 نصيحة المساعد الذكي: عند اختيار XTLS-Vision يُنصح بضبط Flow على xtls-rprx-vision."
            portText == "80" && security != SecurityLayer.NONE ->
                "⚠️ تنبيه المساعد الذكي: المنفذ 80 مخصص عادةً لاتصالات غير مشفرة، بينما المنفذ 443 هو الأنسب لـ ${security.displayName}."
            else ->
                "✅ المساعد الذكي: قيم الإعداد الحالية متوافقة ومثالية لمحرك Xray-core."
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (initialServer == null) {
                            if (isArabic) "إضافة سيرفر جديد" else "New Server Config"
                        } else {
                            if (isArabic) "محرر الإعدادات الذكي" else "Smart Config Editor"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onCancel, modifier = Modifier.testTag("editor_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            if (isRawJsonMode) {
                                val check = VpnConfigParser.validateRawJson(rawJsonText)
                                if (check.isSuccess) {
                                    onSave(buildCurrentConfig(customJson = rawJsonText))
                                } else {
                                    isJsonValid = false
                                    jsonValidationStatus = "خطأ في صيغة JSON: ${check.exceptionOrNull()?.message}"
                                }
                            } else {
                                onSave(buildCurrentConfig())
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.padding(end = 8.dp).testTag("save_server_button")
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isArabic) "حفظ" else "Save")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier.widthIn(max = 600.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Mode Switcher: Visual Editor vs Advanced Raw JSON
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = !isRawJsonMode,
                        onClick = { isRawJsonMode = false },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                        icon = { Icon(Icons.Filled.Tune, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    ) {
                        Text(if (isArabic) "المحرر المرئي" else "Visual Editor")
                    }
                    SegmentedButton(
                        selected = isRawJsonMode,
                        onClick = {
                            rawJsonText = VpnConfigParser.toXrayJson(buildCurrentConfig())
                            isRawJsonMode = true
                        },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                        icon = { Icon(Icons.Filled.Code, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("raw_json_mode_tab")
                    ) {
                        Text(if (isArabic) "الوضع المتقدم (JSON)" else "Raw JSON")
                    }
                }

                // AI Config Assistant Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = aiHint,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            FilledTonalButton(
                                onClick = {
                                    val cleanHost = address.trim().ifBlank { "cdn.salahvpn.cloud" }
                                    sni = sni.ifBlank { cleanHost }
                                    host = host.ifBlank { cleanHost }
                                    portText = "443"
                                    fingerprint = "chrome"
                                    alpn = if (transport == TransportType.QUIC) "h3" else "h2,http/1.1"
                                    if (security == SecurityLayer.XTLS_VISION) {
                                        flow = "xtls-rprx-vision"
                                    }
                                    if (security == SecurityLayer.REALITY && publicKey.isBlank()) {
                                        publicKey = "mF9xZq7Lp2K8vW1nB4cR6tY0uI3oP5aS7dF9gH1jK3l"
                                        shortId = "6ba85179"
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("ai_autofill_button")
                            ) {
                                Icon(Icons.Filled.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isArabic) "ضبط ذكي" else "Auto-Tune")
                            }
                        }
                    }
                }

                if (isRawJsonMode) {
                    // Advanced Raw Xray JSON Editor with Validation
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isArabic) "محرر Xray-core JSON الخام" else "Raw Xray JSON Configuration",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        FilledTonalButton(
                            onClick = {
                                val check = VpnConfigParser.validateRawJson(rawJsonText)
                                isJsonValid = check.isSuccess
                                jsonValidationStatus = if (check.isSuccess) {
                                    "تم التحقق: كائن Xray JSON سليم وصالح للتشغيل ✓"
                                } else {
                                    "خطأ في بناء JSON: ${check.exceptionOrNull()?.message}"
                                }
                            },
                            modifier = Modifier.testTag("validate_json_button")
                        ) {
                            Icon(
                                imageVector = if (isJsonValid) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                                contentDescription = null,
                                tint = if (isJsonValid) StatusSuccess else StatusError,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isArabic) "تحقق من الصحة" else "Validate JSON")
                        }
                    }

                    jsonValidationStatus?.let { msg ->
                        Text(
                            text = msg,
                            color = if (isJsonValid) StatusSuccess else StatusError,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedTextField(
                        value = rawJsonText,
                        onValueChange = {
                            rawJsonText = it
                            jsonValidationStatus = null
                        },
                        textStyle = TextStyle(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.sp
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(420.dp)
                            .testTag("raw_json_textfield")
                    )
                } else {
                    // Visual Editor Fields
                    Text(
                        text = if (isArabic) "1. البروتوكول والبيانات الأساسية" else "1. Protocol & Basic Info",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ProtocolType.entries.forEach { proto ->
                            FilterChip(
                                selected = protocol == proto,
                                onClick = { protocol = proto },
                                label = { Text(proto.displayName) }
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text(if (isArabic) "اسم السيرفر" else "Server Name") },
                            singleLine = true,
                            modifier = Modifier.weight(1.4f).testTag("server_name_input")
                        )
                        OutlinedTextField(
                            value = groupName,
                            onValueChange = { groupName = it },
                            label = { Text(if (isArabic) "المجموعة" else "Group") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = { Text(if (isArabic) "العنوان (Address / Host)" else "Address") },
                            singleLine = true,
                            modifier = Modifier.weight(1.6f).testTag("server_address_input")
                        )
                        OutlinedTextField(
                            value = portText,
                            onValueChange = { portText = it },
                            label = { Text(if (isArabic) "المنفذ (Port)" else "Port") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(0.8f).testTag("server_port_input")
                        )
                    }

                    OutlinedTextField(
                        value = uuid,
                        onValueChange = { uuid = it },
                        label = { Text("UUID") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("server_uuid_input")
                    )

                    if (protocol == ProtocolType.VMESS) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = encryption,
                                onValueChange = { encryption = it },
                                label = { Text("VMess Security (auto/aes-128-gcm/chacha20)") },
                                singleLine = true,
                                modifier = Modifier.weight(1.5f)
                            )
                            OutlinedTextField(
                                value = alterIdText,
                                onValueChange = { alterIdText = it },
                                label = { Text("AlterId") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(0.7f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isArabic) "2. وسيلة النقل (Transport)" else "2. Transport Protocol",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TransportType.entries.forEach { trans ->
                            FilterChip(
                                selected = transport == trans,
                                onClick = { transport = trans },
                                label = { Text(trans.displayName) }
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = host,
                            onValueChange = { host = it },
                            label = { Text("Host / Authority") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = path,
                            onValueChange = { path = it },
                            label = { Text("Path / ServiceName") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isArabic) "3. طبقة الأمان والتشفير (Security)" else "3. Security Layer",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SecurityLayer.entries.forEach { sec ->
                            FilterChip(
                                selected = security == sec,
                                onClick = { security = sec },
                                label = { Text(sec.displayName) }
                            )
                        }
                    }

                    if (security != SecurityLayer.NONE) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = sni,
                                onValueChange = { sni = it },
                                label = { Text("SNI (Server Name)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("server_sni_input")
                            )
                            OutlinedTextField(
                                value = fingerprint,
                                onValueChange = { fingerprint = it },
                                label = { Text("uTLS Fingerprint") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = alpn,
                                onValueChange = { alpn = it },
                                label = { Text("ALPN (h2,http/1.1,h3)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = flow,
                                onValueChange = { flow = it },
                                label = { Text("XTLS Flow") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    if (security == SecurityLayer.REALITY) {
                        OutlinedTextField(
                            value = publicKey,
                            onValueChange = { publicKey = it },
                            label = { Text("Reality Public Key (pbk)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = shortId,
                            onValueChange = { shortId = it },
                            label = { Text("Reality Short ID (sid)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}
