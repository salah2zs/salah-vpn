package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PingQuality
import com.example.data.VpnConfigParser
import com.example.data.VpnServerConfig
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning

@Composable
fun ServersScreen(
    servers: List<VpnServerConfig>,
    activeServerId: Long?,
    searchQuery: String,
    selectedGroup: String,
    isPingingAll: Boolean,
    isArabic: Boolean,
    lastExportedSzText: String,
    onSearchChange: (String) -> Unit,
    onGroupChange: (String) -> Unit,
    onSelectServer: (VpnServerConfig) -> Unit,
    onPingServer: (VpnServerConfig) -> Unit,
    onPingAll: () -> Unit,
    onEditServer: (VpnServerConfig) -> Unit,
    onAddNewServer: () -> Unit,
    onDuplicateServer: (VpnServerConfig) -> Unit,
    onToggleFavorite: (VpnServerConfig) -> Unit,
    onDeleteServer: (VpnServerConfig) -> Unit,
    onImportRawText: (String) -> Unit,
    onGenerateSzExport: (List<VpnServerConfig>, String, String, (String) -> Unit) -> Unit,
    onWriteSzToUri: (Uri, String) -> Unit,
    onReadSzFromUri: (Uri, String) -> Unit,
    onImportSzText: (String, String) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var showImportDialog by remember { mutableStateOf(false) }
    var showSzDialog by remember { mutableStateOf(false) }
    var szPassphrase by remember { mutableStateOf("") }
    var szNote by remember { mutableStateOf("حزمة سيرفرات Salah VPN المشفرة") }
    var szInputText by remember { mutableStateOf("") }

    val createSzFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        if (uri != null && lastExportedSzText.isNotBlank()) {
            onWriteSzToUri(uri, lastExportedSzText)
        }
    }

    val openSzFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            onReadSzFromUri(uri, szPassphrase)
        }
    }

    val groups = listOf("الكل", "المفضلة", "أوروبا VIP", "الشرق الأوسط", "عالمي", "مستوردة")

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddNewServer,
                containerColor = SkyBluePrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_server_fab")
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = if (isArabic) "إضافة سيرفر جديد" else "Add Server"
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.widthIn(max = 600.dp).fillMaxSize()) {
                Spacer(modifier = Modifier.height(8.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("server_search_input"),
                    shape = RoundedCornerShape(18.dp),
                    singleLine = true,
                    leadingIcon = {
                        Icon(imageVector = Icons.Filled.Search, contentDescription = null)
                    },
                    placeholder = {
                        Text(
                            text = if (isArabic) {
                                "ابحث باسم السيرفر، الدولة، VMess، VLESS..."
                            } else {
                                "Search by server, country, VMess, VLESS..."
                            }
                        )
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Quick Action Bar: One-Click Import, Ping All, .sz Encrypted Vault
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = { showImportDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("import_config_button"),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Link,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isArabic) "استيراد رابط/QR" else "Import URI/QR",
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1
                        )
                    }

                    FilledTonalButton(
                        onClick = onPingAll,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("ping_all_button"),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) {
                        if (isPingingAll) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Speed,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isArabic) "فحص وترتيب" else "Ping & Sort",
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1
                        )
                    }

                    Button(
                        onClick = { showSzDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("sz_vault_button"),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.EnhancedEncryption,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isArabic) "ملف .sz المشفر" else ".sz Vault",
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Group Filter Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    groups.forEach { grp ->
                        FilterChip(
                            selected = selectedGroup == grp,
                            onClick = { onGroupChange(grp) },
                            label = { Text(grp) },
                            shape = RoundedCornerShape(50)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Server List
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    items(servers, key = { it.id }) { server ->
                        val isSelected = server.id == activeServerId
                        ServerItemCard(
                            server = server,
                            isSelected = isSelected,
                            isArabic = isArabic,
                            onSelect = { onSelectServer(server) },
                            onPing = { onPingServer(server) },
                            onEdit = { onEditServer(server) },
                            onDuplicate = { onDuplicateServer(server) },
                            onToggleFav = { onToggleFavorite(server) },
                            onShareUri = {
                                val uri = VpnConfigParser.toShareUri(server)
                                clipboardManager.setText(AnnotatedString(uri))
                                onShowMessage("تم نسخ رابط ${server.protocol} إلى الحافظة 📋")
                            },
                            onExportSingleSz = {
                                onGenerateSzExport(listOf(server), "", "تصدير ${server.name}") { sz ->
                                    clipboardManager.setText(AnnotatedString(sz))
                                    showSzDialog = true
                                }
                            },
                            onDelete = { onDeleteServer(server) }
                        )
                    }
                }
            }
        }
    }

    // One-Click URI / Clipboard / QR Import Modal
    if (showImportDialog) {
        var rawImportInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = {
                Text(
                    text = if (isArabic) "استيراد سريع (VMess / VLESS / QR)" else "One-Click Import",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (isArabic) {
                            "الصق روابط vmess:// أو vless:// أو إعداد Xray JSON، وسيقوم Salah VPN بتحليلها وتسميتها تلقائياً."
                        } else {
                            "Paste vmess://, vless:// links or raw Xray JSON."
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = {
                                val clip = readClipboardText(context)
                                if (clip.isNotBlank()) {
                                    rawImportInput = clip
                                } else {
                                    // Provide ready-to-test sample VLESS Reality URI if clipboard is empty in emulator
                                    rawImportInput =
                                        "vless://9a8b7c6d-1122-4334-9556-778899aabbcc@fr-par-reality.salahvpn.cloud:443?encryption=none&security=reality&type=grpc&sni=www.cloudflare.com&fp=chrome&pbk=kL9mN2pQ4rS6tU8vW0xY2zA4bC6dE8fG0hI2jK4lM6n&sid=a1b2c3d4&serviceName=salah-grpc#فرنسا%20•%20باريس%20Reality"
                                }
                            },
                            modifier = Modifier.weight(1f).testTag("paste_clipboard_button")
                        ) {
                            Icon(Icons.Filled.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isArabic) "لصق من الحافظة" else "Paste")
                        }

                        OutlinedButton(
                            onClick = {
                                rawImportInput =
                                    "vless://d1e2f3a4-9988-4776-8554-33221100ffaa@uk-lon-vision.salahvpn.cloud:443?encryption=none&security=xtls-rprx-vision&type=tcp&sni=lon.salahvpn.cloud&fp=chrome&flow=xtls-rprx-vision#بريطانيا%20•%20لندن%20Vision"
                            },
                            modifier = Modifier.weight(1f).testTag("qr_preset_button")
                        ) {
                            Icon(Icons.Filled.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isArabic) "مسح QR تجريبي" else "Scan QR")
                        }
                    }

                    OutlinedTextField(
                        value = rawImportInput,
                        onValueChange = { rawImportInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .testTag("import_uri_textfield"),
                        placeholder = {
                            Text("vless://... أو vmess://...")
                        }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onImportRawText(rawImportInput)
                        showImportDialog = false
                    },
                    modifier = Modifier.testTag("confirm_import_button")
                ) {
                    Text(if (isArabic) "تحليل واستيراد" else "Import")
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text(if (isArabic) "إلغاء" else "Cancel")
                }
            }
        )
    }

    // Encrypted .sz Export & Import Vault Modal
    if (showSzDialog) {
        AlertDialog(
            onDismissRequest = { showSzDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.EnhancedEncryption,
                        contentDescription = null,
                        tint = SkyBluePrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isArabic) "نظام التشفير الحصري (.sz)" else "Encrypted .sz Container",
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = if (isArabic) {
                            "يتم تشفير الإعدادات بمعيار AES-256-GCM مع اشتقاق المفتاح عبر PBKDF2-HMAC-SHA256 وحمايتها عبر Android Keystore بحيث لا يمكن فتحها إلا داخل Salah VPN."
                        } else {
                            "Configs are encrypted with AES-256-GCM + PBKDF2 + Android Keystore and can only be imported inside Salah VPN."
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )

                    OutlinedTextField(
                        value = szPassphrase,
                        onValueChange = { szPassphrase = it },
                        label = {
                            Text(if (isArabic) "كلمة مرور إضافية للقفل (اختياري)" else "Optional Passphrase")
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("sz_passphrase_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                onGenerateSzExport(servers, szPassphrase, szNote) { generated ->
                                    szInputText = generated
                                    clipboardManager.setText(AnnotatedString(generated))
                                }
                            },
                            modifier = Modifier.weight(1f).testTag("generate_sz_button")
                        ) {
                            Icon(Icons.Filled.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isArabic) "توليد ونسخ .sz" else "Generate .sz")
                        }

                        OutlinedButton(
                            onClick = {
                                onGenerateSzExport(servers, szPassphrase, szNote) {
                                    createSzFileLauncher.launch("salah_vpn_backup.sz")
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isArabic) "حفظ ملف .sz" else "Save .sz File")
                        }
                    }

                    OutlinedTextField(
                        value = szInputText.ifBlank { lastExportedSzText },
                        onValueChange = { szInputText = it },
                        label = {
                            Text(if (isArabic) "محتوى حاوية .sz المشفرة" else ".sz Encrypted Payload")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .testTag("sz_payload_textfield")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = {
                                val target = szInputText.ifBlank { lastExportedSzText }
                                onImportSzText(target, szPassphrase)
                                showSzDialog = false
                            },
                            modifier = Modifier.weight(1f).testTag("decrypt_sz_button")
                        ) {
                            Icon(Icons.Filled.LockOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isArabic) "فك تشفير واستيراد" else "Decrypt & Import")
                        }

                        OutlinedButton(
                            onClick = {
                                openSzFileLauncher.launch(arrayOf("*/*"))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isArabic) "فتح ملف .sz" else "Open .sz File")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSzDialog = false }) {
                    Text(if (isArabic) "إغلاق" else "Close")
                }
            }
        )
    }
}

@Composable
private fun ServerItemCard(
    server: VpnServerConfig,
    isSelected: Boolean,
    isArabic: Boolean,
    onSelect: () -> Unit,
    onPing: () -> Unit,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onToggleFav: () -> Unit,
    onShareUri: () -> Unit,
    onExportSingleSz: () -> Unit,
    onDelete: () -> Unit
) {
    val borderColor = if (isSelected) SkyBluePrimary else Color.Transparent
    val pingColor = when (server.pingQuality) {
        PingQuality.EXCELLENT -> StatusSuccess
        PingQuality.GOOD -> StatusWarning
        PingQuality.POOR -> StatusError
        PingQuality.UNTESTED -> MaterialTheme.colorScheme.outline
    }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.dp else 0.dp,
                color = borderColor,
                shape = RoundedCornerShape(20.dp)
            )
            .clickable { onSelect() }
            .testTag("server_card_${server.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Text(text = server.countryFlag, fontSize = 24.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = server.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${server.address}:${server.port} • ${
                                if (isArabic) server.cityNameAr else server.cityNameEn
                            }",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Ping Quality Pill
                Surface(
                    shape = RoundedCornerShape(50),
                    color = pingColor.copy(alpha = 0.14f),
                    modifier = Modifier.clickable { onPing() }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(pingColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (server.pingMs > 0) "${server.pingMs} ms" else "Ping",
                            style = MaterialTheme.typography.labelMedium,
                            color = pingColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Protocol & Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ProtocolBadge(text = server.protocolEnum.displayName)
                    ProtocolBadge(text = server.transportEnum.displayName)
                    ProtocolBadge(text = server.securityEnum.displayName)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onToggleFav,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = if (server.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                            contentDescription = "Favorite",
                            tint = if (server.isFavorite) StatusWarning else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(36.dp).testTag("edit_server_${server.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = "Edit Server",
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    IconButton(
                        onClick = onDuplicate,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ContentCopy,
                            contentDescription = "Duplicate Server",
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    IconButton(
                        onClick = onExportSingleSz,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.EnhancedEncryption,
                            contentDescription = "Export .sz",
                            tint = SkyBluePrimary,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    IconButton(
                        onClick = onShareUri,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Share,
                            contentDescription = "Copy Share URI",
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Delete Server",
                            tint = StatusError,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun readClipboardText(context: Context): String {
    return runCatching {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        cm?.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString() ?: ""
    }.getOrDefault("")
}
