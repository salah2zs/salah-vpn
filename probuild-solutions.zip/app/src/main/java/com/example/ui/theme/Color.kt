package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sky Blue Primary Palette (#38BDF8 & #0EA5E9)
val SkyBluePrimary = Color(0xFF0EA5E9)
val SkyBlueLight = Color(0xFF38BDF8)
val SkyBlueGlow = Color(0xFF7DD3FC)
val SkyBlueSurfaceLight = Color(0xFFF0F9FF)
val SkyBlueCardLight = Color(0xFFFFFFFF)
val SkyBlueBorderLight = Color(0xFFBAE6FD)

// Deep Ocean Text & Dark Theme Palette (#0C4A6E)
val DeepOceanText = Color(0xFF0C4A6E)
val DeepOceanSecondaryText = Color(0xFF0369A1)
val DeepOceanDarkBg = Color(0xFF061320)
val DeepOceanDarkSurface = Color(0xFF0B2135)
val DeepOceanDarkCard = Color(0xFF102C46)
val DeepOceanDarkBorder = Color(0xFF1E4976)

// Status & Quality Colors
val StatusSuccess = Color(0xFF22C55E)
val StatusSuccessBg = Color(0xFFDCFCE7)
val StatusWarning = Color(0xFFF59E0B)
val StatusWarningBg = Color(0xFFFEF3C7)
val StatusError = Color(0xFFEF4444)
val StatusErrorBg = Color(0xFFFEE2E2)
