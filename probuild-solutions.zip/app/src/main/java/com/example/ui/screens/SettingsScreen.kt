package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.SyncLock
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.StatusSuccess
import com.example.viewmodel.AppSettingsState
import com.example.viewmodel.InstalledAppInfo

@Composable
fun SettingsScreen(
    settings: AppSettingsState,
    installedApps: List<InstalledAppInfo>,
    onToggleLanguage: (Boolean) -> Unit,
    onToggleDarkTheme: (Boolean) -> Unit,
    onChangeRoutingMode: (String) -> Unit,
    onToggleKillSwitch: (Boolean) -> Unit,
    onToggleAutoReconnect: (Boolean) -> Unit,
    onToggleSplitTunneling: (Boolean) -> Unit,
    onToggleAppExcluded: (String) -> Unit,
    onChangeDns: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isArabic = settings.isArabicRtl

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Section 1: Appearance & Language (RTL / Dark Mode)
            SettingsSectionCard(
                title = if (isArabic) "اللغة والمظهر" else "Language & Appearance",
                icon = Icons.Filled.Language
            ) {
                SettingsSwitchRow(
                    title = if (isArabic) "اللغة العربية (RTL)" else "Arabic Language (RTL)",
                    subtitle = if (isArabic) {
                        "دعم كامل للاتجاه من اليمين لليسار أو التبديل للإنجليزية"
                    } else {
                        "Switch between Arabic (RTL) and English (LTR)"
                    },
                    checked = settings.isArabicRtl,
                    onCheckedChange = onToggleLanguage,
                    tag = "toggle_language_switch"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                SettingsSwitchRow(
                    title = if (isArabic) "الوضع الداكن (Dark Mode)" else "Dark Mode",
                    subtitle = if (isArabic) {
                        "هوية محيطية داكنة مريحة للعين وتوفر استهلاك شاشات OLED"
                    } else {
                        "Deep ocean dark theme for comfortable night viewing"
                    },
                    checked = settings.isDarkTheme,
                    onCheckedChange = onToggleDarkTheme,
                    tag = "toggle_dark_mode_switch"
                )
            }

            // Section 2: Security, Kill Switch & Smart Reconnect
            SettingsSectionCard(
                title = if (isArabic) "الأمان والاتصال الذكي" else "Security & Smart Connection",
                icon = Icons.Filled.GppGood
            ) {
                SettingsSwitchRow(
                    title = "Kill Switch",
                    subtitle = if (isArabic) {
                        "قطع الإنترنت تلقائياً عند انقطاع الـ VPN لمنع تسرب عنوان IP"
                    } else {
                        "Block unencrypted traffic if VPN tunnel drops"
                    },
                    checked = settings.killSwitchEnabled,
                    onCheckedChange = onToggleKillSwitch,
                    tag = "toggle_kill_switch"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                SettingsSwitchRow(
                    title = if (isArabic) "إعادة الاتصال الذكية (Wi-Fi ↔ البيانات)" else "Smart Network Handover",
                    subtitle = if (isArabic) {
                        "إعادة مزامنة النفق تلقائياً عند تبديل الشبكة دون قطع الجلسة"
                    } else {
                        "Seamlessly reconnect when switching between Wi-Fi and Mobile Data"
                    },
                    checked = settings.autoReconnectEnabled,
                    onCheckedChange = onToggleAutoReconnect,
                    tag = "toggle_auto_reconnect"
                )
            }

            // Section 3: Routing & DNS
            SettingsSectionCard(
                title = if (isArabic) "قواعد التوجيه و DNS" else "Routing & DNS",
                icon = Icons.Filled.Route
            ) {
                Text(
                    text = if (isArabic) "نمط التوجيه (Routing Mode)" else "Routing Mode",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val modes = listOf(
                        "ALL" to (if (isArabic) "كل حركة المرور" else "All Traffic"),
                        "BYPASS_LAN" to (if (isArabic) "تجاوز الشبكة المحلية" else "Bypass LAN"),
                        "SMART_ARABIC" to (if (isArabic) "توجيه ذكي" else "Smart Direct")
                    )
                    modes.forEach { (code, label) ->
                        FilterChip(
                            selected = settings.routingMode == code,
                            onClick = { onChangeRoutingMode(code) },
                            label = { Text(label) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = if (isArabic) "خادم DNS المشفر" else "Encrypted DNS Provider",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val dnsList = listOf(
                        "1.1.1.1" to "Cloudflare 1.1.1.1",
                        "8.8.8.8" to "Google 8.8.8.8",
                        "9.9.9.9" to "Quad9 Security"
                    )
                    dnsList.forEach { (ip, label) ->
                        FilterChip(
                            selected = settings.dnsServer == ip,
                            onClick = { onChangeDns(ip) },
                            label = { Text(label) }
                        )
                    }
                }
            }

            // Section 4: Split Tunneling (Per-App VPN Exclusion)
            SettingsSectionCard(
                title = if (isArabic) "التطبيقات المستثناة (Split Tunneling)" else "Split Tunneling",
                icon = Icons.Filled.Apps
            ) {
                SettingsSwitchRow(
                    title = if (isArabic) "تفعيل Split Tunneling" else "Enable Split Tunneling",
                    subtitle = if (isArabic) {
                        "اختر التطبيقات التي تتصل بالإنترنت مباشرة دون المرور عبر الـ VPN"
                    } else {
                        "Choose apps that bypass the VPN tunnel"
                    },
                    checked = settings.splitTunnelingEnabled,
                    onCheckedChange = onToggleSplitTunneling,
                    tag = "toggle_split_tunneling"
                )

                AnimatedVisibility(visible = settings.splitTunnelingEnabled) {
                    Column(modifier = Modifier.padding(top = 12.dp)) {
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isArabic) {
                                "التطبيقات المستثناة حالياً (${settings.excludedPackages.size}):"
                            } else {
                                "Excluded Applications (${settings.excludedPackages.size}):"
                            },
                            style = MaterialTheme.typography.labelLarge,
                            color = SkyBluePrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        installedApps.take(12).forEach { app ->
                            val isChecked = settings.excludedPackages.contains(app.packageName)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = app.appName,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = app.packageName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { onToggleAppExcluded(app.packageName) }
                                )
                            }
                        }
                    }
                }
            }

            // Section 5: Privacy & No-Logs Policy Guarantee
            SettingsSectionCard(
                title = if (isArabic) "الخصوصية وحماية البيانات (No-Logs)" else "Privacy & No-Logs Policy",
                icon = Icons.Filled.PrivacyTip
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = StatusSuccess.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "AES-256-GCM • Keystore",
                            style = MaterialTheme.typography.labelMedium,
                            color = StatusSuccess,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isArabic) {
                        "• لا يقوم Salah VPN بتسجيل أي نشاط تصفح أو عناوين IP أو طلبات DNS (سياسة No-Logs صارمة).\n" +
                            "• جميع إعدادات VMess و VLESS مخزنة محلياً ومحمية ومشفرة بصيغة .sz عبر Android Keystore."
                    } else {
                        "• Strict No-Logs policy: Salah VPN never logs browsing activity, DNS queries, or traffic.\n" +
                            "• All VMess/VLESS configs and .sz exports are encrypted with AES-256-GCM."
                    },
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = SkyBluePrimary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(tag)
        )
    }
}
