package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = SkyBluePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = DeepOceanText,
    secondary = SkyBlueLight,
    onSecondary = DeepOceanText,
    secondaryContainer = Color(0xFFBAE6FD),
    onSecondaryContainer = DeepOceanText,
    tertiary = StatusSuccess,
    onTertiary = Color.White,
    background = SkyBlueSurfaceLight,
    onBackground = DeepOceanText,
    surface = SkyBlueCardLight,
    onSurface = DeepOceanText,
    surfaceVariant = Color(0xFFE0F2FE),
    onSurfaceVariant = DeepOceanSecondaryText,
    outline = SkyBlueBorderLight,
    error = StatusError,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = SkyBlueLight,
    onPrimary = Color(0xFF042F49),
    primaryContainer = DeepOceanDarkCard,
    onPrimaryContainer = Color(0xFFE0F2FE),
    secondary = SkyBluePrimary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF153B5E),
    onSecondaryContainer = Color(0xFFBAE6FD),
    tertiary = StatusSuccess,
    onTertiary = Color(0xFF052E16),
    background = DeepOceanDarkBg,
    onBackground = Color(0xFFE0F2FE),
    surface = DeepOceanDarkSurface,
    onSurface = Color(0xFFF0F9FF),
    surfaceVariant = DeepOceanDarkCard,
    onSurfaceVariant = SkyBlueGlow,
    outline = DeepOceanDarkBorder,
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A)
)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun SalahVpnTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    isRtl: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val layoutDirection = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = AppShapes,
            content = content
        )
    }
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    SalahVpnTheme(darkTheme = darkTheme, isRtl = true, content = content)
}
