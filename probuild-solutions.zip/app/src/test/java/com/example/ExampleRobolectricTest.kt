package com.example

import com.example.data.ProtocolType
import com.example.data.SecurityLayer
import com.example.data.TransportType
import com.example.data.VpnConfigParser
import com.example.data.VpnServerConfig
import com.example.security.SzCryptoManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class ExampleRobolectricTest {

    @Test
    fun vlessUriParserAndSzEncryptionRoundtrip_worksCorrectly() {
        val sampleVless =
            "vless://b8c4e2a0-91f4-4c3a-9d12-7741a89f0101@de-fra-01.salahvpn.cloud:443?encryption=none&security=reality&type=grpc&sni=www.microsoft.com&fp=chrome&pbk=testPublicKey123&sid=1a2b3c#Germany%20Node"

        val parsed = VpnConfigParser.parseVlessUri(sampleVless)
        assertNotNull(parsed)
        assertEquals(ProtocolType.VLESS, parsed!!.protocolEnum)
        assertEquals(TransportType.GRPC, parsed.transportEnum)
        assertEquals(SecurityLayer.REALITY, parsed.securityEnum)
        assertEquals("de-fra-01.salahvpn.cloud", parsed.address)
        assertEquals(443, parsed.port)
        assertEquals("testPublicKey123", parsed.publicKey)

        // Verify .sz AES-256-GCM encryption and decryption roundtrip
        val exportResult = SzCryptoManager.exportToSzContent(
            servers = listOf(parsed),
            passphrase = "salah_secret_key",
            note = "Unit Test Bundle"
        )
        assertTrue(exportResult.isSuccess)
        val szText = exportResult.getOrThrow()
        assertTrue(szText.contains("BEGIN SALAH VPN SZ CONTAINER"))

        val importResult = SzCryptoManager.importFromSzContent(
            szText = szText,
            passphrase = "salah_secret_key"
        )
        assertTrue(importResult.isSuccess)
        val bundle = importResult.getOrThrow()
        assertEquals(1, bundle.servers.size)
        assertEquals("de-fra-01.salahvpn.cloud", bundle.servers.first().address)

        // Wrong passphrase must fail integrity verification
        val wrongKeyResult = SzCryptoManager.importFromSzContent(
            szText = szText,
            passphrase = "wrong_password"
        )
        assertTrue(wrongKeyResult.isFailure)
    }
}
